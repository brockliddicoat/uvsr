#include "direct_light_visibility.h"
#include "pbr_lighting_debug_contract.h"
#include "pbr_material.h"
#include "pbr_surface_light_contract.h"
#include "screen_space_indirect_composite_shared.h"
#include "screen_space_visibility_defaults.h"
#include "ray_material_visibility_contract.h"
#include "ray_origin_contract.h"
#include "ray_visibility_trace_contract.h"
#include "visibility_estimator_cpu.h"
#include "visibility_projection_cpu.h"

#include <array>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <limits>

#include "image_based_lighting_shared.h"
#include "directional_shadow_settings.h"

namespace
{
    void Require(bool condition, const char* message)
    {
        if (!condition)
        {
            std::cerr << message << '\n';
            std::exit(EXIT_FAILURE);
        }
    }
    bool Near(float a, float b, float tolerance = 1e-5f) { return std::abs(a - b) <= tolerance; }

    void CheckDirectVisibility()
    {
        using namespace uvsr;
        int textureToken = 0, lightToken = 0, unrelatedToken = 0;
        auto* texture = reinterpret_cast<nvrhi::ITexture*>(&textureToken);
        auto* light = reinterpret_cast<const donut::engine::Light*>(&lightToken);
        auto* unrelated = reinterpret_cast<const donut::engine::Light*>(&unrelatedToken);
        const DirectLightVisibility factor{ texture, light };
        Require(TargetsDirectLight(factor, light) && !TargetsDirectLight(factor, unrelated) &&
            !TargetsDirectLight({ texture, nullptr }, light) && !DirectLightVisibility{}.IsComplete(),
            "direct visibility escaped its exact light identity");
        const DirectLightVisibilityTextureProperties properties{
            1920, 1080, 1, 1, 1, 1, true, true, true };
        Require(IsDirectLightVisibilityTextureCompatible(properties, 1920, 1080) &&
            !IsDirectLightVisibilityTextureCompatible(properties, 1919, 1080),
            "direct visibility lost its receiver extent");
        Require(ComposeDirectLightVisibility(.6f, .4f, true) == .4f &&
            ComposeDirectLightVisibility(.6f, .8f, true) == .6f &&
            ComposeDirectLightVisibility(.25f, 0, false) == .25f &&
            ComposeDirectLightVisibility(4, -1, true) == 0,
            "direct visibility did not compose as a bounded matching minimum");
    }

    void CheckLighting()
    {
        using namespace uvsr;
        const auto scales = ResolveImageBasedLightingScales(2, 2, true, .5f, true, 2);
        const auto disabled = ResolveImageBasedLightingScales(2, 2, false, .5f, false, 2);
        Require(scales.radiance == 8 && scales.diffuse == 4 && scales.specular == 16 &&
            disabled.radiance == 8 && disabled.diffuse == 0 && disabled.specular == 0,
            "IBL exposure and lobe controls became coupled");
        for (unsigned mask = 0; mask < 8; ++mask)
        {
            const bool gi = (mask & 1) != 0, diffuse = (mask & 2) != 0, specular = (mask & 4) != 0;
            Require(HasActiveScreenSpaceLightingConsumer(true, true, gi, diffuse, specular) ==
                    (gi || diffuse || specular) &&
                !HasActiveScreenSpaceLightingConsumer(false, true, gi, diffuse, specular),
                "AO/GI consumer routing lost a retained combination");
        }
        Require(Near(ComposeScreenSpaceIndirectLighting(2, .75f, 0, .5f), 2.5f) &&
            Near(ComposeScreenSpaceIndirectLighting(2, .75f, 1, .5f), 3.25f),
            "AO altered direct/emissive or screen-space GI energy");
        for (float roughness : { 0.f, .25f, .5f, 1.f })
        {
            const float mip = ImageBasedLightingReceiverMip(roughness, 9);
            Require(Near(ImageBasedLightingGenerationRoughness(mip / 8), roughness),
                "IBL receiver mip disagrees with prefilter roughness");
            Require(ImageBasedLightingSpecularOcclusion(.35f, 0, roughness) == 0 &&
                ImageBasedLightingSpecularOcclusion(.35f, 1, roughness) == 1,
                "IBL occlusion lost blocked or open endpoints");
        }
        Require(ResolveAnalyticalPositionalLightIntensity(12, 0, .5f, 4) == 3 &&
            Near(ResolveAnalyticalPositionalLightIntensity(12, .1f, .01f, 10000), .0012f, 1e-7f),
            "analytical emitter lost point or far-field energy");
        const float near = ResolveAnalyticalPositionalLightIntensity(12, .1f, 100, .0001f);
        Require(std::isfinite(near) && near > 0 && near < 120000 &&
            ResolvePbrAnalyticalRangeWeight(4, 0) == 1 &&
            Near(ResolvePbrAnalyticalRangeWeight(4, .25f), .5625f) &&
            ResolvePbrAnalyticalRangeWeight(16, .25f) == 0,
            "analytical emitter lost bounded near-field or finite range");
        const float inner = std::cos(.25f), outer = std::cos(.5f);
        Require(ResolvePbrOrdinarySpotWeight(inner, .5f, 1) == 1 &&
            ResolvePbrOrdinarySpotWeight(outer, .5f, 1) == 0 &&
            Near(ResolvePbrOrdinarySpotWeight((inner + outer) * .5f, .5f, 1), .5f),
            "spotlight inner, outer or midpoint weight changed");
    }

    void CheckShadowEmitters()
    {
        uvsr::DirectionalShadowSettings settings;
        settings.samplesPerPixel = 64;
        settings.hardShadows = true;
        Require(uvsr::ResolveRayShadowSampleCount(settings) == 1 &&
                uvsr::ResolveShadowEmitterSize(.53f, true) == 0 && settings.samplesPerPixel == 64,
            "hard shadows must override effective samples and emitter size without erasing them");
        settings.hardShadows = false;
        Require(uvsr::ResolveRayShadowSampleCount(settings) == 64 &&
                uvsr::ResolveShadowEmitterSize(.53f, false) == .53f,
            "disabling hard shadows must recover the stored sampling and emitter size");
        for (const ShaderFloat3 center : { ShaderFloat3{ 0, 0, 1 }, ShaderFloat3{ 0, 1, 0 } })
        {
            const auto hard = SamplePbrDirectionalEmitter(center, 0, { .1f, .9f });
            Require(hard.x == center.x && hard.y == center.y && hard.z == center.z,
                "a zero-angle emitter must use its exact center direction");
            for (float diameter : { .00925f, .5f, 1.5707963f })
            {
                double meanCosine = 0;
                for (int index = 0; index < 4096; ++index)
                {
                    const auto direction = SamplePbrDirectionalEmitter(center, diameter,
                        { (index + .5f) / 4096.f, float(index % 64) / 64.f });
                    const float cosine = ShaderDot(direction, center);
                    Require(Near(ShaderDot(direction, direction), 1.f, 2e-6f) &&
                            cosine >= std::cos(diameter * .5f) - 1e-6f,
                        "sampled shadow direction must be unit length and inside the emitter cone");
                    meanCosine += cosine;
                }
                Require(std::abs(meanCosine / 4096 - (1 + std::cos(diameter * .5)) * .5) < 2e-7,
                    "shadow samples must cover uniform solid angle with the correct mean cosine");
            }
        }
    }

    void CheckMaterialsAndDebug()
    {
        const float nan = std::numeric_limits<float>::quiet_NaN();
        PbrMaterialParameters material;
        material.baseColor.x = nan; material.metalness = 2; material.perceptualRoughness = -1;
        material.ior = 0; material.emissive.x = -2; material.opacity = nan;
        ValidatePbrMaterialParameters(material);
        Require(material.baseColor.x == 1 && material.metalness == 1 && material.perceptualRoughness == 0 &&
            material.ior == 1 && material.emissive.x == 0 && material.opacity == 1 &&
            PbrIorToF0(1) == 0 && Near(PbrIorToF0(1.5f), .04f),
            "material import validation changed");
        const ShaderFloat3 view{ 0, 0, 1 };
        Require(!ShouldFlipPbrSurfaceNormals(true, false, view, view) &&
            ShouldFlipPbrSurfaceNormals(true, true, { 0, 0, -1 }, view) &&
            ShouldFlipPbrSurfaceNormals(false, false, view, view),
            "surface orientation lost winding or two-sided behavior");
        const auto oriented = ResolvePbrTriangleSurfaceNormals(
            { 0, 3, 0 }, { 2, 0, 0 }, { 0, 1, 0 }, { .6f, 0, -.8f }, view);
        Require(Near(oriented.geometricNormal.z, 1) && Near(oriented.shadingNormal.x, -.6f) &&
            Near(oriented.shadingNormal.z, .8f), "triangle shading and geometry disagree on hemisphere");
        const auto fallback = ResolvePbrTrianglePlaneNormal({}, {}, { 0, 1, 0 });
        Require(fallback.y == 1, "degenerate triangle lost its material normal");

        const auto debug = ResolvePbrSkyVisibilityDebugColor(.25f);
        const auto invalid = ResolvePbrSkyVisibilityDebugColor(nan);
        Require(debug.x == .25f && debug.y == .25f && debug.z == .25f &&
            invalid.x == 1 && invalid.y == 1 && invalid.z == 1,
            "sky visibility debug lost grayscale or invalid-sample behavior");
        Require(PbrNeedsSkyVisibilitySample(UVSR_PBR_LIGHTING_DEBUG_SKY_VISIBILITY, false, false) &&
            !PbrNeedsSkyVisibilitySample(UVSR_PBR_LIGHTING_DEBUG_NONE, false, false) &&
            ResolvePbrDebugPresentation(UVSR_PBR_LIGHTING_DEBUG_SKY_VISIBILITY,
                UVSR_VISIBILITY_DEBUG_AMBIENT_VISIBILITY) == UVSR_PBR_DEBUG_PRESENT_VISIBILITY &&
            PbrDebugUsesBlackBackground(UVSR_PBR_LIGHTING_DEBUG_SKY_VISIBILITY,
                UVSR_VISIBILITY_DEBUG_FINAL_IMAGE),
            "visibility debug routing or neutral background changed");
    }

    void CheckRayVisibility()
    {
        const float nan = std::numeric_limits<float>::quiet_NaN();
        const auto normal = RayOriginOrientGeometricNormal({ 0, 0, -2 }, { 0, 0, 1 });
        Require(normal.x == 0 && normal.y == 0 && normal.z == 1, "ray origin normal lost its view hemisphere");
        Require(RayOriginStepDepthTowardCamera(.5f, true, true, 0) == std::nextafter(.5f, 1.f) &&
            RayOriginStepDepthTowardCamera(.5f, true, false, 0) == std::nextafter(.5f, 0.f) &&
            RayOriginStepDepthTowardCamera(1, true, true, 0) == 1 &&
            RayOriginStepDepthTowardCamera(0, true, false, 0) == 0, "float depth lost its camera-directed ULP step");
        Require(Near(RayOriginStepDepthTowardCamera(.5f, false, true, 1.f / 1024), .5f + 1.f / 1024, 1e-6f) &&
            Near(RayOriginStepDepthTowardCamera(.5f, false, false, 1.f / 1024), .5f - 1.f / 1024, 1e-6f),
            "integer depth ignored its configured forward/reverse step");
        Require(RayOriginOffsetFloatComponent(1, 1) > 1 && RayOriginOffsetFloatComponent(1, -1) < 1 &&
            RayOriginOffsetFloatComponent(-1, 1) > -1 && RayOriginOffsetFloatComponent(-1, -1) < -1 &&
            Near(RayOriginOffsetFloatComponent(0, 1), 1.f / 65536, 1e-6f), "signed ray origin offset changed");
        Require(Near(ResolveRayOriginClearance(.01f, .02f), .02f, 1e-6f) &&
            Near(ResolveRayOriginClearance(.03f, .02f), .03f, 1e-6f) &&
            ResolveRayOriginClearance(-1, nan) == 0, "ray clearance lost its user/depth bias boundary");
        const auto position = ResolveRayOriginPosition({ 1, -1, 0 }, { 0, 0, 1 }, .01f);
        Require(position.x == 1 && position.y == -1 && position.z > .01f,
            "ray origin failed to combine clearance with representable offset");

        const auto opaque = ResolveRayMaterialCoveragePlan(true, false, false, false, true, false, true, true);
        Require(opaque.mode == UVSR_RAY_MATERIAL_COVERAGE_OPAQUE &&
            ResolveRayMaterialCandidateCoverage(opaque, 0, 0, 1, false) &&
            ResolveRayMaterialCoveragePlan(false, false, false, false, true, false, false, false).mode ==
                UVSR_RAY_MATERIAL_COVERAGE_REJECT &&
            ResolveRayMaterialCoveragePlan(false, true, false, false, true, false, false, false).mode ==
                UVSR_RAY_MATERIAL_COVERAGE_OPAQUE, "opaque/backface/double-sided ray acceptance changed");
        Require(ResolveRayMaterialCoveragePlan(true, false, true, true, true, false, false, false).mode ==
                UVSR_RAY_MATERIAL_COVERAGE_REJECT &&
            ResolveRayMaterialCoveragePlan(true, false, false, false, false, false, false, false).mode ==
                UVSR_RAY_MATERIAL_COVERAGE_REJECT, "unsupported or transparent material became a blocker");
        const auto opacity = ResolveRayMaterialCoveragePlan(true, false, false, false, false, true, true, true);
        const auto base = ResolveRayMaterialCoveragePlan(true, false, false, false, false, true, false, true);
        const auto scalar = ResolveRayMaterialCoveragePlan(true, false, false, false, false, true, false, false);
        Require(opacity.alphaSource == UVSR_RAY_MATERIAL_ALPHA_OPACITY_TEXTURE &&
            base.alphaSource == UVSR_RAY_MATERIAL_ALPHA_BASE_TEXTURE && scalar.alphaSource == UVSR_RAY_MATERIAL_ALPHA_NONE &&
            !ResolveRayMaterialCandidateCoverage(opacity, 1, .2f, .5f, true) &&
            ResolveRayMaterialCandidateCoverage(base, 1, .9f, .5f, true) &&
            !ResolveRayMaterialCandidateCoverage(opacity, 1, 1, .5f, false),
            "ray alpha source precedence or descriptor rejection changed");
        Require(ResolveRayMaterialCandidateCoverage(scalar, .5f, 0, .5f, true) &&
            !ResolveRayMaterialCandidateCoverage(scalar, .499f, 1, .5f, true) &&
            ResolveRayMaterialCandidateCoverage(scalar, 2, 1, 1, true) &&
            !ResolveRayMaterialCandidateCoverage(scalar, nan, 1, .5f, true),
            "ray alpha lost exact cutoff, saturation or finite rejection");

        const auto miss = ResolveRayVisibilityTraceSample(false);
        const auto hit = ResolveRayVisibilityTraceSample(true);
        Require(miss.queryCount == 1 && !miss.occluded && miss.visibility == 1 &&
            hit.queryCount == 1 && hit.occluded && hit.visibility == 0,
            "ray hit/miss encoding lost its binary one-query contract");
        for (const auto samples : { std::array{ miss, hit, hit }, std::array{ hit, miss, hit } })
        {
            auto aggregate = BeginRayVisibilityTraceAggregate();
            for (const auto sample : samples)
                aggregate = AccumulateRayVisibilityTraceSample(aggregate, sample);
            Require(aggregate.queryCount == 3 && aggregate.sampleCount == 3 && aggregate.visibleSampleCount == 1 &&
                Near(ResolveRayVisibilityTraceAverage(aggregate), 1.f / 3, 1e-6f) &&
                RayVisibilityTraceAggregateIsComplete(aggregate, 3) && !RayVisibilityTraceAggregateIsComplete(aggregate, 4),
                "ray reduction lost order independence or one query per sample");
        }
    }

    void CheckProjection()
    {
        struct Case { float startZ, startW, endZ, endW; bool reverse, valid, clipped; float scale; };
        const float inset = 1.f - VisibilityProjectionClipInset;
        const Case cases[] = {
            { .25f, 1, -.75f, 1, false, true, true, .25f * inset },
            { .75f, 1, 1.75f, 1, true, true, true, .25f * inset },
            { .5f, 1, .5f, -1, false, true, true, (1.f - 2.f * VisibilityProjectionEpsilon) * .5f * inset },
            { .2f, 1, .2f, 1, false, true, false, 1 },
            { .8f, 1, .8f, 1, true, true, false, 1 },
            { 0, 1, -1, 1, false, true, true, 0 },
            { .1f, 1, -1000, 1, false, true, true, .1f / 1000.1f * inset },
            { .2f, 0, .2f, 1, false, false, false, 0 },
            { -.1f, 1, .2f, 1, false, false, false, 0 },
            { .2f, 1, std::numeric_limits<float>::infinity(), 1, false, false, false, 0 }
        };
        for (const auto& test : cases)
        {
            const auto clip = ComputeVisibilityProjectionEndpointClip(test.startZ, test.startW, test.endZ, test.endW, test.reverse);
            Require(bool(clip.valid) == test.valid && (!test.valid ||
                (bool(clip.clipped) == test.clipped && Near(clip.endpointScale, test.scale, 2e-6f))),
                "shared visibility projection clipping changed");
        }
    }

    void CheckSectorCoverage()
    {
        const float minimum = 5.10f / 32, maximum = 5.35f / 32;
        Require(MakeStochasticSectorRangeMask({ minimum, maximum }, 0) == 0 &&
            MakeStochasticSectorRangeMask({ minimum, maximum }, .75f) == 0x20u &&
            MakeStochasticSectorRangeMask({ minimum, maximum }, 1.75f) == 0x20u,
            "thin sector interval or periodic phase changed");
        Require(MakeStochasticSectorRangeMask({ 0, 1 }, .37f) == 0xffffffffu &&
            MakeStochasticSectorRangeMask({ -4, 5 }, .1f) == 0xffffffffu &&
            MakeStochasticSectorRangeMask({ .8f, .2f }, .4f) == MakeStochasticSectorRangeMask({ .2f, .8f }, .4f),
            "sector endpoint clamping or ordering changed");
        const float nan = std::numeric_limits<float>::quiet_NaN();
        Require(MakeStochasticSectorRangeMask({ nan, .5f }, 0) == 0 &&
            MakeStochasticSectorRangeMask({ .5f, nan }, 0) == 0 &&
            MakeStochasticSectorRangeMask({ 0, 1 }, std::numeric_limits<float>::infinity()) == 0,
            "nonfinite sector input fabricated occlusion");
        unsigned hits = 0;
        for (unsigned phase = 0; phase < 256; ++phase)
            hits += MakeStochasticSectorRangeMask({ minimum, maximum }, (float(phase) + .5f) / 256) != 0;
        Require(std::abs(float(hits) / 256 - (maximum - minimum) * 32) <= 1.f / 256,
            "thin interval survival lost proportional angular mass");
        RadialVisibilityMask mask{};
        Require(AccumulateOccluder(mask, 0x0fu) == 0x0fu && AccumulateOccluder(mask, 0x3cu) == 0x30u &&
            AccumulateOccluder(mask, 0x3cu) == 0 && AccumulateOccluder(mask, 0xf0000000u) == 0xf0000000u &&
            mask.occludedBits == 0xf000003fu, "sector union lost overlap, idempotence or high bits");
        mask = {};
        for (unsigned count = 0; count <= 32; ++count)
        {
            Require(CountOccludedSectors(mask) == count && GetSliceVisibility(mask) == 1.f - float(count) / 32,
                "sector population and visibility disagree");
            if (count < 32)
                Require(AccumulateOccluder(mask, 1u << count) == (1u << count), "sector was not reported exactly once");
        }
    }

    using Float3 = ShaderFloat3;
    bool Near(Float3 a, Float3 b)
    {
        return Near(a.x, b.x) && Near(a.y, b.y) && Near(a.z, b.z);
    }

    void CheckSliceMeasures()
    {
        constexpr Float3 view{ 0, 0, 1 }, side{ 1, 0, 0 };
        constexpr std::array<float, 7> angles{ -2.8f, -1.4f, -.4f, 0, .4f, 1.4f, 2.8f };
        for (const float tilt : { -.8f, 0.f, .9f })
        for (const float outOfPlane : { 0.f, .55f })
        {
            const auto normal = VisibilityEstimatorSafeNormalize(
                { std::sin(tilt), outOfPlane, std::cos(tilt) }, view);
            const auto measure = BuildSliceMeasure(view, side, normal);
            Require(measure.valid && Near(ShaderDot(measure.V, measure.S), 0) &&
                Near(measure.cosGamma, std::cos(tilt)) && Near(measure.sinGamma, -std::sin(tilt)),
                "shared estimator lost its orthogonal signed basis");

            // independent hemisphere quadrature checks the shared closed forms.
            std::array<double, 7> uniform{}, cosine{};
            double uniformMass = 0, cosineMass = 0;
            constexpr unsigned steps = 16384;
            const double step = 2.0 * VisibilityEstimatorPi / steps;
            for (unsigned index = 0; index < steps; ++index)
            {
                const double angle = -VisibilityEstimatorPi + (index + .5) * step;
                const Float3 direction{ float(std::sin(angle)), 0, float(std::cos(angle)) };
                const double facing = std::max(double(ShaderDot(normal, direction)), 0.0);
                const double solidWeight = facing > 0 ? .5 * std::abs(std::sin(angle)) * step : 0;
                const double cosineWeight = facing * std::abs(std::sin(angle)) * step;
                uniformMass += solidWeight;
                cosineMass += cosineWeight;
                for (unsigned target = 0; target < angles.size(); ++target)
                {
                    if (angle > angles[target])
                        continue;
                    uniform[target] += solidWeight;
                    cosine[target] += cosineWeight;
                }
            }
            Require(std::abs(uniformMass - 1) < 4e-4 &&
                std::abs(cosineMass - measure.cosineSliceMass) < 4e-4,
                "shared estimator normalization differs from hemisphere measure");
            for (unsigned index = 0; index < angles.size(); ++index)
            {
                const Float3 direction{ std::sin(angles[index]), 0, std::cos(angles[index]) };
                Require(Near(MapDirectionToUniformSliceMass(direction, measure),
                        float(uniform[index] / uniformMass), 4e-4f) &&
                    Near(MapDirectionToCosineSliceMass(direction, measure),
                        float(cosine[index] / cosineMass), 4e-4f),
                    "shared estimator CDF differs from independent quadrature");
            }
        }
        const auto degenerate = BuildSliceMeasure(view, view, view);
        Require(!degenerate.valid && MapDirectionToUniformSliceMass(view, degenerate) == 0 &&
            MapDirectionToCosineSliceMass(view, degenerate) == 0 &&
            ResolveGtCosineAmbientVisibility({}, degenerate) == 0,
            "degenerate slice fabricated visible mass");
        const auto aligned = BuildSliceMeasure(view, side, view);
        const Float3 invalid{ std::numeric_limits<float>::quiet_NaN(), 0, 1 };
        Require(MapDirectionToUniformSliceMass(invalid, aligned) == 0 &&
            MapDirectionToCosineSliceMass(invalid, aligned) == 0,
            "nonfinite direction fabricated interval mass");
        const auto interval = BuildGtInterval(side, view, aligned);
        Require(Near(interval.minimumAngle01, .5f) && Near(interval.maximumAngle01, 1),
            "uniform interval did not sort its endpoint masses");
        const auto cosineInterval = BuildGtCosineInterval(side, view, aligned);
        Require(Near(cosineInterval.minimumAngle01, .5f) && Near(cosineInterval.maximumAngle01, 1),
            "cosine interval did not sort its endpoint masses");
    }

    void CheckThicknessAndEnergy()
    {
        const Float3 receiver{ 2.5f, -.75f, -4.f }, sample{ 3.5f, .4f, -2.f };
        const Float3 view = VisibilityEstimatorSafeNormalize(-receiver, { 0, 0, 1 });
        const Float3 back = receiver + ComputeBackDelta(receiver, sample, view, .65f, false);
        Require(Near(back, sample + VisibilityEstimatorSafeNormalize(sample, -view) * .65f) &&
            back.z < sample.z && Near(back.x / back.z, sample.x / sample.z) &&
            Near(back.y / back.z, sample.y / sample.z),
            "perspective thickness changed the sampled camera ray");
        Require(Near(receiver + ComputeBackDelta(receiver, sample, { 0, 0, 1 }, .65f, true),
                sample - Float3{ 0, 0, .65f }) &&
            Near(receiver + ComputeBackDelta(receiver, sample, view, -1, false), sample),
            "orthographic or negative thickness changed");
        Require(Near(ComputeGtUniformGiSampleWeight(16, .5f, .25f), .0625f) &&
            Near(ComputeGtCosineGiSampleWeight(16, 1.5f, .25f), .1875f) &&
            ComputeGtUniformGiSampleWeight(32, 1, -1) == 0 &&
            ComputeGtCosineGiSampleWeight(32, 1, -1) == 0 &&
            GetGtUniformIrradianceNormalization() == VisibilityEstimatorTwoPi &&
            GetGtCosineIrradianceNormalization() == VisibilityEstimatorPi,
            "GI lost its estimator-specific measure or source-facing rejection");
        const auto measure = BuildSliceMeasure({ 0, 0, 1 }, { 1, 0, 0 }, { 0, 0, 1 });
        Require(ResolveGtUniformAmbientVisibility({}) == 1 &&
            ResolveGtUniformAmbientVisibility({ 0xffffffffu }) == 0 &&
            Near(ResolveGtCosineAmbientVisibility({ 0x55555555u }, measure), .5f),
            "AO no longer preserves open, closed and half-covered limits");
    }
}

int main()
{
    CheckDirectVisibility();
    CheckLighting();
    CheckShadowEmitters();
    CheckMaterialsAndDebug();
    CheckRayVisibility();
    CheckProjection();
    CheckSectorCoverage();
    CheckSliceMeasures();
    CheckThicknessAndEnergy();
    return EXIT_SUCCESS;
}
