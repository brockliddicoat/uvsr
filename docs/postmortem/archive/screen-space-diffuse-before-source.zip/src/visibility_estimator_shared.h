#ifndef UVSR_VISIBILITY_ESTIMATOR_SHARED_H
#define UVSR_VISIBILITY_ESTIMATOR_SHARED_H

// This header is compiled as both C++ and HLSL. Keep the executable estimator
// equations here so the CPU reference and production shader cannot silently
// drift in sign, CDF, sector-mass, or normalization conventions.

#include "shader_math.h"


static const float VisibilityEstimatorPi = 3.14159265358979323846f;
static const float VisibilityEstimatorTwoPi = 6.28318530717958647692f;
static const float VisibilityEstimatorHalfPi = 1.57079632679489661923f;
static const float VisibilityEstimatorEpsilon = 1e-6f;

struct SliceMeasure
{
    // V points from the receiver toward the camera. S is the positive horizon
    // direction in the slice plane. The receiver normal projected into that
    // plane is cosGamma * V - sinGamma * S; the minus sign is intentional and
    // is the convention used by MapDirectionToUniformSliceMass.
    ShaderFloat3 V;
    ShaderFloat3 S;
    float sinGamma;
    float cosGamma;
    // Length of the receiver normal after projection into the slice. The
    // conditional CDF cancels this factor, but the complete joint cosine
    // measure must restore it when resolving AO and GI across slice azimuths.
    float projectedNormalLength;
    float gamma;
    float cosineSliceMass;
    ShaderUint valid;
};

struct GtIntervalBuildResult
{
    VisibilityInterval interval;
    float frontMass;
    float backMass;
    ShaderUint endpointOrderValid;
};

UVSR_SHADER_INLINE float VisibilityEstimatorLengthSquared(
    ShaderFloat3 value)
{
    return ShaderDot(value, value);
}

UVSR_SHADER_INLINE ShaderFloat3 VisibilityEstimatorSafeNormalize(
    ShaderFloat3 value,
    ShaderFloat3 fallback)
{
    float lengthSquared = VisibilityEstimatorLengthSquared(value);
    if (!(lengthSquared > VisibilityEstimatorEpsilon * VisibilityEstimatorEpsilon) ||
        !ShaderIsFinite(lengthSquared))
    {
        return fallback;
    }

    return value * ShaderRsqrt(lengthSquared);
}

UVSR_SHADER_INLINE SliceMeasure BuildSliceMeasure(
    ShaderFloat3 receiverToCamera,
    ShaderFloat3 positiveSliceDirection,
    ShaderFloat3 receiverNormal)
{
    SliceMeasure measure;
    measure.V = VisibilityEstimatorSafeNormalize(
        receiverToCamera,
        ShaderMakeFloat3(0.0f, 0.0f, -1.0f));

    ShaderFloat3 tangent = positiveSliceDirection -
        measure.V * ShaderDot(positiveSliceDirection, measure.V);
    float tangentLengthSquared = VisibilityEstimatorLengthSquared(tangent);
    measure.S = VisibilityEstimatorSafeNormalize(
        tangent,
        ShaderMakeFloat3(1.0f, 0.0f, 0.0f));

    ShaderFloat3 sliceNormal = VisibilityEstimatorSafeNormalize(
        ShaderCross(measure.V, measure.S),
        ShaderMakeFloat3(0.0f, 1.0f, 0.0f));
    float receiverNormalLengthSquared =
        VisibilityEstimatorLengthSquared(receiverNormal);
    ShaderFloat3 unitReceiverNormal =
        VisibilityEstimatorSafeNormalize(receiverNormal, measure.V);
    ShaderFloat3 projectedNormal = unitReceiverNormal - sliceNormal *
        ShaderDot(unitReceiverNormal, sliceNormal);
    float projectedLengthSquared = VisibilityEstimatorLengthSquared(projectedNormal);

    measure.valid = tangentLengthSquared >
            VisibilityEstimatorEpsilon * VisibilityEstimatorEpsilon &&
        projectedLengthSquared >
            VisibilityEstimatorEpsilon * VisibilityEstimatorEpsilon &&
        receiverNormalLengthSquared >
            VisibilityEstimatorEpsilon * VisibilityEstimatorEpsilon &&
        ShaderIsFinite(tangentLengthSquared) &&
        ShaderIsFinite(projectedLengthSquared) &&
        ShaderIsFinite(receiverNormalLengthSquared) &&
        ShaderIsFinite3(receiverNormal)
        ? 1u
        : 0u;

    measure.projectedNormalLength = 0.0f;
    measure.gamma = 0.0f;
    measure.cosineSliceMass = 0.0f;
    if (measure.valid == 0u)
    {
        measure.sinGamma = 0.0f;
        measure.cosGamma = 1.0f;
        return measure;
    }

    measure.projectedNormalLength =
        ShaderSqrt(projectedLengthSquared);
    projectedNormal *= ShaderRsqrt(projectedLengthSquared);
    measure.cosGamma = ShaderMax(-1.0f,
        ShaderMin(1.0f,
            ShaderDot(projectedNormal, measure.V)));
    measure.sinGamma = ShaderMax(-1.0f,
        ShaderMin(1.0f,
            -ShaderDot(projectedNormal, measure.S)));
    // Visible G-buffer surfaces are expected to be face-forward with respect
    // to V. Preserve Uniform Solid Angle's historical behavior for malformed
    // normals,
    // but make their joint-cosine mass zero instead of integrating a wrapped
    // hemisphere with invalid sector semantics.
    if (measure.cosGamma >= 0.0f)
    {
        measure.gamma = ShaderAtan2(
            measure.sinGamma, measure.cosGamma);
        float conditionalMass = measure.cosGamma +
            measure.gamma * measure.sinGamma;
        measure.cosineSliceMass = measure.projectedNormalLength *
            ShaderMax(conditionalMass, 0.0f);
    }
    return measure;
}

UVSR_SHADER_INLINE ShaderFloat3 ComputeBackDelta(
    ShaderFloat3 receiverPositionVS,
    ShaderFloat3 samplePositionVS,
    ShaderFloat3 receiverToCamera,
    float thickness,
    bool orthographic)
{
    ShaderFloat3 awayFromCamera = orthographic
        ? -receiverToCamera
        : VisibilityEstimatorSafeNormalize(samplePositionVS, -receiverToCamera);
    ShaderFloat3 sampleBackPositionVS = samplePositionVS +
        awayFromCamera * ShaderMax(thickness, 0.0f);
    return sampleBackPositionVS - receiverPositionVS;
}

UVSR_SHADER_INLINE float MapDirectionToUniformSliceMass(
    ShaderFloat3 direction,
    SliceMeasure measure)
{
    if (measure.valid == 0u || !ShaderIsFinite3(direction))
        return 0.0f;

    ShaderFloat3 unitDirection = VisibilityEstimatorSafeNormalize(
        direction, measure.V);
    float horizonCosine = ShaderMax(-1.0f,
        ShaderMin(1.0f,
            ShaderDot(unitDirection, measure.V)));
    float side = ShaderDot(unitDirection, measure.S) >= 0.0f
        ? 1.0f
        : -1.0f;

    // This is the closed-form CDF of uniform solid-angle measure over the
    // receiver hemisphere, restricted to the current bidirectional slice:
    // F = 1/2 * (1 + sinGamma + side * (1 - cos(theta))). Because theta is
    // represented by its cosine, no acos is required.
    return ShaderSaturate(0.5f *
        (1.0f + measure.sinGamma + side * (1.0f - horizonCosine)));
}

UVSR_SHADER_INLINE ShaderUint GtUniformEndpointOrderIsConsistent(
    ShaderFloat3 frontDirection,
    ShaderFloat3 backDirection,
    SliceMeasure measure,
    float frontMass,
    float backMass)
{
    float frontSide = ShaderDot(frontDirection, measure.S);
    float backSide = ShaderDot(backDirection, measure.S);
    if (frontSide * backSide < 0.0f ||
        ShaderAbs(frontSide) <= VisibilityEstimatorEpsilon ||
        ShaderAbs(backSide) <= VisibilityEstimatorEpsilon)
    {
        // Crossing the view direction is valid but has no single-side ordering
        // invariant. The sorted interval remains the authoritative behavior.
        return 1u;
    }

    bool ordered = frontSide > 0.0f
        ? frontMass <= backMass + VisibilityEstimatorEpsilon
        : backMass <= frontMass + VisibilityEstimatorEpsilon;
    return ordered ? 1u : 0u;
}

UVSR_SHADER_INLINE GtIntervalBuildResult BuildGtIntervalDetails(
    ShaderFloat3 frontDirection,
    ShaderFloat3 backDirection,
    SliceMeasure measure)
{
    GtIntervalBuildResult result;
    result.frontMass = MapDirectionToUniformSliceMass(frontDirection, measure);
    result.backMass = MapDirectionToUniformSliceMass(backDirection, measure);
    result.interval = MakeVisibilityInterval(
        ShaderMin(result.frontMass, result.backMass),
        ShaderMax(result.frontMass, result.backMass));
    result.endpointOrderValid = GtUniformEndpointOrderIsConsistent(
        frontDirection,
        backDirection,
        measure,
        result.frontMass,
        result.backMass);
    return result;
}

UVSR_SHADER_INLINE VisibilityInterval BuildGtInterval(
    ShaderFloat3 frontDirection,
    ShaderFloat3 backDirection,
    SliceMeasure measure)
{
    return BuildGtIntervalDetails(frontDirection, backDirection, measure).interval;
}

UVSR_SHADER_INLINE float ResolveGtUniformAmbientVisibility(
    RadialVisibilityMask mask)
{
    return GetSliceVisibility(mask);
}

UVSR_SHADER_INLINE float CosineSliceAntiderivative(
    float signedAngle,
    float sinGamma,
    float cosGamma)
{
    float sinAngle = ShaderSin(signedAngle);
    float sinDoubleAngle = ShaderSin(2.0f * signedAngle);
    float positiveSide = 0.5f * cosGamma * sinAngle * sinAngle -
        0.5f * sinGamma * signedAngle +
        0.25f * sinGamma * sinDoubleAngle;
    float negativeSide = -0.5f * cosGamma * sinAngle * sinAngle +
        0.5f * sinGamma * signedAngle -
        0.25f * sinGamma * sinDoubleAngle;
    return signedAngle >= 0.0f ? positiveSide : negativeSide;
}

UVSR_SHADER_INLINE float MapDirectionToCosineSliceMass(
    ShaderFloat3 direction,
    SliceMeasure measure)
{
    if (measure.valid == 0u || !(measure.cosGamma >= 0.0f) ||
        !(measure.cosineSliceMass > VisibilityEstimatorEpsilon) ||
        !ShaderIsFinite3(direction))
    {
        return 0.0f;
    }

    ShaderFloat3 unitDirection = VisibilityEstimatorSafeNormalize(
        direction, measure.V);
    float signedAngle = ShaderAtan2(
        ShaderDot(unitDirection, measure.S),
        ShaderDot(unitDirection, measure.V));
    float minimumAngle = -VisibilityEstimatorHalfPi - measure.gamma;
    float maximumAngle = VisibilityEstimatorHalfPi - measure.gamma;
    signedAngle = ShaderMax(minimumAngle,
        ShaderMin(maximumAngle, signedAngle));

    float lowerIntegral = CosineSliceAntiderivative(
        minimumAngle, measure.sinGamma, measure.cosGamma);
    float conditionalMass = measure.cosGamma +
        measure.gamma * measure.sinGamma;
    float accumulatedMass = CosineSliceAntiderivative(
        signedAngle, measure.sinGamma, measure.cosGamma) - lowerIntegral;
    return ShaderSaturate(accumulatedMass /
        ShaderMax(conditionalMass, VisibilityEstimatorEpsilon));
}

UVSR_SHADER_INLINE GtIntervalBuildResult BuildGtCosineIntervalDetails(
    ShaderFloat3 frontDirection,
    ShaderFloat3 backDirection,
    SliceMeasure measure)
{
    GtIntervalBuildResult result;
    result.frontMass = MapDirectionToCosineSliceMass(frontDirection, measure);
    result.backMass = MapDirectionToCosineSliceMass(backDirection, measure);
    result.interval = MakeVisibilityInterval(
        ShaderMin(result.frontMass, result.backMass),
        ShaderMax(result.frontMass, result.backMass));
    result.endpointOrderValid = GtUniformEndpointOrderIsConsistent(
        frontDirection,
        backDirection,
        measure,
        result.frontMass,
        result.backMass);
    return result;
}

UVSR_SHADER_INLINE VisibilityInterval BuildGtCosineInterval(
    ShaderFloat3 frontDirection,
    ShaderFloat3 backDirection,
    SliceMeasure measure)
{
    return BuildGtCosineIntervalDetails(
        frontDirection, backDirection, measure).interval;
}

UVSR_SHADER_INLINE float ResolveGtCosineAmbientVisibility(
    RadialVisibilityMask mask,
    SliceMeasure measure)
{
    // The mask fraction is conditional on the current slice. Multiplying by
    // the projected slice mass restores the joint cosine measure before the
    // uniform azimuth Monte Carlo average.
    return GetSliceVisibility(mask) * measure.cosineSliceMass;
}

UVSR_SHADER_INLINE float ComputeGtUniformGiSampleWeight(
    ShaderUint newlyCoveredSectorCount,
    float receiverCosine,
    float sourceFacingCosine)
{
    float coveredMass = ShaderMin(
        float(newlyCoveredSectorCount),
        float(RadialVisibilitySectorCount)) /
        float(RadialVisibilitySectorCount);
    return coveredMass * ShaderSaturate(receiverCosine) *
        ShaderSaturate(sourceFacingCosine);
}

UVSR_SHADER_INLINE float GetGtUniformIrradianceNormalization()
{
    // Equal-mass Uniform Solid Angle sectors sample p(omega)=1/(2*pi) on the
    // receiver hemisphere. Diffuse irradiance therefore multiplies their mean
    // L_i * cos(theta_receiver) by 2*pi. Cosine-Weighted Solid Angle uses a
    // different CDF and omits this receiver cosine rather than reusing this
    // normalization.
    return VisibilityEstimatorTwoPi;
}

UVSR_SHADER_INLINE float ComputeGtCosineGiSampleWeight(
    ShaderUint newlyCoveredSectorCount,
    float cosineSliceMass,
    float sourceFacingCosine)
{
    float coveredMass = ShaderMin(
        float(newlyCoveredSectorCount),
        float(RadialVisibilitySectorCount)) /
        float(RadialVisibilitySectorCount);
    // Receiver cosine is already in the CDF and slice mass. Applying it again
    // would square the Lambertian term. Source-facing cosine remains part of
    // the finite-screen emitter approximation.
    return coveredMass * ShaderMax(cosineSliceMass, 0.0f) *
        ShaderSaturate(sourceFacingCosine);
}

UVSR_SHADER_INLINE float GetGtCosineIrradianceNormalization()
{
    // Slice azimuth is sampled uniformly over [0, pi). The receiver cosine is
    // already included in each conditional sector, leaving only the outer pi
    // Monte Carlo normalization.
    return VisibilityEstimatorPi;
}


#endif // UVSR_VISIBILITY_ESTIMATOR_SHARED_H
