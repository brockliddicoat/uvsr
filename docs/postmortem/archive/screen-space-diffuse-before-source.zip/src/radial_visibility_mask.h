#pragma once

// The shader scanner never follows this CPU adapter. Domain equations remain in the HLSL owner.
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace radial_visibility_detail
{
    using uint = std::uint32_t;
    using std::clamp;
    using std::floor;
    using std::isfinite;
    using std::min;
    using std::max;
    inline float saturate(float value) { return std::clamp(value, 0.f, 1.f); }
    inline float frac(float value) { return value - std::floor(value); }
    inline uint countbits(uint bits)
    {
        uint count = 0;
        for (; bits; bits &= bits - 1)
            ++count;
        return count;
    }
#include "radial_visibility_mask.hlsli"
}

using radial_visibility_detail::RadialVisibilitySectorCount;
using radial_visibility_detail::VisibilityInterval;
using radial_visibility_detail::RadialVisibilityMask;
using radial_visibility_detail::MakeVisibilityInterval;
using radial_visibility_detail::MakeStochasticSectorRangeMask;
using radial_visibility_detail::AccumulateOccluder;
using radial_visibility_detail::CountOccludedSectors;
using radial_visibility_detail::GetSliceVisibility;
