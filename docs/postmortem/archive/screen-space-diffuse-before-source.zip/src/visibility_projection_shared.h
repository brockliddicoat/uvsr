#ifndef UVSR_VISIBILITY_PROJECTION_SHARED_H
#define UVSR_VISIBILITY_PROJECTION_SHARED_H

// Compiled as both C++ and HLSL. The inputs are homogeneous D3D clip-space
// z/w values for a visible receiver and a desired radial endpoint. The result
// clips their segment once against the active near plane and positive-w domain.

#include "shader_math.h"

static const float VisibilityProjectionEpsilon = 1e-6f;
static const float VisibilityProjectionClipInset = 1e-5f;

struct VisibilityProjectionClipResult
{
    float endpointScale;
    ShaderUint valid;
    ShaderUint clipped;
};

UVSR_SHADER_INLINE float VisibilityProjectionNearDistance(
    float clipZ,
    float clipW,
    bool reverseDepth)
{
    // D3D NDC depth is [0, 1]. Forward depth reaches the near plane at z=0;
    // reverse depth reaches it at z=w.
    return reverseDepth ? clipW - clipZ : clipZ;
}

UVSR_SHADER_INLINE VisibilityProjectionClipResult
ComputeVisibilityProjectionEndpointClip(
    float receiverClipZ,
    float receiverClipW,
    float endpointClipZ,
    float endpointClipW,
    bool reverseDepth)
{
    VisibilityProjectionClipResult result;
    result.endpointScale = 0.0f;
    result.valid = 0u;
    result.clipped = 0u;

    if (!ShaderIsFinite(receiverClipZ) ||
        !ShaderIsFinite(receiverClipW) ||
        !ShaderIsFinite(endpointClipZ) ||
        !ShaderIsFinite(endpointClipW) ||
        !(receiverClipW > VisibilityProjectionEpsilon))
    {
        return result;
    }

    float receiverNearDistance = VisibilityProjectionNearDistance(
        receiverClipZ, receiverClipW, reverseDepth);
    float endpointNearDistance = VisibilityProjectionNearDistance(
        endpointClipZ, endpointClipW, reverseDepth);
    if (!ShaderIsFinite(receiverNearDistance) ||
        !ShaderIsFinite(endpointNearDistance) ||
        receiverNearDistance < -VisibilityProjectionEpsilon)
    {
        return result;
    }
    receiverNearDistance = ShaderMax(receiverNearDistance, 0.0f);

    float endpointScale = 1.0f;
    if (endpointClipW <= VisibilityProjectionEpsilon)
    {
        float denominator = receiverClipW - endpointClipW;
        if (!(denominator > VisibilityProjectionEpsilon) ||
            !ShaderIsFinite(denominator))
        {
            return result;
        }

        // Clip to a strictly positive w so the final perspective divide cannot
        // land exactly on the projection singularity.
        float positiveWScale =
            (receiverClipW - 2.0f * VisibilityProjectionEpsilon) /
            denominator;
        endpointScale = ShaderMin(
            endpointScale, positiveWScale);
        result.clipped = 1u;
    }

    if (endpointNearDistance < 0.0f)
    {
        float denominator = receiverNearDistance - endpointNearDistance;
        if (!(denominator > VisibilityProjectionEpsilon) ||
            !ShaderIsFinite(denominator))
        {
            return result;
        }

        float nearPlaneScale = receiverNearDistance / denominator;
        endpointScale = ShaderMin(endpointScale, nearPlaneScale);
        result.clipped = 1u;
    }

    endpointScale = ShaderMax(
        ShaderMin(endpointScale, 1.0f), 0.0f);
    if (result.clipped != 0u)
    {
        // Move a tiny amount toward the already-valid receiver. This keeps the
        // reconstructed endpoint inside both half-spaces after float rounding.
        endpointScale *= 1.0f - VisibilityProjectionClipInset;
    }

    float clippedW = receiverClipW +
        (endpointClipW - receiverClipW) * endpointScale;
    float clippedZ = receiverClipZ +
        (endpointClipZ - receiverClipZ) * endpointScale;
    float clippedNearDistance = VisibilityProjectionNearDistance(
        clippedZ, clippedW, reverseDepth);
    if (!ShaderIsFinite(clippedW) ||
        !ShaderIsFinite(clippedZ) ||
        !ShaderIsFinite(clippedNearDistance) ||
        !(clippedW > VisibilityProjectionEpsilon) ||
        clippedNearDistance < -VisibilityProjectionEpsilon)
    {
        return result;
    }

    result.endpointScale = endpointScale;
    result.valid = 1u;
    return result;
}


#endif // UVSR_VISIBILITY_PROJECTION_SHARED_H
