#include "screen_space_visibility.h"
#include "renderer_common_passes.h"
#include "renderer_environment_bindings.h"
#include "renderer_shader_factory.h"
#include "visibility_scheduler_contract.h"
#include "visibility_pipeline_contract.h"

#include <donut/engine/View.h>

#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstddef>
#include <string>
#include <utility>
#include <vector>

using namespace donut;
using namespace donut::engine;
using namespace donut::math;

#include "screen_space_visibility_cb.h"

static_assert(
    offsetof(ScreenSpaceVisibilityConstants, sourceRadianceAvailable) ==
        offsetof(ScreenSpaceVisibilityConstants, ambientStrength) + 16u);
static_assert(
    offsetof(ScreenSpaceVisibilityConstants, diffuseEnvironmentEnabled) ==
        offsetof(ScreenSpaceVisibilityConstants, orthographicProjection) +
            16u);
static_assert(
    offsetof(ScreenSpaceVisibilityConstants, skyVisibilityApplication) +
            16u ==
        sizeof(ScreenSpaceVisibilityConstants));
static_assert(
    sizeof(ScreenSpaceVisibilityConstants) ==
        sizeof(PlanarViewConstants) + 128u,
    "Visibility constants must occupy eight registers after the view.");
static_assert(sizeof(ScreenSpaceVisibilityConstants) % 16u == 0u);
static_assert(static_cast<uint32_t>(
    uvsr::NoisePattern::SpatialWhite) == 0u);
static_assert(static_cast<uint32_t>(
    uvsr::NoisePattern::SpatialBlue) == 1u);
static_assert(static_cast<uint32_t>(
    uvsr::NoisePattern::SpatiotemporalBlue) == 2u);
static_assert(static_cast<uint32_t>(
    uvsr::VisibilityEstimator::UniformSolidAngle) ==
        uvsr::VisibilitySchedulerParityEstimatorIndex);
namespace
{
    constexpr uint32_t kThreadGroupSize = 8u;

    uint32_t GetResolutionScale(uvsr::VisibilityResolution resolution)
    {
        switch (resolution)
        {
        case uvsr::VisibilityResolution::Half: return 2u;
        case uvsr::VisibilityResolution::Quarter: return 4u;
        default: return 1u;
        }
    }

    uint32_t GetConsumerVariant(bool ambientEnabled, bool indirectEnabled)
    {
        assert(ambientEnabled || indirectEnabled);
        if (ambientEnabled)
            return indirectEnabled ? 2u : 0u;
        return 1u;
    }

    uint64_t TextureBytes(uint2 size, uint32_t bytesPerPixel)
    {
        return uint64_t(size.x) * uint64_t(size.y) * bytesPerPixel;
    }

    uint64_t TracePipelineKey(
        uint32_t estimator,
        uint32_t consumer,
        uint32_t runtimeSampleParity)
    {
        return 0x1000000000000000ull |
            uint64_t(estimator) |
            (uint64_t(consumer) << 2u) |
            (uint64_t(runtimeSampleParity) << 4u);
    }

    bool IsSkyVisibilityTextureCompatible(
        nvrhi::ITexture* texture,
        uint2 fullSize)
    {
        if (!texture)
            return false;

        const nvrhi::TextureDesc& description = texture->getDesc();
        return description.width == fullSize.x &&
            description.height == fullSize.y &&
            description.depth == 1u &&
            description.arraySize == 1u &&
            description.mipLevels == 1u &&
            description.sampleCount == 1u &&
            (description.format == nvrhi::Format::R8_UNORM ||
                description.format == nvrhi::Format::R16_FLOAT ||
                description.format == nvrhi::Format::RGBA16_FLOAT) &&
            description.dimension == nvrhi::TextureDimension::Texture2D &&
            description.isShaderResource;
    }


}

namespace uvsr
{
    void ApplyVisibilityBufferPrecisionPreset(
        VisibilityBufferPrecisionSettings& settings,
        bool use16BitAo,
        bool use16BitGi)
    {
        const VisibilityScalarBufferPrecision ambientPrecision = use16BitAo
            ? VisibilityScalarBufferPrecision::Float16
            : VisibilityScalarBufferPrecision::Float32;
        const VisibilityVectorBufferPrecision indirectPrecision = use16BitGi
            ? VisibilityVectorBufferPrecision::Rgba16Float
            : VisibilityVectorBufferPrecision::Rgba32Float;

        settings.ambient = ambientPrecision;
        settings.indirect = indirectPrecision;
    }

    ScreenSpaceVisibilitySettings::ScreenSpaceVisibilitySettings()
    {
        ApplyScreenSpaceVisibilityQualityPreset(
            *this, ScreenSpaceVisibilityQuality::High);
    }

    void MarkScreenSpaceVisibilityQualityCustom(
        ScreenSpaceVisibilitySettings& settings)
    {
        if (settings.quality != ScreenSpaceVisibilityQuality::Custom)
            settings.qualityPresetOrigin = settings.quality;
        settings.quality = ScreenSpaceVisibilityQuality::Custom;
    }

    void ApplyScreenSpaceVisibilityQualityPreset(
        ScreenSpaceVisibilitySettings& settings,
        ScreenSpaceVisibilityQuality quality)
    {
        if (quality == ScreenSpaceVisibilityQuality::Custom)
        {
            MarkScreenSpaceVisibilityQualityCustom(settings);
            return;
        }

        settings.enabled = true;
        settings.estimator = VisibilityEstimator::UniformSolidAngle;
        settings.resolution = VisibilityResolution::Full;
        settings.sampling.maximumSampleCount =
            DefaultVisibilitySampleCount;
        settings.sampling.radius = 3.f;
        settings.sampling.thickness = 0.5f;
        settings.sampling.stepDistributionExponent = 2.f;
        settings.ambientOcclusion = {};
        settings.indirectDiffuse = {};
        const bool use16BitBuffers =
            quality != ScreenSpaceVisibilityQuality::Ultra;
        ApplyVisibilityBufferPrecisionPreset(
            settings.bufferPrecision,
            use16BitBuffers,
            use16BitBuffers);

        switch (quality)
        {
        case ScreenSpaceVisibilityQuality::Low:
            settings.resolution = VisibilityResolution::Quarter;
            settings.estimator = VisibilityEstimator::UniformProjectedAngle;
            settings.sampling.maximumSampleCount = 8u;
            break;
        case ScreenSpaceVisibilityQuality::Medium:
            settings.resolution = VisibilityResolution::Half;
            settings.sampling.maximumSampleCount = 8u;
            break;
        case ScreenSpaceVisibilityQuality::High:
            break;
        case ScreenSpaceVisibilityQuality::Ultra:
            settings.sampling.maximumSampleCount = 48u;
            break;
        default:
            break;
        }

        settings.qualityPresetOrigin = quality;
        settings.quality = quality;
    }

    bool MatchesScreenSpaceVisibilityQualityPreset(
        const ScreenSpaceVisibilitySettings& settings,
        ScreenSpaceVisibilityQuality quality)
    {
        if (quality == ScreenSpaceVisibilityQuality::Custom)
            return false;

        ScreenSpaceVisibilitySettings preset;
        ApplyScreenSpaceVisibilityQualityPreset(preset, quality);

        const auto& leftBuffers = settings.bufferPrecision;
        const auto& rightBuffers = preset.bufferPrecision;
        return settings.enabled == preset.enabled &&
            settings.estimator == preset.estimator &&
            settings.resolution == preset.resolution &&
            settings.sampling.maximumSampleCount ==
                preset.sampling.maximumSampleCount &&
            settings.sampling.radius == preset.sampling.radius &&
            settings.sampling.thickness == preset.sampling.thickness &&
            settings.sampling.stepDistributionExponent ==
                preset.sampling.stepDistributionExponent &&
            settings.ambientOcclusion.enabled ==
                preset.ambientOcclusion.enabled &&
            settings.ambientOcclusion.strength ==
                preset.ambientOcclusion.strength &&
            settings.indirectDiffuse.enabled ==
                preset.indirectDiffuse.enabled &&
            settings.indirectDiffuse.intensity ==
                preset.indirectDiffuse.intensity &&
            leftBuffers.ambient == rightBuffers.ambient &&
            leftBuffers.indirect == rightBuffers.indirect;
    }

    void ReconcileScreenSpaceVisibilityQualityPreset(
        ScreenSpaceVisibilitySettings& settings)
    {
        ScreenSpaceVisibilityQuality origin =
            settings.quality == ScreenSpaceVisibilityQuality::Custom
            ? settings.qualityPresetOrigin
            : settings.quality;
        if (origin == ScreenSpaceVisibilityQuality::Custom)
            origin = ScreenSpaceVisibilityQuality::High;

        if (MatchesScreenSpaceVisibilityQualityPreset(settings, origin))
            ApplyScreenSpaceVisibilityQualityPreset(settings, origin);
        else
        {
            settings.qualityPresetOrigin = origin;
            settings.quality = ScreenSpaceVisibilityQuality::Custom;
        }
    }

    ScreenSpaceVisibilityPass::ScreenSpaceVisibilityPass(
        nvrhi::IDevice* device,
        const std::shared_ptr<RendererShaderFactory>& shaderFactory,
        std::shared_ptr<RendererCommonPasses> commonPasses,
        bool deferPipelineCreation)
        : m_Device(device)
        , m_ShaderFactory(shaderFactory)
        , m_CommonPasses(std::move(commonPasses))
    {
        nvrhi::BufferDesc constantBufferDesc;
        constantBufferDesc.byteSize = sizeof(ScreenSpaceVisibilityConstants);
        constantBufferDesc.debugName = "ScreenSpaceVisibility/Constants";
        constantBufferDesc.isConstantBuffer = true;
        constantBufferDesc.isVolatile = true;
        constantBufferDesc.maxVersions =
            RendererMaxConstantBufferVersions;
        m_ConstantBuffer = device->createBuffer(constantBufferDesc);

        const auto createDummyTexture = [device](
            nvrhi::Format format,
            const char* debugName)
        {
            nvrhi::TextureDesc desc;
            desc.width = 1u;
            desc.height = 1u;
            desc.format = format;
            desc.dimension = nvrhi::TextureDimension::Texture2D;
            desc.mipLevels = 1u;
            desc.initialState = nvrhi::ResourceStates::ShaderResource;
            desc.keepInitialState = true;
            desc.debugName = debugName;
            return device->createTexture(desc);
        };
        m_DummyAmbientVisibility = createDummyTexture(
            nvrhi::Format::R16_FLOAT,
            "ScreenSpaceVisibility/DummyAmbientVisibility");
        m_DummyIndirectDiffuse = createDummyTexture(
            nvrhi::Format::RGBA16_FLOAT,
            "ScreenSpaceVisibility/DummyIndirectDiffuse");

        if (!deferPipelineCreation)
        {
            while (!m_PipelinesReady && !m_PipelineCreationFailed)
            {
                if (PreparePipelinesStep())
                    break;
            }
        }

        for (auto& stageQueries : m_TimerQueries)
            for (nvrhi::TimerQueryHandle& query : stageQueries)
                query = device->createTimerQuery();
    }

    bool ScreenSpaceVisibilityPass::PreparePipelinesStep()
    {
        if (m_PipelinesReady)
            return true;
        if (m_PipelineCreationFailed)
            return false;

        const auto createPipeline = [this](
            Pipeline& destination,
            const char* shaderName,
            const std::vector<nvrhi::BindingLayoutItem>& bindings,
            const std::vector<RendererShaderMacro>* macros = nullptr)
        {
            destination = {};
            destination.shader = m_ShaderFactory->CreateShader(
                shaderName, "main", macros, nvrhi::ShaderType::Compute);
            if (!destination.shader)
                return false;
            nvrhi::BindingLayoutDesc layoutDesc;
            layoutDesc.visibility = nvrhi::ShaderType::Compute;
            layoutDesc.bindings = bindings;
            destination.bindingLayout =
                m_Device->createBindingLayout(layoutDesc);
            if (!destination.bindingLayout)
                return false;
            nvrhi::ComputePipelineDesc pipelineDesc;
            pipelineDesc.CS = destination.shader;
            pipelineDesc.bindingLayouts = { destination.bindingLayout };
            destination.pipeline =
                m_Device->createComputePipeline(pipelineDesc);
            return destination.IsValid();
        };

        bool created = false;

        if (m_PipelinePreparationStep < c_ConsumerVariantCount)
        {
            const uint32_t consumer = m_PipelinePreparationStep;
            const bool ambientEnabled = consumer != 1u;
            const bool indirectEnabled = consumer != 0u;
            std::vector<RendererShaderMacro> macros = {
                { "ENABLE_AO", ambientEnabled ? "1" : "0" },
                { "ENABLE_GI", indirectEnabled ? "1" : "0" }
            };
            std::vector<nvrhi::BindingLayoutItem> layout = {
                nvrhi::BindingLayoutItem::VolatileConstantBuffer(0)
            };
            if (ambientEnabled)
                layout.push_back(nvrhi::BindingLayoutItem::Texture_SRV(0));
            if (indirectEnabled)
                layout.push_back(nvrhi::BindingLayoutItem::Texture_SRV(1));
            layout.push_back(nvrhi::BindingLayoutItem::Texture_SRV(2));
            layout.push_back(nvrhi::BindingLayoutItem::Texture_SRV(3));
            if (ambientEnabled)
                layout.push_back(nvrhi::BindingLayoutItem::Texture_UAV(0));
            if (indirectEnabled)
                layout.push_back(nvrhi::BindingLayoutItem::Texture_UAV(1));
            created = createPipeline(
                m_Filter[consumer],
                "uvsr/screen_space_visibility_filter_cs.hlsl",
                layout,
                &macros);
        }
        else
        {
            created = createPipeline(
                m_Composite,
                "uvsr/screen_space_indirect_composite_cs.hlsl",
                {
                    nvrhi::BindingLayoutItem::VolatileConstantBuffer(0),
                    nvrhi::BindingLayoutItem::Texture_SRV(0),
                    nvrhi::BindingLayoutItem::Texture_SRV(1),
                    nvrhi::BindingLayoutItem::Texture_SRV(2),
                    nvrhi::BindingLayoutItem::Texture_SRV(3),
                    nvrhi::BindingLayoutItem::Texture_SRV(4),
                    nvrhi::BindingLayoutItem::Texture_SRV(5),
                    nvrhi::BindingLayoutItem::Texture_SRV(6),
                    nvrhi::BindingLayoutItem::Texture_SRV(
                        ScreenSpaceCompositeDiffuseEnvironmentSlot),
                    nvrhi::BindingLayoutItem::Texture_SRV(8),
                    nvrhi::BindingLayoutItem::Texture_SRV(9),
                    nvrhi::BindingLayoutItem::Texture_SRV(
                        ScreenSpaceCompositeSpecularEnvironmentSlot),
                    nvrhi::BindingLayoutItem::Texture_SRV(
                        ScreenSpaceCompositeEnvironmentBrdfSlot),
                    nvrhi::BindingLayoutItem::Texture_SRV(
                        ScreenSpaceCompositeSkyVisibilitySlot),
                    nvrhi::BindingLayoutItem::Texture_UAV(0),
                    nvrhi::BindingLayoutItem::Sampler(0),
                    nvrhi::BindingLayoutItem::Sampler(1)
                });
        }

        VisibilityPipelinePreparationState state{
            m_PipelinePreparationStep, m_PipelineCreationFailed };
        m_PipelinesReady = CommitVisibilityPipelineCreation(
            state, created, created, created, 4u);
        m_PipelinePreparationStep = state.completedPipelines;
        m_PipelineCreationFailed = state.failed;
        return m_PipelinesReady;
    }

    ScreenSpaceVisibilityPass::Pipeline*
        ScreenSpaceVisibilityPass::GetOrCreateAdvancedPipeline(
            uint64_t key,
            const char* shaderName,
            const std::vector<nvrhi::BindingLayoutItem>& bindings,
            const std::vector<RendererShaderMacro>* macros)
    {
        const auto existing = m_AdvancedPipelines.find(key);
        if (existing != m_AdvancedPipelines.end())
            return existing->second.IsValid() ? &existing->second : nullptr;

        Pipeline pipeline;
        pipeline.shader = m_ShaderFactory->CreateShader(
            shaderName, "main", macros, nvrhi::ShaderType::Compute);
        if (!pipeline.shader)
            return nullptr;
        nvrhi::BindingLayoutDesc layoutDesc;
        layoutDesc.visibility = nvrhi::ShaderType::Compute;
        layoutDesc.bindings = bindings;
        pipeline.bindingLayout = m_Device->createBindingLayout(layoutDesc);
        if (!pipeline.bindingLayout)
            return nullptr;
        nvrhi::ComputePipelineDesc pipelineDesc;
        pipelineDesc.CS = pipeline.shader;
        pipelineDesc.bindingLayouts = { pipeline.bindingLayout };
        pipeline.pipeline = m_Device->createComputePipeline(pipelineDesc);
        if (!pipeline.IsValid())
            return nullptr;
        return &m_AdvancedPipelines.emplace(key, std::move(pipeline))
            .first->second;
    }

    void ScreenSpaceVisibilityPass::EnsureResources(
        uint2 fullSize,
        uint32_t resolutionScale,
        bool ambientEnabled,
        bool indirectDiffuseEnabled,
        bool upsampleEnabled,
        const VisibilityBufferPrecisionSettings& bufferPrecision)
    {
        resolutionScale = std::clamp(resolutionScale, 1u, 4u);
        const uint2 samplingSize(
            (fullSize.x + resolutionScale - 1u) / resolutionScale,
            (fullSize.y + resolutionScale - 1u) / resolutionScale);
        const uint64_t bufferPrecisionKey =
            uint64_t(bufferPrecision.ambient) |
            (uint64_t(bufferPrecision.indirect) << 2u);

        if (all(m_FullSize == fullSize) &&
            all(m_SamplingSize == samplingSize) &&
            m_ResolutionScale == resolutionScale &&
            m_AmbientResourcesEnabled == ambientEnabled &&
            m_IndirectDiffuseResourcesEnabled == indirectDiffuseEnabled &&
            m_UpsampleResourcesEnabled == upsampleEnabled &&
            m_BufferPrecisionConfigurationKey == bufferPrecisionKey &&
            (!ambientEnabled || m_RawAmbientVisibility) &&
            (!indirectDiffuseEnabled || m_RawIndirectDiffuse) &&
            (!upsampleEnabled || !ambientEnabled ||
                m_FinalAmbientVisibility) &&
            (!upsampleEnabled || !indirectDiffuseEnabled ||
                m_FinalIndirectDiffuse))
        {
            return;
        }

        ReleaseResources();
        m_FullSize = fullSize;
        m_SamplingSize = samplingSize;
        m_ResolutionScale = resolutionScale;
        m_AmbientResourcesEnabled = ambientEnabled;
        m_IndirectDiffuseResourcesEnabled = indirectDiffuseEnabled;
        m_UpsampleResourcesEnabled = upsampleEnabled;
        m_BufferPrecisionConfigurationKey = bufferPrecisionKey;

        const auto scalarFormat = [](VisibilityScalarBufferPrecision precision)
        {
            return precision == VisibilityScalarBufferPrecision::Float32
                ? nvrhi::Format::R32_FLOAT
                : nvrhi::Format::R16_FLOAT;
        };
        const auto vectorFormat = [](VisibilityVectorBufferPrecision precision)
        {
            return precision == VisibilityVectorBufferPrecision::Rgba32Float
                ? nvrhi::Format::RGBA32_FLOAT
                : nvrhi::Format::RGBA16_FLOAT;
        };
        const auto scalarBytes = [](VisibilityScalarBufferPrecision precision)
        {
            return precision == VisibilityScalarBufferPrecision::Float32
                ? 4u
                : 2u;
        };
        const auto vectorBytes = [](VisibilityVectorBufferPrecision precision)
        {
            return precision == VisibilityVectorBufferPrecision::Rgba32Float
                ? 16u
                : 8u;
        };
        const auto createTexture = [this](
            uint2 size,
            nvrhi::Format format,
            const char* debugName)
        {
            nvrhi::TextureDesc desc;
            desc.width = size.x;
            desc.height = size.y;
            desc.format = format;
            desc.dimension = nvrhi::TextureDimension::Texture2D;
            desc.mipLevels = 1u;
            desc.isUAV = true;
            desc.initialState = nvrhi::ResourceStates::ShaderResource;
            desc.keepInitialState = true;
            desc.debugName = debugName;
            return m_Device->createTexture(desc);
        };

        if (ambientEnabled)
        {
            m_RawAmbientVisibility = createTexture(
                samplingSize,
                scalarFormat(bufferPrecision.ambient),
                "ScreenSpaceVisibility/RawAmbientVisibility");
        }
        if (indirectDiffuseEnabled)
        {
            m_RawIndirectDiffuse = createTexture(
                samplingSize,
                vectorFormat(bufferPrecision.indirect),
                "ScreenSpaceVisibility/RawIndirectDiffuse");
        }


        if (upsampleEnabled && ambientEnabled)
        {
            m_FinalAmbientVisibility = createTexture(
                fullSize,
                scalarFormat(bufferPrecision.ambient),
                "ScreenSpaceVisibility/FinalAmbientVisibility");
        }
        if (upsampleEnabled && indirectDiffuseEnabled)
        {
            m_FinalIndirectDiffuse = createTexture(
                fullSize,
                vectorFormat(bufferPrecision.indirect),
                "ScreenSpaceVisibility/FinalIndirectDiffuse");
        }
        const uint64_t rawAmbientBytes = TextureBytes(
            samplingSize, scalarBytes(bufferPrecision.ambient));
        const uint64_t rawIndirectBytes = TextureBytes(
            samplingSize, vectorBytes(bufferPrecision.indirect));
        const uint64_t finalAmbientBytes = TextureBytes(
            fullSize, scalarBytes(bufferPrecision.ambient));
        const uint64_t finalIndirectBytes = TextureBytes(
            fullSize, vectorBytes(bufferPrecision.indirect));
        m_Timings.outputTextureBytes =
            (ambientEnabled ? rawAmbientBytes : 0u) +
            (indirectDiffuseEnabled ? rawIndirectBytes : 0u) +
            (upsampleEnabled && ambientEnabled
                ? finalAmbientBytes : 0u) +
            (upsampleEnabled && indirectDiffuseEnabled
                ? finalIndirectBytes : 0u);
        m_Timings.workingTextureBytes = 0u;
    }

    void ScreenSpaceVisibilityPass::ReleaseResources()
    {
        ResetBindingCache();
        m_RawAmbientVisibility = nullptr;
        m_RawIndirectDiffuse = nullptr;
        m_FinalAmbientVisibility = nullptr;
        m_FinalIndirectDiffuse = nullptr;
        m_FullSize = uint2::zero();
        m_SamplingSize = uint2::zero();
        m_ResolutionScale = 1u;
        m_AmbientResourcesEnabled = false;
        m_IndirectDiffuseResourcesEnabled = false;
        m_UpsampleResourcesEnabled = false;
        m_BufferPrecisionConfigurationKey = 0u;
        m_Timings = {};
    }

    void ScreenSpaceVisibilityPass::Deactivate()
    {
        ReleaseResources();
    }

    void ScreenSpaceVisibilityPass::ResetBindingCache()
    {
        for (nvrhi::BindingSetHandle& bindingSet : m_FilterBindingSets)
            bindingSet = nullptr;
        m_CompositeBindingSet = nullptr;
        m_BoundCompositeAmbient = nullptr;
        m_BoundCompositeIndirect = nullptr;
        m_BoundNoiseTexture = nullptr;
        m_AdvancedBindingSets.clear();
    }

    void ScreenSpaceVisibilityPass::AdvanceTimers()
    {
        const uint32_t slot = m_TimerFrame % c_TimerLatency;
        TimerSlot& timerSlot = m_TimerSlots[slot];
        m_TimerActive.fill(false);

        if (timerSlot.submittedStageMask == 0u)
        {
            assert(timerSlot.resolvedStageMask == 0u);
            m_TimerFrameWritable =
                VisibilityTimingSlotIsWritable(timerSlot);
            return;
        }

        m_TimerFrameWritable = false;
        VisibilityTimingSnapshot completedSnapshot;
        bool publishCompletedSnapshot = false;
        for (uint32_t stageIndex = 0u;
            stageIndex < static_cast<uint32_t>(Stage::Count);
            ++stageIndex)
        {
            const Stage stage = static_cast<Stage>(stageIndex);
            const uint32_t stageMask = VisibilityTimingStageMask(stage);
            if ((timerSlot.submittedStageMask & stageMask) == 0u ||
                (timerSlot.resolvedStageMask & stageMask) != 0u)
            {
                continue;
            }

            nvrhi::ITimerQuery* query = m_TimerQueries[stageIndex][slot];
            if (!m_Device->pollTimerQuery(query))
                continue;

            const float milliseconds =
                m_Device->getTimerQueryTime(query) * 1000.f;
            m_Device->resetTimerQuery(query);
            const VisibilityTimingResolution resolution =
                ResolveVisibilityTimingStage(
                    timerSlot,
                    stage,
                    milliseconds);
            assert(resolution.status !=
                VisibilityTimingResolveStatus::Invalid);
            if (resolution.status ==
                VisibilityTimingResolveStatus::Published)
            {
                completedSnapshot = resolution.snapshot;
                publishCompletedSnapshot = true;
            }
        }

        if (!publishCompletedSnapshot)
            return;

        ScreenSpaceVisibilityTimings completedTimings = m_Timings;
        completedTimings.firstTraceMs = completedSnapshot.firstTraceMs;
        completedTimings.reconstructionMs =
            completedSnapshot.reconstructionMs;
        completedTimings.compositionMs = completedSnapshot.compositionMs;
        completedTimings.effectEnvelopeMs =
            completedSnapshot.effectEnvelopeMs;
        completedTimings.available = completedSnapshot.available;
        m_Timings = completedTimings;

        assert(VisibilityTimingSlotIsWritable(timerSlot));
        m_TimerFrameWritable = true;
    }

    void ScreenSpaceVisibilityPass::BeginStage(
        nvrhi::ICommandList* commandList,
        Stage stage)
    {
        if (!m_TimerFrameWritable)
            return;

        const uint32_t stageIndex = static_cast<uint32_t>(stage);
        const uint32_t slot = m_TimerFrame % c_TimerLatency;
        TimerSlot& timerSlot = m_TimerSlots[slot];
        if (!VisibilityTimingCanSubmitStage(timerSlot, stage))
            return;

        commandList->beginTimerQuery(m_TimerQueries[stageIndex][slot]);
        m_TimerActive[stageIndex] = true;
    }

    void ScreenSpaceVisibilityPass::EndStage(
        nvrhi::ICommandList* commandList,
        Stage stage)
    {
        const uint32_t stageIndex = static_cast<uint32_t>(stage);
        if (!m_TimerActive[stageIndex])
            return;

        const uint32_t slot = m_TimerFrame % c_TimerLatency;
        TimerSlot& timerSlot = m_TimerSlots[slot];
        commandList->endTimerQuery(m_TimerQueries[stageIndex][slot]);
        const bool submitted = SubmitVisibilityTimingStage(
            timerSlot,
            stage);
        assert(submitted);
        m_TimerActive[stageIndex] = false;
    }

    ScreenSpaceVisibilityResult ScreenSpaceVisibilityPass::Render(
        nvrhi::ICommandList* commandList,
        const ScreenSpaceVisibilitySettings& settings,
        const ICompositeView& compositeView,
        const ScreenSpaceVisibilityInputs& inputs,
        const NoiseSettings& noiseSettings,
        nvrhi::ITexture* noiseTexture,
        uint32_t sampleSequencePhase,
        const LightingSampleSchedule& sampleSchedule)
    {
        if (!settings.HasActiveConsumer())
        {
            Deactivate();
            return {};
        }

        const auto fail = [this]()
        {
            m_TerminalRenderFailure = true;
            m_Timings = {};
            ScreenSpaceVisibilityResult result;
            result.status = ScreenSpaceVisibilityRenderStatus::Failed;
            return result;
        };

        if (!commandList || !m_PipelinesReady || m_PipelineCreationFailed ||
            m_TerminalRenderFailure ||
            !m_ConstantBuffer || !m_DummyAmbientVisibility ||
            !m_DummyIndirectDiffuse || !m_CommonPasses ||
            !inputs.surface.HasCompleteGBuffer() ||
            !inputs.baseLighting || !inputs.output ||
            !IsValidNoiseSettings(noiseSettings) || !noiseTexture ||
            !sampleSchedule || !sampleSchedule.attemptMask ||
            compositeView.GetNumChildViews(ViewType::PLANAR) != 1)
        {
            return fail();
        }

        const IView* view = compositeView.GetChildView(ViewType::PLANAR, 0);
        if (!view)
        {
            return fail();
        }
        const nvrhi::TextureDesc& depthDesc =
            inputs.surface.depth->getDesc();
        const uint2 fullSize(depthDesc.width, depthDesc.height);
        const uint32_t resolutionScale =
            GetResolutionScale(settings.resolution);
        const bool ambientEnabled = settings.HasActiveAmbientOcclusion();
        const bool indirectEnabled = settings.HasActiveIndirectDiffuse();
        const bool upsampleEnabled = resolutionScale > 1u;

        EnsureResources(
            fullSize,
            resolutionScale,
            ambientEnabled,
            indirectEnabled,
            upsampleEnabled,
            settings.bufferPrecision);
        const bool resourcesReady =
            (!ambientEnabled || m_RawAmbientVisibility) &&
            (!indirectEnabled || m_RawIndirectDiffuse) &&
            (!upsampleEnabled ||
                ((!ambientEnabled || m_FinalAmbientVisibility) &&
                 (!indirectEnabled || m_FinalIndirectDiffuse)));
        if (!resourcesReady)
        {
            return fail();
        }
        const bool hasSkyVisibilityConsumer =
            inputs.applySkyVisibilityToDiffuseIbl ||
            inputs.applySkyVisibilityToSpecularIbl;
        nvrhi::ITexture* activeSkyVisibility =
            hasSkyVisibilityConsumer &&
            IsSkyVisibilityTextureCompatible(
                inputs.skyVisibility,
                fullSize)
                ? inputs.skyVisibility
                : nullptr;
        const std::array<nvrhi::ITexture*, 14> inputTextures = {
            inputs.surface.depth,
            inputs.surface.normals,
            inputs.sourceRadiance,
            inputs.surface.diffuse,
            inputs.surface.material,
            inputs.surface.emissive,
            inputs.surface.materialAmbientOcclusion,
            activeSkyVisibility,
            inputs.diffuseEnvironment,
            inputs.specularEnvironment,
            inputs.environmentBrdf,
            inputs.baseLighting,
            inputs.output,
            sampleSchedule.attemptMask
        };
        if (inputTextures != m_BoundInputTextures ||
            noiseTexture != m_BoundNoiseTexture)
        {
            ResetBindingCache();
            m_BoundInputTextures = inputTextures;
            m_BoundNoiseTexture = noiseTexture;
        }
        AdvanceTimers();

        const uint32_t consumerVariant =
            GetConsumerVariant(ambientEnabled, indirectEnabled);
        const uint32_t estimatorIndex = std::min(
            static_cast<uint32_t>(settings.estimator),
            ImplementedVisibilityEstimatorCount - 1u);
        const VisibilitySchedulerState scheduler =
            ResolveVisibilitySchedulerState(
            estimatorIndex,
            ambientEnabled,
            indirectEnabled,
            settings.sampling.maximumSampleCount);
        const uint32_t runtimeSampleParity =
            static_cast<uint32_t>(scheduler.mode);

        ScreenSpaceVisibilityConstants constants{};
        view->FillPlanarViewConstants(constants.view);
        constants.fullResolution = {
            float(fullSize.x), float(fullSize.y) };
        constants.samplingResolution = {
            float(m_SamplingSize.x), float(m_SamplingSize.y) };
        constants.radiusWorld = std::max(settings.sampling.radius, 0.f);
        constants.thicknessWorld = std::max(
            settings.sampling.thickness, 0.f);
        constants.stepDistributionExponent = std::clamp(
            settings.sampling.stepDistributionExponent,
            MinimumVisibilityStepDistributionExponent,
            MaximumVisibilityStepDistributionExponent);
        constants.ambientStrength = std::clamp(
            settings.ambientOcclusion.strength,
            MinimumVisibilityAmbientOcclusionStrength,
            MaximumVisibilityAmbientOcclusionStrength);
        constants.indirectDiffuseIntensity = std::max(
            settings.indirectDiffuse.intensity, 0.f);
        constants.sampleSequencePhase = sampleSequencePhase;
        constants.maximumSampleCount = scheduler.selectedSampleCount;
        constants.sourceRadianceAvailable =
            inputs.sourceRadiance ? 1u : 0u;
        constants.enableAmbientOcclusion = ambientEnabled ? 1u : 0u;
        constants.enableIndirectDiffuse = indirectEnabled ? 1u : 0u;
        constants.reverseDepth = view->IsReverseDepth() ? 1u : 0u;
        constants.orthographicProjection =
            view->IsOrthographicProjection() ? 1u : 0u;
        constants.resolutionScale = resolutionScale;
        constants.noisePattern = static_cast<uint32_t>(
            noiseSettings.pattern);
        constants.sampleSequenceMode = static_cast<uint32_t>(
            ResolveLightingSampleSequenceMode(
                sampleSchedule,
                true,
                noiseSettings.animate));
        constants.visibilityDebugView = std::min(
            static_cast<uint32_t>(settings.debugView), 3u);
        constants.lightingDebugView = inputs.lightingDebugView;
        constants.skyVisibilityApplication =
            ResolveSkyVisibilityApplication(
                activeSkyVisibility != nullptr,
                inputs.applySkyVisibilityToDiffuseIbl,
                inputs.applySkyVisibilityToSpecularIbl);

        const float diffuseEnvironmentScale = std::max(
            std::isfinite(inputs.diffuseEnvironmentScale)
                ? inputs.diffuseEnvironmentScale
                : 0.f,
            0.f);
        constants.diffuseEnvironmentEnabled =
            inputs.diffuseEnvironment && diffuseEnvironmentScale > 0.f
            ? 1u
            : 0u;
        constants.diffuseEnvironmentScale = diffuseEnvironmentScale;
        constants.diffuseEnvironmentArrayIndex =
            inputs.diffuseEnvironmentArrayIndex;

        const float specularEnvironmentScale = std::max(
            std::isfinite(inputs.specularEnvironmentScale)
                ? inputs.specularEnvironmentScale
                : 0.f,
            0.f);
        const float specularEnvironmentMipLevels = std::max(
            std::isfinite(inputs.specularEnvironmentMipLevels)
                ? inputs.specularEnvironmentMipLevels
                : 0.f,
            0.f);
        constants.specularEnvironmentEnabled =
            inputs.specularEnvironment && inputs.environmentBrdf &&
                specularEnvironmentScale > 0.f &&
                specularEnvironmentMipLevels > 0.f
            ? 1u
            : 0u;
        constants.specularEnvironmentScale = specularEnvironmentScale;
        constants.specularEnvironmentMipLevels =
            specularEnvironmentMipLevels;
        constants.specularEnvironmentArrayIndex =
            inputs.specularEnvironmentArrayIndex;

        BeginStage(commandList, Stage::EffectEnvelope);
        commandList->writeBuffer(
            m_ConstantBuffer, &constants, sizeof(constants));

        const uint32_t samplingDispatchX =
            (m_SamplingSize.x + kThreadGroupSize - 1u) /
            kThreadGroupSize;
        const uint32_t samplingDispatchY =
            (m_SamplingSize.y + kThreadGroupSize - 1u) /
            kThreadGroupSize;
        const uint32_t fullDispatchX =
            (fullSize.x + kThreadGroupSize - 1u) / kThreadGroupSize;
        const uint32_t fullDispatchY =
            (fullSize.y + kThreadGroupSize - 1u) / kThreadGroupSize;

        nvrhi::ITexture* rawAmbient = ambientEnabled
            ? m_RawAmbientVisibility.Get()
            : m_DummyAmbientVisibility.Get();
        nvrhi::ITexture* rawIndirect = indirectEnabled
            ? m_RawIndirectDiffuse.Get()
            : m_DummyIndirectDiffuse.Get();
        nvrhi::ITexture* sourceRadiance = inputs.sourceRadiance
            ? inputs.sourceRadiance
            : m_DummyIndirectDiffuse.Get();

        commandList->beginMarker(indirectEnabled
            ? (ambientEnabled
                ? "Screen Space Visibility (AO + GI)"
                : "Screen Space Visibility (GI)")
            : "Screen Space Visibility (AO)");
        ScreenSpaceVisibilityInstrumentationScope instrumentation(
            [commandList]() { commandList->endMarker(); },
            [this, commandList]()
            {
                EndStage(commandList, Stage::EffectEnvelope);
            });

        std::vector<RendererShaderMacro> traceMacros = {
            { "VISIBILITY_ESTIMATOR", std::to_string(estimatorIndex) },
            { "ENABLE_AO", ambientEnabled ? "1" : "0" },
            { "ENABLE_GI", indirectEnabled ? "1" : "0" }
        };
        if (runtimeSampleParity != 0u)
        {
            traceMacros.push_back({
                "RUNTIME_SAMPLE_PARITY",
                std::to_string(runtimeSampleParity)
            });
        }

        std::vector<nvrhi::BindingLayoutItem> traceLayout = {
            nvrhi::BindingLayoutItem::VolatileConstantBuffer(0),
            nvrhi::BindingLayoutItem::Texture_SRV(0),
            nvrhi::BindingLayoutItem::Texture_SRV(1)
        };
        if (indirectEnabled)
            traceLayout.push_back(nvrhi::BindingLayoutItem::Texture_SRV(2));
        traceLayout.push_back(nvrhi::BindingLayoutItem::Texture_SRV(3));
        traceLayout.push_back(nvrhi::BindingLayoutItem::Texture_SRV(4));
        if (ambientEnabled)
            traceLayout.push_back(nvrhi::BindingLayoutItem::Texture_UAV(0));
        if (indirectEnabled)
            traceLayout.push_back(nvrhi::BindingLayoutItem::Texture_UAV(1));

        const uint64_t tracePipelineKey = TracePipelineKey(
            estimatorIndex,
            consumerVariant,
            runtimeSampleParity);
        Pipeline* tracePipeline = GetOrCreateAdvancedPipeline(
            tracePipelineKey,
            "uvsr/screen_space_visibility_cs.hlsl",
            traceLayout,
            &traceMacros);
        if (!tracePipeline)
        {
            m_PipelineCreationFailed = true;
            return fail();
        }
        nvrhi::BindingSetHandle& traceBindingSet =
            m_AdvancedBindingSets[tracePipelineKey];
        if (!traceBindingSet)
        {
            nvrhi::BindingSetDesc bindings;
            bindings.bindings = {
                nvrhi::BindingSetItem::ConstantBuffer(0, m_ConstantBuffer),
                nvrhi::BindingSetItem::Texture_SRV(
                    0, inputs.surface.depth),
                nvrhi::BindingSetItem::Texture_SRV(
                    1, inputs.surface.normals)
            };
            if (indirectEnabled)
            {
                bindings.bindings.push_back(
                    nvrhi::BindingSetItem::Texture_SRV(2, sourceRadiance));
            }
            bindings.bindings.push_back(
                nvrhi::BindingSetItem::Texture_SRV(
                    3, noiseTexture));
            bindings.bindings.push_back(
                nvrhi::BindingSetItem::Texture_SRV(
                    4, sampleSchedule.attemptMask));
            if (ambientEnabled)
            {
                bindings.bindings.push_back(
                    nvrhi::BindingSetItem::Texture_UAV(0, rawAmbient));
            }
            if (indirectEnabled)
            {
                bindings.bindings.push_back(
                    nvrhi::BindingSetItem::Texture_UAV(1, rawIndirect));
            }


            traceBindingSet = m_Device->createBindingSet(
                bindings, tracePipeline->bindingLayout);
        }

        if (!VisibilityDispatchIsReady(
                tracePipeline->IsValid(), bool(traceBindingSet), resourcesReady))
        {
            return fail();
        }

        {
            nvrhi::ComputeState state;
            state.pipeline = tracePipeline->pipeline;
            state.bindings = { traceBindingSet };
            commandList->beginMarker("Visibility Sampling");
            BeginStage(commandList, Stage::FirstTrace);
            commandList->setComputeState(state);
            commandList->dispatch(
                samplingDispatchX, samplingDispatchY, 1u);
            EndStage(commandList, Stage::FirstTrace);
            commandList->endMarker();
        }

        const bool upsampleAmbient = ambientEnabled && upsampleEnabled;
        const bool upsampleIndirect = indirectEnabled && upsampleEnabled;
        const bool upsampleRequired = upsampleAmbient || upsampleIndirect;
        nvrhi::ITexture* compositionAmbient = rawAmbient;
        nvrhi::ITexture* compositionIndirect = rawIndirect;
        if (upsampleRequired)
        {
            const uint32_t upsampleConsumerVariant =
                GetConsumerVariant(
                    upsampleAmbient,
                    upsampleIndirect);
            Pipeline& upsamplePipeline = m_Filter[upsampleConsumerVariant];
            nvrhi::BindingSetHandle& upsampleBindingSet =
                m_FilterBindingSets[upsampleConsumerVariant];

            if (!upsampleBindingSet)
            {
                nvrhi::BindingSetDesc bindings;
                bindings.bindings = {
                    nvrhi::BindingSetItem::ConstantBuffer(
                        0, m_ConstantBuffer)
                };
                if (upsampleAmbient)
                {
                    bindings.bindings.push_back(
                        nvrhi::BindingSetItem::Texture_SRV(
                            0, rawAmbient));
                }
                if (upsampleIndirect)
                {
                    bindings.bindings.push_back(
                        nvrhi::BindingSetItem::Texture_SRV(
                            1, rawIndirect));
                }
                bindings.bindings.push_back(
                    nvrhi::BindingSetItem::Texture_SRV(
                        2, inputs.surface.depth));
                bindings.bindings.push_back(
                    nvrhi::BindingSetItem::Texture_SRV(
                        3, inputs.surface.normals));
                if (upsampleAmbient)
                {
                    bindings.bindings.push_back(
                        nvrhi::BindingSetItem::Texture_UAV(
                            0, m_FinalAmbientVisibility));
                }
                if (upsampleIndirect)
                {
                    bindings.bindings.push_back(
                        nvrhi::BindingSetItem::Texture_UAV(
                            1, m_FinalIndirectDiffuse));
                }
                upsampleBindingSet = m_Device->createBindingSet(
                    bindings, upsamplePipeline.bindingLayout);
            }

            if (!VisibilityDispatchIsReady(
                    upsamplePipeline.IsValid(), bool(upsampleBindingSet),
                    resourcesReady))
            {
                return fail();
            }

            nvrhi::ComputeState state;
            state.pipeline = upsamplePipeline.pipeline;
            state.bindings = { upsampleBindingSet };
            commandList->beginMarker("Visibility Guide-Aware Upsample");
            BeginStage(commandList, Stage::Upsample);
            commandList->setComputeState(state);
            commandList->dispatch(fullDispatchX, fullDispatchY, 1u);
            EndStage(commandList, Stage::Upsample);
            commandList->endMarker();

            compositionAmbient = upsampleAmbient
                ? m_FinalAmbientVisibility.Get()
                : rawAmbient;
            compositionIndirect = upsampleIndirect
                ? m_FinalIndirectDiffuse.Get()
                : rawIndirect;
        }
        if (compositionAmbient != m_BoundCompositeAmbient ||
            compositionIndirect != m_BoundCompositeIndirect)
        {
            m_CompositeBindingSet = nullptr;
            m_BoundCompositeAmbient = compositionAmbient;
            m_BoundCompositeIndirect = compositionIndirect;
        }
        if (!m_CompositeBindingSet)
        {
            nvrhi::BindingSetDesc bindings;
            bindings.bindings = {
                nvrhi::BindingSetItem::ConstantBuffer(0, m_ConstantBuffer),
                nvrhi::BindingSetItem::Texture_SRV(
                    0, inputs.baseLighting),
                nvrhi::BindingSetItem::Texture_SRV(
                    1, compositionAmbient),
                nvrhi::BindingSetItem::Texture_SRV(
                    2, compositionIndirect),
                nvrhi::BindingSetItem::Texture_SRV(
                    3, inputs.surface.diffuse),
                nvrhi::BindingSetItem::Texture_SRV(
                    4, inputs.surface.emissive),
                nvrhi::BindingSetItem::Texture_SRV(
                    5, inputs.surface.materialAmbientOcclusion),
                nvrhi::BindingSetItem::Texture_SRV(
                    6, inputs.surface.normals),
                nvrhi::BindingSetItem::Texture_SRV(
                    8, inputs.surface.material),
                nvrhi::BindingSetItem::Texture_SRV(
                    9, inputs.surface.depth),
                nvrhi::BindingSetItem::Sampler(
                    0, m_CommonPasses->LinearWrapSampler()),
                nvrhi::BindingSetItem::Sampler(
                    1, m_CommonPasses->LinearClampSampler()),
                nvrhi::BindingSetItem::Texture_UAV(0, inputs.output)
            };
            ScreenSpaceCompositeEnvironmentResources<nvrhi::ITexture*>
                activeEnvironmentResources;
            activeEnvironmentResources.diffuseEnvironment =
                inputs.diffuseEnvironment;
            activeEnvironmentResources.specularEnvironment =
                inputs.specularEnvironment;
            activeEnvironmentResources.environmentBrdf =
                inputs.environmentBrdf;
            activeEnvironmentResources.skyVisibility = activeSkyVisibility;
            const auto environmentResources =
                ResolveScreenSpaceCompositeEnvironmentResources(
                    activeEnvironmentResources,
                    m_CommonPasses->BlackCubeArray(),
                    m_CommonPasses->BlackTexture(),
                    m_CommonPasses->WhiteTexture());
            for (const auto& binding :
                MakeScreenSpaceCompositeEnvironmentBindings(
                    environmentResources))
            {
                bindings.bindings.push_back(
                    nvrhi::BindingSetItem::Texture_SRV(
                        binding.slot, binding.resource));
            }
            m_CompositeBindingSet = m_Device->createBindingSet(
                bindings, m_Composite.bindingLayout);
        }

        if (!VisibilityDispatchIsReady(
                m_Composite.IsValid(), bool(m_CompositeBindingSet),
                resourcesReady))
        {
            return fail();
        }

        {
            nvrhi::ComputeState state;
            state.pipeline = m_Composite.pipeline;
            state.bindings = { m_CompositeBindingSet };
            commandList->beginMarker("Screen Space Indirect Composite");
            BeginStage(commandList, Stage::Composition);
            commandList->setComputeState(state);
            commandList->dispatch(fullDispatchX, fullDispatchY, 1u);
            EndStage(commandList, Stage::Composition);
            commandList->endMarker();
        }

        m_Timings.activeSrvCount = 3u + (indirectEnabled ? 1u : 0u);
        m_Timings.activeUavCount =
            uint32_t(ambientEnabled) + uint32_t(indirectEnabled);
        m_Timings.activeDispatchCount = 2u +
            uint32_t(upsampleRequired);
        m_Timings.active = true;

        instrumentation.Close();
        if (m_TimerFrameWritable)
            ++m_TimerFrame;
        return {
            ambientEnabled ? m_RawAmbientVisibility.Get() : nullptr,
            indirectEnabled ? m_RawIndirectDiffuse.Get() : nullptr,
            m_SamplingSize,
            true,
            ScreenSpaceVisibilityRenderStatus::Dispatched
        };
    }
}
