#include "uvsr_ui_internal.h"

namespace
{
    struct UiSettingRange
    {
        float safeMinimum = 0.f;
        float safeMaximum = 0.f;
        float trackMinimum = 0.f;
        float trackMaximum = 0.f;
        float displayScale = 1.f;
    };

    [[nodiscard]] const UiSettingsCommandDefinition&
        GetUiSettingDefinition(SettingId id)
    {
        return *FindSettingsCommandDefinition(id);
    }

    [[nodiscard]] UiSettingRange GetUiSettingRange(
        SettingId id,
        bool useContextMaximum = false)
    {
        const UiSettingsCommandDefinition& definition =
            GetUiSettingDefinition(id);
        const UiSettingsTypedDomain& domain = definition.typedDomain;
        const UiSettingsPresentation& presentation =
            definition.presentation;
        const float displayScale = presentation.displayScale;
        const float trackMinimum = presentation.hasTrackRange
            ? static_cast<float>(presentation.trackMinimum)
            : static_cast<float>(domain.minimum);
        const float safeMaximum = useContextMaximum &&
            domain.hasContextMaximum
            ? static_cast<float>(domain.contextMaximum)
            : static_cast<float>(domain.maximum);
        const float trackMaximum = presentation.hasTrackRange
            ? static_cast<float>(presentation.trackMaximum)
            : safeMaximum;
        return {
            static_cast<float>(domain.minimum) * displayScale,
            safeMaximum * displayScale,
            trackMinimum * displayScale,
            trackMaximum * displayScale,
            displayScale
        };
    }

    [[nodiscard]] std::string GetUiSettingToken(
        SettingId id,
        std::size_t index)
    {
        const UiSettingsTypedDomain& domain =
            GetUiSettingDefinition(id).typedDomain;
        return index < domain.tokenCount
            ? std::string(domain.tokens[index])
            : std::string{};
    }

    [[nodiscard]] std::size_t GetUiSettingTokenIndex(
        SettingId id,
        std::string_view token)
    {
        const UiSettingsTypedDomain& domain =
            GetUiSettingDefinition(id).typedDomain;
        for (std::size_t index = 0u; index < domain.tokenCount; ++index)
        {
            if (domain.tokens[index] == token)
                return index;
        }
        assert(false && "The current setting token must belong to its typed domain");
        return 0u;
    }

    void ClampUiSettingColor(
        SettingId id,
        float* color,
        std::size_t componentCount)
    {
        const UiSettingsTypedDomain& domain =
            GetUiSettingDefinition(id).typedDomain;
        assert(domain.hasRange);
        assert(
            (componentCount == 3u &&
                domain.kind == UiSettingsDomainKind::Float3) ||
            (componentCount == 4u &&
                domain.kind == UiSettingsDomainKind::Float4));
        const float minimum = static_cast<float>(domain.minimum);
        const float maximum = static_cast<float>(domain.maximum);
        for (std::size_t index = 0u;
            index < componentCount;
            ++index)
        {
            color[index] = std::clamp(
                color[index],
                minimum,
                maximum);
        }
    }
}

auto UIRenderer::IsSettingsChildLaterInDrawOrder(
        const ImGuiWindow* candidate,
        const ImGuiWindow* current) -> bool {
        if (!current)
            return true;

        const int popupOrder =
            int(candidate->Flags & ImGuiWindowFlags_Popup) -
            int(current->Flags & ImGuiWindowFlags_Popup);
        if (popupOrder != 0)
            return popupOrder > 0;

        const int tooltipOrder =
            int(candidate->Flags & ImGuiWindowFlags_Tooltip) -
            int(current->Flags & ImGuiWindowFlags_Tooltip);
        if (tooltipOrder != 0)
            return tooltipOrder > 0;

        return candidate->BeginOrderWithinParent >
            current->BeginOrderWithinParent;
    }

auto UIRenderer::ResolveFinalSettingsDecorationDrawList(
        ImGuiWindow* window) -> ImDrawList* {
        if (!window)
            return nullptr;

        ImGuiWindow* finalVisibleChild = nullptr;
        for (ImGuiWindow* child : window->DC.ChildWindows)
        {
            if (!child || !child->Active || child->Hidden)
                continue;
            if (IsSettingsChildLaterInDrawOrder(
                    child,
                    finalVisibleChild))
            {
                finalVisibleChild = child;
            }
        }
        return finalVisibleChild
            ? ResolveFinalSettingsDecorationDrawList(finalVisibleChild)
            : window->DrawList;
    }

auto UIRenderer::CompositeUiColorOver(
        const ImVec4& foreground,
        const ImVec4& background) -> ImVec4 {
        const float foregroundAlpha =
            std::clamp(foreground.w, 0.f, 1.f);
        const float backgroundAlpha =
            std::clamp(background.w, 0.f, 1.f);
        const float outputAlpha =
            foregroundAlpha +
            backgroundAlpha * (1.f - foregroundAlpha);
        if (outputAlpha <= 0.f)
            return ImVec4(0.f, 0.f, 0.f, 0.f);

        const float backgroundContribution =
            backgroundAlpha * (1.f - foregroundAlpha);
        return ImVec4(
            (foreground.x * foregroundAlpha +
                background.x * backgroundContribution) /
                outputAlpha,
            (foreground.y * foregroundAlpha +
                background.y * backgroundContribution) /
                outputAlpha,
            (foreground.z * foregroundAlpha +
                background.z * backgroundContribution) /
                outputAlpha,
            outputAlpha);
    }

auto UIRenderer::MakeUiColor(
        const UiRgbaColor& color,
        float alphaMultiplier ) -> ImVec4 {
        return ImVec4(
            std::clamp(color.red, 0.f, 1.f),
            std::clamp(color.green, 0.f, 1.f),
            std::clamp(color.blue, 0.f, 1.f),
            std::clamp(color.alpha * alphaMultiplier, 0.f, 1.f));
    }

auto UIRenderer::ScaleUiColor(
        const UiRgbaColor& color,
        float scale,
        float alphaMultiplier ) -> ImVec4 {
        return ImVec4(
            std::clamp(color.red * scale, 0.f, 1.f),
            std::clamp(color.green * scale, 0.f, 1.f),
            std::clamp(color.blue * scale, 0.f, 1.f),
            std::clamp(color.alpha * alphaMultiplier, 0.f, 1.f));
    }

auto UIRenderer::OffsetUiColor(
        const UiRgbaColor& color,
        float offset,
        float alphaMultiplier ) -> ImVec4 {
        return ImVec4(
            std::clamp(color.red + offset, 0.f, 1.f),
            std::clamp(color.green + offset, 0.f, 1.f),
            std::clamp(color.blue + offset, 0.f, 1.f),
            std::clamp(color.alpha * alphaMultiplier, 0.f, 1.f));
    }

auto UIRenderer::IsUltraBrightUiColor(const UiRgbaColor& color) -> bool {
        const float luminance =
            color.red * 0.2126f +
            color.green * 0.7152f +
            color.blue * 0.0722f;
        return luminance >= 0.68f;
    }

auto UIRenderer::ApplyUiSkin(
        UiSkin skin,
        const UiAccentSettings& accents,
        float displayScale) -> void {
        const UiSkin resolvedSkin = ResolveUiSkin(skin);
        const UiSkinBehavior behavior =
            GetUiSkinBehavior(resolvedSkin);
        const UiSkinPalette* storedPalette =
            FindUiSkinPalette(accents, resolvedSkin);
        const UiSkinPalette* defaultPalette =
            FindDefaultUiSkinPalette(resolvedSkin);
        const UiSkinPalette& palette = storedPalette
            ? *storedPalette
            : defaultPalette
                ? *defaultPalette
                : DefaultUiAmpPalette;
        const bool authoredSkin = !behavior.stockImGuiWidgets;
        const bool brightPrimaryAccent = authoredSkin &&
            IsUltraBrightUiColor(palette.primaryAccent);
        const bool brightPrimaryBackground = authoredSkin &&
            IsUltraBrightUiColor(palette.primaryBackground);

        ImGuiStyle style;
        ImGui::StyleColorsDark(&style);
        ImVec4* colors = style.Colors;
        UiVisualTokens tokens;
        tokens.errorText = MakeUiColor(accents.secondaryAccent);
        tokens.successText = MakeUiColor(accents.tertiaryAccent);

        if (!authoredSkin)
        {
            style.ScrollbarRounding = 0.f;
            tokens.drawerHeader = colors[ImGuiCol_Header];
            tokens.drawerHeaderHovered =
                colors[ImGuiCol_HeaderHovered];
            tokens.drawerHeaderActive =
                colors[ImGuiCol_HeaderActive];
            tokens.drawerHeaderText = colors[ImGuiCol_Text];
            tokens.drawerBackground = colors[ImGuiCol_ChildBg];
            tokens.drawerFrame = colors[ImGuiCol_FrameBg];
            tokens.drawerFrameHovered =
                colors[ImGuiCol_FrameBgHovered];
            tokens.drawerFrameActive =
                colors[ImGuiCol_FrameBgActive];
            tokens.outlineTop = colors[ImGuiCol_Border];
            tokens.outlineBottom = colors[ImGuiCol_Border];
            tokens.panelBodySurface = colors[ImGuiCol_WindowBg];
            tokens.colorPickerSurface = colors[ImGuiCol_PopupBg];
            tokens.panelInsetFrame = ImVec4(
                colors[ImGuiCol_WindowBg].x,
                colors[ImGuiCol_WindowBg].y,
                colors[ImGuiCol_WindowBg].z,
                1.f);
            tokens.settingsTitleSurface =
                colors[ImGuiCol_TitleBgActive];
            tokens.settingsTitleText = colors[ImGuiCol_Text];
            tokens.actionButton = colors[ImGuiCol_Button];
            tokens.actionButtonHovered =
                colors[ImGuiCol_ButtonHovered];
            tokens.actionButtonActive =
                colors[ImGuiCol_ButtonActive];
            tokens.actionButtonText = colors[ImGuiCol_Text];
            tokens.drawerRounding = style.ChildRounding;
            tokens.drawControlOutlines = false;
        }
        else
        {
            constexpr float SecondaryRestAlpha = 0.72f;
            constexpr float AuthoredCornerRounding = 4.f;
            style.WindowRounding = AuthoredCornerRounding;
            style.ChildRounding = AuthoredCornerRounding;
            style.PopupRounding = AuthoredCornerRounding;
            style.FrameRounding = AuthoredCornerRounding;
            style.GrabRounding = AuthoredCornerRounding;
            style.ScrollbarRounding = AuthoredCornerRounding;
            style.ScrollbarSize = 12.f;
            style.TabRounding = AuthoredCornerRounding;
            style.WindowBorderSize = 1.f;
            style.DisabledAlpha = 0.38f;

            colors[ImGuiCol_Text] = MakeUiColor(palette.fontColor);
            colors[ImGuiCol_TextDisabled] =
                ScaleUiColor(palette.fontColor, 0.62f);
            colors[ImGuiCol_WindowBg] = MakeUiColor(
                palette.primaryBackground,
                0.60f / SecondaryRestAlpha);
            colors[ImGuiCol_ChildBg] =
                ImVec4(0.f, 0.f, 0.f, 0.f);
            colors[ImGuiCol_PopupBg] = MakeUiColor(
                palette.primaryBackground,
                0.92f / SecondaryRestAlpha);
            colors[ImGuiCol_Border] =
                ImVec4(0.15f, 0.15f, 0.15f, 0.92f);
            colors[ImGuiCol_BorderShadow] =
                ImVec4(0.01f, 0.012f, 0.016f, 0.48f);
            colors[ImGuiCol_FrameBg] =
                MakeUiColor(palette.primaryBackground);
            colors[ImGuiCol_FrameBgHovered] = brightPrimaryBackground
                ? ScaleUiColor(
                    palette.primaryBackground,
                    0.82f,
                    0.76f / SecondaryRestAlpha)
                : OffsetUiColor(
                    palette.primaryBackground,
                    0.112f,
                    0.76f / SecondaryRestAlpha);
            colors[ImGuiCol_FrameBgActive] = brightPrimaryBackground
                ? ScaleUiColor(
                    palette.primaryBackground,
                    0.70f,
                    0.82f / SecondaryRestAlpha)
                : OffsetUiColor(
                    palette.primaryBackground,
                    0.162f,
                    0.82f / SecondaryRestAlpha);
            colors[ImGuiCol_TitleBg] =
                colors[ImGuiCol_FrameBg];
            colors[ImGuiCol_TitleBgActive] =
                colors[ImGuiCol_FrameBgHovered];
            colors[ImGuiCol_TitleBgCollapsed] =
                colors[ImGuiCol_FrameBg];
            colors[ImGuiCol_ScrollbarBg] = MakeUiColor(
                palette.primaryBackground,
                0.36f / SecondaryRestAlpha);
            colors[ImGuiCol_ScrollbarGrab] =
                ImVec4(0.66f, 0.67f, 0.69f, 0.13f);
            colors[ImGuiCol_ScrollbarGrabHovered] =
                ImVec4(0.74f, 0.75f, 0.77f, 0.20f);
            colors[ImGuiCol_ScrollbarGrabActive] =
                ImVec4(0.80f, 0.81f, 0.83f, 0.26f);
            const ImVec4 opaquePrimaryAccent(
                palette.primaryAccent.red,
                palette.primaryAccent.green,
                palette.primaryAccent.blue,
                1.f);
            colors[ImGuiCol_CheckMark] = opaquePrimaryAccent;
            colors[ImGuiCol_Button] = colors[ImGuiCol_FrameBg];
            colors[ImGuiCol_ButtonHovered] =
                colors[ImGuiCol_FrameBgHovered];
            colors[ImGuiCol_ButtonActive] =
                colors[ImGuiCol_FrameBgActive];
            colors[ImGuiCol_ResizeGrip] =
                ImVec4(0.48f, 0.49f, 0.51f, 0.28f);
            colors[ImGuiCol_ResizeGripHovered] =
                ImVec4(0.60f, 0.61f, 0.63f, 0.62f);
            colors[ImGuiCol_ResizeGripActive] =
                ImVec4(0.75f, 0.76f, 0.78f, 0.90f);

            tokens.drawerHeader =
                MakeUiColor(palette.primaryAccent);
            if (brightPrimaryAccent)
            {
                // Ultra-bright custom Amp accents darken on interaction while
                // retaining Amp's authored opacity curve.
                tokens.drawerHeaderHovered = ScaleUiColor(
                    palette.primaryAccent,
                    0.82f,
                    0.48f / 0.31f);
                tokens.drawerHeaderActive = ScaleUiColor(
                    palette.primaryAccent,
                    0.70f,
                    0.65f / 0.31f);
            }
            else
            {
                tokens.drawerHeaderHovered = MakeUiColor(
                    palette.primaryAccent,
                    0.48f / 0.31f);
                tokens.drawerHeaderActive = MakeUiColor(
                    palette.primaryAccent,
                    0.65f / 0.31f);
            }
            tokens.drawerHeaderText =
                MakeUiColor(palette.fontColor);
            tokens.drawerBackground =
                ImVec4(
                    0.66f,
                    0.67f,
                    0.69f,
                    std::clamp(
                        palette.primaryBackground.alpha *
                            (0.13f / SecondaryRestAlpha),
                        0.f,
                        1.f));
            tokens.drawerFrame = colors[ImGuiCol_FrameBg];
            tokens.drawerFrameHovered =
                colors[ImGuiCol_FrameBgHovered];
            tokens.drawerFrameActive =
                colors[ImGuiCol_FrameBgActive];
            tokens.outlineTop =
                ImVec4(0.005f, 0.006f, 0.008f, 0.14f);
            tokens.outlineBottom =
                ImVec4(0.88f, 0.90f, 0.94f, 0.070f);
            tokens.panelBodySurface = MakeUiColor(
                palette.primaryBackground,
                0.92f / SecondaryRestAlpha);
            tokens.colorPickerSurface = tokens.panelBodySurface;
            tokens.panelInsetFrame = ImVec4(
                tokens.panelBodySurface.x,
                tokens.panelBodySurface.y,
                tokens.panelBodySurface.z,
                1.f);
            tokens.settingsTitleSurface = CompositeUiColorOver(
                tokens.drawerHeader,
                tokens.panelBodySurface);
            tokens.settingsTitleText =
                MakeUiColor(palette.fontColor);
            tokens.actionButton = tokens.drawerHeader;
            tokens.actionButtonHovered =
                tokens.drawerHeaderHovered;
            tokens.actionButtonActive =
                tokens.drawerHeaderActive;
            tokens.actionButtonText =
                MakeUiColor(palette.fontColor);
            tokens.drawerRounding = style.ChildRounding;
            colors[ImGuiCol_Header] = tokens.drawerHeader;
            colors[ImGuiCol_HeaderHovered] =
                tokens.drawerHeaderHovered;
            colors[ImGuiCol_HeaderActive] =
                tokens.drawerHeaderActive;
            colors[ImGuiCol_SliderGrab] =
                tokens.drawerHeader;
            colors[ImGuiCol_SliderGrabActive] =
                tokens.drawerHeaderActive;
        }

        ImGui::SetUvsrUiBehavior(behavior.stockImGuiWidgets);
        ImGui::SetUvsrUiAccentColors(
            MakeUiColor(accents.secondaryAccent),
            MakeUiColor(accents.tertiaryAccent));
        ImGui::SetUvsrSliderTrackColors(
            tokens.drawerFrame,
            tokens.drawerFrameHovered,
            tokens.drawerFrameActive);
        const float safeDisplayScale =
            std::clamp(
                displayScale,
                UiMinimumDisplayScale,
                UiMaximumDisplayScale);
        style.ScaleAllSizes(safeDisplayScale);
        const UiSpacingTokens spacing =
            ResolveUiSpacingTokens(safeDisplayScale);
        style.WindowPadding =
            ImVec2(spacing.regular, spacing.regular);
        ImGui::SetUvsrAuthoredWindowPadding(style.WindowPadding);
        style.ItemSpacing =
            ImVec2(spacing.regular, spacing.tight);
        style.ItemInnerSpacing =
            ImVec2(spacing.tight, spacing.tight);
        tokens.drawerRounding *= safeDisplayScale;
        if (authoredSkin)
        {
            // Keep the authored edge stroke physically thin while radii scale
            // with the rest of the controls instead of sharpening at high DPI.
            style.WindowBorderSize = 1.f;
            style.CircleTessellationMaxError = 0.20f;
        }
        g_UiSpacingTokens = spacing;
        g_UiVisualTokens = tokens;
        ImGui::GetStyle() = style;
    }

UIRenderer::RootPanel UIRenderer::BeginRootPanel(
    bool performance, const ImVec2& position, float width, float maximumHeight)
{
    const ImGuiStyle& style = ImGui::GetStyle();
    const float collapsedHeight = GetSettingsCollapsedWindowHeight(style, ImGui::GetFontSize());
    ImGui::SetNextWindowPos(position, ImGuiCond_Always);
    // Exact X constraints fix width while AlwaysAutoResize owns height.
    ImGui::SetNextWindowSizeConstraints(ImVec2(width, performance ? collapsedHeight : 0.f),
        ImVec2(width, maximumHeight));
    ImGui::SetNextUvsrWindowCollapsedHeight(collapsedHeight);
    auto& request = performance ? m_PerformanceCollapsedRequest : m_SettingsCollapsedRequest;
    ImGui::SetNextWindowCollapsed(request.value_or(performance),
        request ? ImGuiCond_Always : ImGuiCond_Once);
    request.reset();
    ImGui::PushStyleColor(ImGuiCol_WindowBg, g_UiVisualTokens.panelBodySurface);
    for (ImGuiCol color : { ImGuiCol_TitleBg, ImGuiCol_TitleBgActive, ImGuiCol_TitleBgCollapsed })
        ImGui::PushStyleColor(color, g_UiVisualTokens.settingsTitleSurface);
    ImGui::PushStyleColor(ImGuiCol_Text, g_UiVisualTokens.settingsTitleText);
    const bool authored = !GetUiSkinBehavior(m_ComposedUiSkin).stockImGuiWidgets;
    if (authored)
    {
        ImGui::PushFont(GetActiveUiHeaderFont());
        ApplyActiveUiHeaderWordSpacing();
    }
    const ImGuiWindowFlags flags = ImGuiWindowFlags_AlwaysAutoResize | (performance
        ? ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings
        : ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    const bool visible = ImGui::Begin(performance ? "Performance" : "Settings", nullptr, flags);
    const bool collapsed = ImGui::IsWindowCollapsed();
    if (authored)
    {
        RestoreActiveUiHeaderWordSpacing();
        ImGui::PopFont();
    }
    ImGui::PopStyleColor();
    return { ImGui::GetCurrentWindow(), visible && !collapsed, collapsed };
}

void UIRenderer::EndRootPanel()
{
    ImGui::End();
    ImGui::PopStyleColor(4);
}

UIRenderer::RootPanelGeometry UIRenderer::GetRootPanelGeometry(const ImGuiWindow* window)
{
    const ImVec2 padding = ImGui::GetStyle().WindowPadding;
    RootPanelGeometry result;
    result.body = ImRect(ImVec2(window->Pos.x, window->Pos.y + window->TitleBarHeight),
        ImVec2(window->Pos.x + window->Size.x, window->Pos.y + window->Size.y));
    result.content = ImRect(ImVec2(result.body.Min.x + padding.x, result.body.Min.y + padding.y),
        ImVec2(result.body.Max.x - padding.x, result.body.Max.y - padding.y));
    result.summary = ImRect(result.content.Min, ImVec2(result.content.Max.x,
        std::min(result.content.Max.y, result.content.Min.y + ImGui::GetFontSize() + g_UiSpacingTokens.tight)));
    return result;
}

auto UIRenderer::GetOpaquePanelBodySurface() -> ImVec4 {
        ImVec4 surface = g_UiVisualTokens.panelBodySurface;
        surface.w = 1.f;
        return surface;
    }



auto UIRenderer::GetSettingsCollapsedWindowHeight(
        const ImGuiStyle& style,
        float fontSize) -> float {
        return (fontSize + style.FramePadding.y * 2.f) +
            style.WindowPadding.y * 2.f +
            fontSize +
            g_UiSpacingTokens.tight;
    }



bool UIRenderer::DrawCollapsingHeader(
    const char* label, const char* tooltip, ImGuiTreeNodeFlags flags)
{
    ImGui::PushStyleColor(ImGuiCol_Header, g_UiVisualTokens.drawerHeader);
    ImGui::PushStyleColor(ImGuiCol_HeaderHovered, g_UiVisualTokens.drawerHeaderHovered);
    ImGui::PushStyleColor(ImGuiCol_HeaderActive, g_UiVisualTokens.drawerHeaderActive);
    ImGui::PushStyleColor(ImGuiCol_Text, g_UiVisualTokens.drawerHeaderText);
    const bool authoredFont = !GetUiSkinBehavior(m_ComposedUiSkin).stockImGuiWidgets;
    if (authoredFont)
    {
        ImGui::PushFont(GetActiveUiHeaderFont());
        ApplyActiveUiHeaderWordSpacing();
    }
    ImGuiStyle& style = ImGui::GetStyle();
    const float itemSpacingY = std::exchange(style.ItemSpacing.y, 0.f);
    const bool open = ImGui::CollapsingHeader(label, flags);
    style.ItemSpacing.y = itemSpacingY;
    if (authoredFont)
    {
        RestoreActiveUiHeaderWordSpacing();
        ImGui::PopFont();
    }
    ImGui::PopStyleColor(4);
    ImGui::SetItemTooltip("%s", tooltip);
    return open;
}

void UIRenderer::BeginDrawerBody(const char* id, float controlWidth, float maximumHeight)
{
    ImGui::PushStyleColor(ImGuiCol_ChildBg, g_UiVisualTokens.drawerBackground);
    ImGui::PushStyleColor(ImGuiCol_FrameBg, g_UiVisualTokens.drawerFrame);
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, g_UiVisualTokens.drawerFrameHovered);
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive, g_UiVisualTokens.drawerFrameActive);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(g_UiSpacingTokens.tight, g_UiSpacingTokens.tight));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, g_UiVisualTokens.drawerRounding);
    const bool scrollable = maximumHeight > 0.f;
    if (scrollable)
        ImGui::SetNextWindowSizeConstraints(ImVec2(0.f, 0.f), ImVec2(FLT_MAX, maximumHeight));
    ImGui::BeginChild(id, ImVec2(0.f, 0.f),
        ImGuiChildFlags_AlwaysUseWindowPadding |
            ImGuiChildFlags_AutoResizeY | ImGuiChildFlags_AlwaysAutoResize,
        scrollable ? ImGuiWindowFlags_None : ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    ImGui::PushItemWidth(controlWidth);
}



auto UIRenderer::DrawDrawerBodyOutline(
        ImDrawList* drawList,
        const ImVec2& minimum,
        const ImVec2& maximum,
        float rounding,
        float topGap,
        bool intersectClipRect) -> void {
        if (!drawList ||
            !g_UiVisualTokens.drawControlOutlines)
            return;

        constexpr float Thickness = 1.f;
        constexpr float Inset = Thickness * 0.5f;

        const ImVec2 outlineMinimum(
            minimum.x + Inset,
            minimum.y + Inset);
        const ImVec2 outlineMaximum(
            maximum.x - Inset,
            maximum.y - Inset);
        const float width = outlineMaximum.x - outlineMinimum.x;
        const float height = outlineMaximum.y - outlineMinimum.y;
        if (width <= Thickness || height <= topGap + Thickness)
            return;

        const float clipTop = topGap > 0.f
            ? outlineMinimum.y + topGap
            : outlineMinimum.y - Thickness;
        drawList->PushClipRect(
            ImVec2(
                outlineMinimum.x - Thickness,
                clipTop),
            ImVec2(
                outlineMaximum.x + Thickness,
                outlineMaximum.y + Thickness),
            intersectClipRect);
        const int vertexStart = drawList->VtxBuffer.Size;
        drawList->AddRect(
            outlineMinimum,
            outlineMaximum,
            IM_COL32_WHITE,
            std::max(0.f, rounding - Inset),
            ImDrawFlags_RoundCornersAll,
            Thickness);
        const int vertexEnd = drawList->VtxBuffer.Size;
        drawList->PopClipRect();

        const float gradientExtent = std::max(height, 1.f);
        for (int vertexIndex = vertexStart;
            vertexIndex < vertexEnd;
            ++vertexIndex)
        {
            ImDrawVert& vertex = drawList->VtxBuffer[vertexIndex];
            const float coverage =
                float((vertex.col & IM_COL32_A_MASK) >>
                    IM_COL32_A_SHIFT) / 255.f;
            const float gradientPosition = std::clamp(
                (vertex.pos.y - outlineMinimum.y) / gradientExtent,
                0.f,
                1.f);
            ImVec4 outlineColor = ImLerp(
                g_UiVisualTokens.outlineTop,
                g_UiVisualTokens.outlineBottom,
                gradientPosition);
            outlineColor.w *= coverage;
            vertex.col = ImGui::GetColorU32(outlineColor);
        }
    }

auto UIRenderer::ResolveRoundedRectRadius(
        const ImRect& rectangle,
        float requestedRadius) -> float {
        return std::max(
            0.f,
            std::min({
                requestedRadius,
                rectangle.GetWidth() * 0.5f - 1.f,
                rectangle.GetHeight() * 0.5f - 1.f
            }));
    }

auto UIRenderer::DrawFilledRoundedInsetFrame(
        ImDrawList* drawList,
        const ImRect& outerRect,
        const ImRect& innerRect,
        float rounding) -> void {
        if (!drawList ||
            outerRect.GetWidth() <= 1.f ||
            outerRect.GetHeight() <= 1.f ||
            innerRect.Min.x <= outerRect.Min.x ||
            innerRect.Min.y <= outerRect.Min.y ||
            innerRect.Max.x >= outerRect.Max.x ||
            innerRect.Max.y >= outerRect.Max.y ||
            innerRect.GetWidth() <= 1.f ||
            innerRect.GetHeight() <= 1.f)
        {
            return;
        }

        const float outerRadius = ResolveRoundedRectRadius(
            outerRect,
            rounding);
        const float innerRadius = ResolveRoundedRectRadius(
            innerRect,
            rounding);
        const ImU32 frameColor = ImGui::GetColorU32(
            g_UiVisualTokens.panelInsetFrame);
        if ((frameColor & IM_COL32_A_MASK) == 0u)
            return;
        const ImVec2 expandedOuterMinimum(
            outerRect.Min.x - 1.f,
            outerRect.Min.y - 1.f);
        const ImVec2 expandedOuterMaximum(
            outerRect.Max.x + 1.f,
            outerRect.Max.y + 1.f);

        // Draw the opaque exterior silhouette through four disjoint clips.
        // The center is never painted, so already-submitted menu content stays
        // intact. The four corner wedges below restore the rounded interior
        // edge instead of leaving the rejected transparent square gaps.
        drawList->PushClipRect(
            expandedOuterMinimum,
            expandedOuterMaximum,
            false);
        const auto drawOuterSurfaceThrough =
            [&](const ImVec2& minimum, const ImVec2& maximum)
            {
                if (maximum.x <= minimum.x || maximum.y <= minimum.y)
                    return;
                drawList->PushClipRect(minimum, maximum, true);
                drawList->AddRectFilled(
                    outerRect.Min,
                    outerRect.Max,
                    frameColor,
                    outerRadius,
                    ImDrawFlags_RoundCornersAll);
                drawList->PopClipRect();
            };
        drawOuterSurfaceThrough(
            expandedOuterMinimum,
            ImVec2(outerRect.Max.x + 1.f, innerRect.Min.y));
        drawOuterSurfaceThrough(
            ImVec2(outerRect.Min.x - 1.f, innerRect.Max.y),
            expandedOuterMaximum);
        drawOuterSurfaceThrough(
            ImVec2(outerRect.Min.x - 1.f, innerRect.Min.y),
            ImVec2(innerRect.Min.x, innerRect.Max.y));
        drawOuterSurfaceThrough(
            ImVec2(innerRect.Max.x, innerRect.Min.y),
            ImVec2(outerRect.Max.x + 1.f, innerRect.Max.y));

        if (innerRadius > 0.f)
        {
            const int cornerSegments = std::max(
                3,
                drawList->_CalcCircleAutoSegmentCount(innerRadius) / 4);
            const auto drawInnerCornerWedge =
                [&](const ImVec2& squareCorner,
                    const ImVec2& arcCenter,
                    float startAngle,
                    float endAngle)
                {
                    std::vector<ImVec2> points;
                    points.reserve(static_cast<size_t>(cornerSegments) + 2u);
                    points.push_back(squareCorner);
                    for (int segment = 0;
                        segment <= cornerSegments;
                        ++segment)
                    {
                        const float amount =
                            float(segment) / float(cornerSegments);
                        const float angle =
                            startAngle + (endAngle - startAngle) * amount;
                        points.emplace_back(
                            arcCenter.x + std::cos(angle) * innerRadius,
                            arcCenter.y + std::sin(angle) * innerRadius);
                    }
                    float twiceArea = 0.f;
                    for (size_t index = 0;
                        index < points.size();
                        ++index)
                    {
                        const ImVec2& current = points[index];
                        const ImVec2& next =
                            points[(index + 1u) % points.size()];
                        twiceArea +=
                            current.x * next.y - current.y * next.x;
                    }
                    if (twiceArea < 0.f)
                        std::reverse(points.begin(), points.end());
                    drawList->AddConcavePolyFilled(
                        points.data(),
                        static_cast<int>(points.size()),
                        frameColor);
                };
            drawInnerCornerWedge(
                innerRect.Min,
                ImVec2(
                    innerRect.Min.x + innerRadius,
                    innerRect.Min.y + innerRadius),
                -IM_PI * 0.5f,
                -IM_PI);
            drawInnerCornerWedge(
                ImVec2(innerRect.Max.x, innerRect.Min.y),
                ImVec2(
                    innerRect.Max.x - innerRadius,
                    innerRect.Min.y + innerRadius),
                -IM_PI * 0.5f,
                0.f);
            drawInnerCornerWedge(
                innerRect.Max,
                ImVec2(
                    innerRect.Max.x - innerRadius,
                    innerRect.Max.y - innerRadius),
                0.f,
                IM_PI * 0.5f);
            drawInnerCornerWedge(
                ImVec2(innerRect.Min.x, innerRect.Max.y),
                ImVec2(
                    innerRect.Min.x + innerRadius,
                    innerRect.Max.y - innerRadius),
                IM_PI * 0.5f,
                IM_PI);
        }
        drawList->PopClipRect();
    }

auto UIRenderer::DrawRootPanelSummaryBackground(
        ImDrawList* drawList,
        const ImRect& bodyRect,
        const ImRect& summaryRect,
        float rounding) -> void {
        if (!drawList ||
            bodyRect.GetWidth() <= 1.f ||
            bodyRect.GetHeight() <= 1.f ||
            summaryRect.GetWidth() <= 1.f ||
            summaryRect.GetHeight() <= 1.f)
        {
            return;
        }

        const ImRect clippedContentRect(
            ImVec2(
                std::max(bodyRect.Min.x, summaryRect.Min.x),
                std::max(bodyRect.Min.y, summaryRect.Min.y)),
            ImVec2(
                std::min(bodyRect.Max.x, summaryRect.Max.x),
                std::min(bodyRect.Max.y, summaryRect.Max.y)));
        if (clippedContentRect.GetWidth() <= 1.f ||
            clippedContentRect.GetHeight() <= 1.f)
        {
            return;
        }

        drawList->PushClipRect(
            bodyRect.Min,
            bodyRect.Max,
            false);
        drawList->AddRectFilled(
            clippedContentRect.Min,
            clippedContentRect.Max,
            ImGui::GetColorU32(GetOpaquePanelBodySurface()),
            ResolveRoundedRectRadius(clippedContentRect, rounding),
            ImDrawFlags_RoundCornersAll);
        drawList->PopClipRect();
    }

auto UIRenderer::DrawRootPanelBodySurface(
        ImDrawList* drawList,
        const ImRect& bodyRect,
        const ImRect& contentRect,
        const ImRect& summaryRect,
        float rounding) -> void {
        DrawFilledRoundedInsetFrame(
            drawList,
            bodyRect,
            contentRect,
            rounding);
        DrawRootPanelSummaryBackground(
            drawList,
            bodyRect,
            summaryRect,
            rounding);
    }

auto UIRenderer::DrawRootPanelBodyOutlines(
        ImDrawList* drawList,
        const ImRect& bodyRect,
        const ImRect& contentRect,
        float rounding) -> void {
        DrawDrawerBodyOutline(
            drawList,
            bodyRect.Min,
            bodyRect.Max,
            rounding,
            0.f,
            false);
        DrawDrawerBodyOutline(
            drawList,
            contentRect.Min,
            contentRect.Max,
            rounding,
            0.f,
            false);
    }

auto UIRenderer::DrawRootPanelBodyChrome(
        ImDrawList* drawList,
        const ImRect& bodyRect,
        const ImRect& contentRect,
        const ImRect& summaryRect,
        float rounding) -> void {
        DrawRootPanelBodySurface(
            drawList,
            bodyRect,
            contentRect,
            summaryRect,
            rounding);
        DrawRootPanelBodyOutlines(
            drawList,
            bodyRect,
            contentRect,
            rounding);
    }

auto UIRenderer::DrawCompactRootPanelBody(
        ImDrawList* drawList,
        const ImRect& bodyRect,
        const ImRect& contentRect,
        float rounding,
        const char* text) -> ImRect {
        const ImVec2 textSize = ImGui::CalcTextSize(text);
        const ImVec2 textMinimum(
            contentRect.Min.x + g_UiSpacingTokens.tight,
            contentRect.Min.y);
        const ImRect textRect(
            textMinimum,
            ImVec2(
                textMinimum.x + textSize.x,
                textMinimum.y + textSize.y));
        DrawRootPanelBodyChrome(
            drawList,
            bodyRect,
            contentRect,
            contentRect,
            rounding);
        drawList->PushClipRect(
            textMinimum,
            ImVec2(contentRect.Max.x, bodyRect.Max.y),
            true);
        drawList->AddText(
            textMinimum,
            ImGui::GetColorU32(ImGuiCol_Text),
            text);
        drawList->PopClipRect();
        return textRect;
    }

void UIRenderer::EndDrawerBody()
{
    ImGui::PopItemWidth();
    ImGuiStyle& style = ImGui::GetStyle();
    const float itemSpacingY = std::exchange(style.ItemSpacing.y, 0.f);
    ImGui::EndChild();
    style.ItemSpacing.y = itemSpacingY;
    DrawDrawerBodyOutline(ImGui::GetWindowDrawList(), ImGui::GetItemRectMin(),
        ImGui::GetItemRectMax(), style.ChildRounding, 2.f, true);
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(4);
}

void UIRenderer::BeginControlRegion(ImGuiID id)
{
    const float width = ImGui::CalcItemWidth();
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.f, 0.f, 0.f, 0.f));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0.f, 0.f));
    ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 0.f);
    ImGui::BeginChild(id, ImVec2(0.f, 0.f),
        ImGuiChildFlags_AutoResizeY | ImGuiChildFlags_AlwaysAutoResize,
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    ImGui::PushItemWidth(width);
}

void UIRenderer::EndControlRegion()
{
    ImGui::PopItemWidth();
    ImGui::EndChild();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor();
}

bool UIRenderer::BeginSettingsTree(const char* label, ImGuiTreeNodeFlags flags, const char* tooltip)
{
    const ImGuiID id = ImGui::GetID(label);
    const bool open = ImGui::TreeNodeEx(label, flags | ImGuiTreeNodeFlags_NoTreePushOnOpen);
    if (tooltip)
        ImGui::SetItemTooltip("%s", tooltip);
    if (!open)
        return false;
    BeginControlRegion(id ^ ImGuiID(0xE60792B5u));
    const float indent = ImGui::GetStyle().IndentSpacing;
    ImGui::Indent(indent);
    g_NestedDrawerContexts.push_back({ ImGui::GetCurrentWindow(), indent });
    return true;
}

void UIRenderer::EndSettingsTree()
{
    assert(!g_NestedDrawerContexts.empty());
    ImGui::Unindent(g_NestedDrawerContexts.back().indentSpacing);
    g_NestedDrawerContexts.pop_back();
    ImGuiStyle& style = ImGui::GetStyle();
    const float itemSpacingY = std::exchange(style.ItemSpacing.y, 0.f);
    EndControlRegion();
    style.ItemSpacing.y = itemSpacingY;
}

bool UIRenderer::BeginToggleRegion(const char* id, bool visible)
{
    if (!visible)
        return false;
    BeginControlRegion(ImGui::GetID(id) ^ ImGuiID(0x6C3E91B7u));
    return true;
}

auto UIRenderer::DrawMaterialEditorTextureFilename(
        const char* filename,
        const float4& color) -> void {
        const std::string_view fullFilename =
            filename != nullptr ? std::string_view(filename) : std::string_view();
        const FrontEllipsisText formatted =
            FormatFrontEllipsisUtf8(fullFilename, 25u);
        ImGui::TextColored(
            ImVec4(color.x, color.y, color.z, color.w),
            "%s",
            formatted.display.c_str());
        if (formatted.truncated)
        {
            const FrontEllipsisText tooltip =
                FormatFrontEllipsisUtf8(fullFilename, 117u);
            ImGui::SetItemTooltip("%s", tooltip.display.c_str());
        }
    }

auto UIRenderer::DrawUvsrColorEdit(
        const char* label,
        float* color,
        UvsrColorEditChannels channels) -> bool {
        ImGuiColorEditFlags flags =
            ImGuiColorEditFlags_Float |
            ImGuiColorEditFlags_DisplayRGB |
            ImGuiColorEditFlags_NoTooltip;
        if (channels == UvsrColorEditChannels::Rgba)
        {
            flags |=
                ImGuiColorEditFlags_AlphaBar |
                ImGuiColorEditFlags_AlphaPreviewHalf;
        }
        if (!ImGui::IsUvsrStockWidgetRenderingEnabled())
            flags |= ImGuiColorEditFlags_PickerHueWheel;
        return channels == UvsrColorEditChannels::Rgba
            ? ImGui::ColorEdit4(label, color, flags)
            : ImGui::ColorEdit3(label, color, flags);
    }

auto UIRenderer::SetNextLabeledControlWidth(
        const char* label,
        float preferredWidth) -> void {
        const ImGuiStyle& style = ImGui::GetStyle();
        const char* visibleLabelEnd =
            ImGui::FindRenderedTextEnd(label);
        const float visibleLabelWidth = visibleLabelEnd == label
            ? 0.f
            : ImGui::CalcTextSize(label, visibleLabelEnd).x +
                style.ItemInnerSpacing.x;
        const float resetLaneWidth =
            ImGui::GetFrameHeight() * 0.78f +
            style.ItemInnerSpacing.x;
        const float minimumControlWidth =
            ImGui::GetFrameHeight() * 3.f;
        const float maximumControlWidth = std::max(
            minimumControlWidth,
            ImGui::GetContentRegionAvail().x -
                visibleLabelWidth - resetLaneWidth);
        ImGui::SetNextItemWidth(std::min(
            preferredWidth,
            maximumControlWidth));
    }

auto UIRenderer::DrawPresetResetIcon(
        const char* id,
        bool modified,
        const char* tooltip,
        bool nestedDropdownGutterRequested) -> bool {
        ImGui::PushID(id);
        const ImGuiStyle& style = ImGui::GetStyle();
        const float buttonSize = ImGui::GetFrameHeight() * 0.78f;

        const bool nestedDropdownGutterAvailable =
            nestedDropdownGutterRequested &&
            !g_NestedDrawerContexts.empty() &&
            ImGui::GetCurrentWindow() ==
                g_NestedDrawerContexts.back().bodyWindow;
        if (nestedDropdownGutterRequested)
        {
            assert(nestedDropdownGutterAvailable);
        }
        if (nestedDropdownGutterAvailable)
        {
            const NestedDrawerContext& context =
                g_NestedDrawerContexts.back();
            ImGuiWindow* window = ImGui::GetCurrentWindow();
            const float resetButtonScreenX =
                ImGui::GetCursorScreenPos().x +
                (-context.indentSpacing +
                    (context.indentSpacing - buttonSize) * 0.5f);
            const float sameLineOffset =
                resetButtonScreenX - window->Pos.x + window->Scroll.x -
                window->DC.GroupOffset.x - window->DC.ColumnsOffset.x;
            ImGui::SameLine(sameLineOffset, 0.f);
        }
        else
        {
            // Keep the established trailing lane unchanged for un-nested
            // dropdowns and every non-dropdown control.
            ImGui::SameLine(0.f, style.ItemInnerSpacing.x);
            const float rightAlignedX =
                ImGui::GetContentRegionMax().x - buttonSize;
            if (ImGui::GetCursorPosX() < rightAlignedX)
                ImGui::SetCursorPosX(rightAlignedX);
        }

        ImGui::PushStyleVar(
            ImGuiStyleVar_Alpha,
            modified ? style.Alpha : 0.f);
        ImGui::BeginDisabled(!modified);
        // Route through the native button frame so the reset control receives
        // the same Amp gradient outline and interaction surface as every other
        // framed menu element.
        const bool pressed = ImGui::Button(
            "##PresetReset",
            ImVec2(buttonSize, buttonSize));
        ImDrawList* drawList = ImGui::GetWindowDrawList();
        const ImVec2 minimum = ImGui::GetItemRectMin();
        const ImVec2 maximum = ImGui::GetItemRectMax();
        const ImVec2 center(
            (minimum.x + maximum.x) * 0.5f,
            (minimum.y + maximum.y) * 0.5f);
        constexpr float Pi = 3.14159265358979323846f;
        const float radius = buttonSize * 0.24f;
        const ImU32 iconColor = ImGui::GetColorU32(ImGuiCol_Text);
        drawList->PathClear();
        drawList->PathArcTo(
            center,
            radius,
            Pi * 0.12f,
            Pi * 1.72f,
            14);
        drawList->PathStroke(iconColor, false, 1.5f);
        const ImVec2 arrowTip(
            center.x + radius * std::cos(Pi * 0.12f),
            center.y + radius * std::sin(Pi * 0.12f));
        drawList->AddTriangleFilled(
            ImVec2(
                arrowTip.x + buttonSize * 0.01f,
                arrowTip.y - buttonSize * 0.16f),
            ImVec2(
                arrowTip.x + buttonSize * 0.16f,
                arrowTip.y + buttonSize * 0.01f),
            ImVec2(
                arrowTip.x - buttonSize * 0.05f,
                arrowTip.y + buttonSize * 0.04f),
            iconColor);
        if (modified)
            ImGui::SetItemTooltip("%s", tooltip);
        ImGui::EndDisabled();
        ImGui::PopStyleVar();
        ImGui::PopID();
        return pressed && modified;
    }





void UIRenderer::DrawPerformancePanelContents(
    float settingsControlWidth, const std::string& performanceLine)
{
    ImGui::PushItemWidth(settingsControlWidth);
    const float summaryCursorX = ImGui::GetCursorPosX();
    ImGui::SetCursorPosX(summaryCursorX + g_UiSpacingTokens.tight);
    ImGui::TextUnformatted(performanceLine.c_str());
    ImGui::SetItemTooltip("%s",
        "tris counts main-pass triangles after frustum culling; "
        "occluded, back-facing, or alpha-discarded ones may remain.");
    ImGui::SetCursorPosX(summaryCursorX);

    using Stage = RendererTimingStage;
    struct StatisticsView
    {
        const char* label;
        const char* table;
        const char* column;
        std::initializer_list<Stage> stages;
    };
    static const StatisticsView views[] = {
        { "Complete Renderer", "##CompleteRendererStatistics", "Graphics Stage", {
            Stage::CompleteFrame, Stage::SceneSetup, Stage::Geometry, Stage::PathTransport,
            Stage::ShadowRayDispatch, Stage::SkyVisibilityRayDispatch, Stage::DirectLighting,
            Stage::ScreenSpaceVisibility,
            Stage::MaterialPicking, Stage::EnvironmentBackground, Stage::AutoExposure,
            Stage::ToneMapping, Stage::FastApproximate, Stage::OutputBlit } },
        { "Scene Setup", "##SelectedRendererStatistics", "Graphics Stage", { Stage::SceneSetup } },
        { "Geometry", "##SelectedRendererStatistics", "Graphics Stage", { Stage::Geometry } },
        { "Path Transport", "##SelectedRendererStatistics", "Graphics Stage", { Stage::PathTransport } },
        { "Direct Lighting", "##DirectLightingStatistics", "Lighting Stage", {
            Stage::DirectLighting } },
        { "Screen Space Visibility", "##VisibilityStatistics", "Visibility Metric", {} },
        { "Directional Shadows", "##ShadowStatistics", "Shadow Metric", {
            Stage::ShadowRayDispatch, Stage::SkyVisibilityRayDispatch } },
        { "Fast Approximate", "##SelectedRendererStatistics", "Graphics Stage", { Stage::FastApproximate } },
        { "Material Picking", "##SelectedRendererStatistics", "Graphics Stage", { Stage::MaterialPicking } },
        { "Environment Background", "##SelectedRendererStatistics", "Graphics Stage", { Stage::EnvironmentBackground } },
        { "Tone Mapping", "##ToneMappingStatistics", "Graphics Stage", { Stage::AutoExposure, Stage::ToneMapping } },
        { "Output Blit", "##SelectedRendererStatistics", "Graphics Stage", { Stage::OutputBlit } }
    };
    static_assert(std::size(views) == size_t(StatisticsEffect::Count));
    m_StatisticsEffect = std::clamp(m_StatisticsEffect, 0, int(std::size(views)) - 1);
    if (ImGui::BeginCombo("##StatisticsEffect", views[m_StatisticsEffect].label))
    {
        for (int index = 0; index < int(std::size(views)); ++index)
        {
            DrawDropdownOption(views[index].label, m_StatisticsEffect == index,
                [this, index]() { m_StatisticsEffect = index; });
            if (m_StatisticsEffect == index)
                ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }
    ImGui::SetItemTooltip("Choose GPU renderer timings. These exclude CPU work, UI rendering, presentation, and frame-limiter waits. The frame interval and FPS above include the whole loop.");
    const auto& view = views[m_StatisticsEffect];
    const auto effect = StatisticsEffect(m_StatisticsEffect);
    const RendererTimings& timings = m_app->GetRendererTimings();
    ImGui::PushID(m_StatisticsEffect);
    if (ImGui::BeginTable(view.table, 2, ImGuiTableFlags_BordersInnerH |
        ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp))
    {
        ImGui::TableSetupColumn(view.column, ImGuiTableColumnFlags_WidthStretch, 3.f);
        ImGui::TableSetupColumn("Current", ImGuiTableColumnFlags_WidthStretch, 1.35f);
        const auto beginRow = [](const char* label, bool available)
        {
            ImGui::TableNextRow();
            ImGui::TableSetColumnIndex(0);
            if (available)
                ImGui::TextUnformatted(label);
            else
                ImGui::TextDisabled("%s", label);
            ImGui::TableSetColumnIndex(1);
        };
        const auto milliseconds = [&](const char* label, double value, bool available)
        {
            const auto row = m_PerformanceTimingRows.Resolve(
                uint32_t(effect), ImHashStr(label), value, available);
            if (!row.IsVisible())
                return;
            beginRow(label, row.HasMeasurement());
            if (row.HasMeasurement())
                ImGui::Text("%.3f ms", row.milliseconds);
            else
                ImGui::TextDisabled("--");
        };
        const auto count = [&](const char* label, uint64_t value, bool available)
        {
            beginRow(label, available);
            if (available)
                ImGui::Text("%llu", static_cast<unsigned long long>(value));
            else
                ImGui::TextDisabled("--");
        };
        const auto memory = [&](const char* label, uint64_t bytes, bool available)
        {
            beginRow(label, available);
            if (available)
                ImGui::Text("%.2f MiB", double(bytes) / (1024.0 * 1024.0));
            else
                ImGui::TextDisabled("--");
        };
        const auto text = [&](const char* label, const char* value, bool available)
        {
            beginRow(label, available);
            if (available)
                ImGui::TextUnformatted(value);
            else
                ImGui::TextDisabled("--");
        };
        const auto renderer = [&](Stage stage, bool eligible = true)
        {
            static constexpr std::pair<Stage, const char*> labels[] = {
                { Stage::CompleteFrame, "Complete Renderer Frame (GPU)" },
                { Stage::SceneSetup, "Scene Setup and Clears" },
                { Stage::Geometry, "Geometry" },
                { Stage::PathTransport, "Path Transport" },
                { Stage::ShadowRayDispatch, "Shadow Ray Dispatch" },
                { Stage::SkyVisibilityRayDispatch, "Sky Visibility Ray Dispatch" },
                { Stage::DirectLighting, "Direct Lighting" },
                { Stage::ScreenSpaceVisibility, "Screen Space Visibility" },
                { Stage::MaterialPicking, "Material Picking" },
                { Stage::EnvironmentBackground, "Environment Background" },
                { Stage::AutoExposure, "Auto Environment Exposure" },
                { Stage::ToneMapping, "Tone Mapping" },
                { Stage::FastApproximate, "Fast Approximate" },
                { Stage::OutputBlit, "Output Blit" }
            };
            static_assert(std::size(labels) == size_t(Stage::Count));
            for (const auto& [candidate, label] : labels)
            {
                if (candidate != stage)
                    continue;
                if (stage == Stage::ScreenSpaceVisibility)
                {
                    milliseconds(label, m_DisplayedVisibilityTimings.CompleteEffectMs(),
                        m_HasVisibilityStatSnapshot && m_DisplayedVisibilityTimings.active &&
                        m_DisplayedVisibilityTimings.available);
                }
                else
                {
                    const bool available = eligible && m_app->IsRendererStageActiveThisFrame(stage) &&
                        timings.IsAvailable(stage);
                    milliseconds(effect == StatisticsEffect::SceneSetup && stage == Stage::SceneSetup ? view.label : label,
                        available ? timings.Get(stage) : 0.0, available);
                }
                return;
            }
        };

        for (Stage stage : view.stages)
            renderer(stage);
        if (effect == StatisticsEffect::Visibility)
        {
            const auto& visibility = m_DisplayedVisibilityTimings;
            const bool available = m_HasVisibilityStatSnapshot;
            milliseconds("Complete Effect", visibility.CompleteEffectMs(), available);
            milliseconds("First Trace", visibility.firstTraceMs, available);
            milliseconds("Upsample", visibility.reconstructionMs, available);
            milliseconds("Composition", visibility.compositionMs, available);
            memory("Output Texture Memory", visibility.outputTextureBytes, available);
            memory("Working Texture Memory", visibility.workingTextureBytes, available);
            count("Dispatches", visibility.activeDispatchCount, available);
            count("Read Resources", visibility.activeSrvCount, available);
            count("Write Resources", visibility.activeUavCount, available);
        }
        if (effect != StatisticsEffect::CompleteRenderer)
            renderer(Stage::CompleteFrame);
        ImGui::EndTable();
    }
    ImGui::PopID();
    ImGui::PopItemWidth();
}

UiSettingsValue UIRenderer::ReadUiPresentationValue(SettingId id)
{
    UiSettingsValue value;
    std::string error;
    // Disabled rows still display their retained values. Command reads keep
    // their availability checks; this read never requests a mutation.
    if (!DispatchTypedSetting(GetUiSettingDefinition(id), nullptr, value, error, true, true))
        uvsr::log::warning("UI setting read failed for %s: %s", SettingName(id).data(), error.c_str());
    return value;
}

bool UIRenderer::ApplyUiSetting(SettingId id, const UiSettingsValue& value)
{
    std::string error;
    const bool applied = ApplySettingValue(id, value, error);
    if (!applied)
        uvsr::log::warning("UI setting update failed: %s", error.c_str());
    return applied;
}

bool UIRenderer::ResetUiSetting(SettingId id)
{
    std::string error;
    const bool reset = ResetSettingValue(id, error);
    if (!reset)
        uvsr::log::warning("UI setting reset failed: %s", error.c_str());
    return reset;
}

bool UIRenderer::IsUiSettingChanged(SettingId id)
{
    const auto* definition = FindSettingsCommandDefinition(id);
    if (!definition || !definition->Supports(UiSettingsCommandVerb::Reset) ||
        !IsSettingAvailable(id))
        return false;
    std::string error;
    const bool atDefault = IsSettingAtContextualDefault(id, error);
    if (!error.empty())
        uvsr::log::warning("UI setting default check failed: %s", error.c_str());
    return error.empty() && !atDefault;
}

std::size_t UIRenderer::ReadUiTokenIndex(SettingId id)
{
    UiSettingsValue value;
    std::string error;
    if (ReadSettingValue(id, value, error) && value.kind == UiSettingsValueKind::Token)
        return GetUiSettingTokenIndex(id, value.text);
    uvsr::log::warning("UI setting read failed for %s: %s", SettingName(id).data(), error.c_str());
    return 0u;
}

bool UIRenderer::DrawUiReset(
    SettingId id, bool nested, const char* resetId, const char* tooltip)
{
    const bool changed = IsUiSettingChanged(id);
    const char* label = resetId ? resetId : SettingName(id).data();
    const bool pressed = DrawPresetResetIcon(label, changed, tooltip, nested);
    if (pressed)
        ResetUiSetting(id);
    return pressed;
}

void UIRenderer::DrawUiBoolean(
    const char* label, SettingId id, const char* tooltip,
    bool nestedReset, const std::string* texturePath, const char* resetId)
{
    bool current = ReadUiPresentationValue(id).boolean;
    if (ImGui::Checkbox(label, &current))
        ApplyUiSetting(id, UiSettingsValue::Boolean(current));
    ImGui::SetItemTooltip("%s", tooltip);
    if (texturePath)
    {
        ImGui::SameLine();
        const ImVec4 color = g_UiVisualTokens.successText;
        DrawMaterialEditorTextureFilename(texturePath->c_str(), float4(color.x, color.y, color.z, color.w));
    }
    DrawUiReset(id, nestedReset, resetId);
}

void UIRenderer::DrawUiFloat(
    const char* label, SettingId id, const char* format,
    const char* tooltip, ImGuiSliderFlags flags, bool nestedReset,
    float width, bool useContextMaximum)
{
    const UiSettingRange range = GetUiSettingRange(id, useContextMaximum);
    float candidate = ReadUiPresentationValue(id).scalar * range.displayScale;
    if (width > 0.f)
        SetNextLabeledControlWidth(label, width);
    if (DrawBoundedSlider(label, &candidate,
            range.safeMinimum, range.safeMaximum, range.trackMinimum, range.trackMaximum,
            format, flags))
    {
        ApplyUiSetting(id, UiSettingsValue::Float(candidate / range.displayScale));
    }
    ImGui::SetItemTooltip("%s", tooltip);
    DrawUiReset(id, nestedReset);
}

void UIRenderer::DrawUiInteger(
    const char* label, SettingId id, const char* format,
    const char* tooltip, ImGuiSliderFlags flags, bool nestedReset)
{
    const UiSettingRange range = GetUiSettingRange(id);
    int current = static_cast<int>(ReadUiPresentationValue(id).integer);
    if (DrawBoundedSlider(label, &current,
            static_cast<int>(range.safeMinimum), static_cast<int>(range.safeMaximum),
            static_cast<int>(range.trackMinimum), static_cast<int>(range.trackMaximum), format, flags))
    {
        ApplyUiSetting(id, UiSettingsValue::Integer(current));
    }
    ImGui::SetItemTooltip("%s", tooltip);
    DrawUiReset(id, nestedReset);
}

void UIRenderer::DrawUiInheritedNumber(const char* label, SettingId id,
    const UiSettingsValue& inherited, const char* format, const char* tooltip)
{
    const auto& domain = GetUiSettingDefinition(id).typedDomain;
    const UiSettingRange range = GetUiSettingRange(id);
    assert(domain.hasAlternative);
    UiSettingsValue candidate = ReadUiPresentationValue(id);
    if (domain.kind == UiSettingsDomainKind::Integer)
    {
        int current = int(candidate.integer == int64_t(domain.alternative)
            ? inherited.integer : candidate.integer);
        if (DrawBoundedSlider(label, &current, int(range.safeMinimum), int(range.safeMaximum),
            int(range.trackMinimum), int(range.trackMaximum), format))
        {
            ApplyUiSetting(id, UiSettingsValue::Integer(current == inherited.integer
                ? int64_t(domain.alternative) : current));
        }
    }
    else
    {
        float current = (candidate.scalar == float(domain.alternative)
            ? inherited.scalar : candidate.scalar) * range.displayScale;
        if (DrawBoundedSlider(label, &current, range.safeMinimum, range.safeMaximum,
            range.trackMinimum, range.trackMaximum, format))
        {
            current /= range.displayScale;
            ApplyUiSetting(id, UiSettingsValue::Float(std::abs(current - inherited.scalar) < 1e-4f
                ? float(domain.alternative) : current));
        }
    }
    ImGui::SetItemTooltip("%s", tooltip);
    DrawUiReset(id);
}

void UIRenderer::DrawUiColor(
    const char* label, SettingId id, const char* tooltip, const char* resetId,
    float width, bool enabled)
{
    if (!enabled)
        return;
    const auto channels = GetUiSettingDefinition(id).typedDomain.kind == UiSettingsDomainKind::Float4
        ? UvsrColorEditChannels::Rgba : UvsrColorEditChannels::Rgb;
    const std::uint8_t count = channels == UvsrColorEditChannels::Rgba ? 4u : 3u;
    UiSettingsValue value = UiSettingsValue::Vector({ 0.f, 0.f, 0.f, 1.f }, count);
    std::string error;
    if (IsSettingAvailable(id) && !ReadSettingValue(id, value, error))
        uvsr::log::warning("UI color read failed: %s", error.c_str());
    if (width > 0.f)
        SetNextLabeledControlWidth(label, width);
    if (DrawUvsrColorEdit(label, value.vector.data(), channels))
    {
        ClampUiSettingColor(id, value.vector.data(), count);
        ApplyUiSetting(id, value);
    }
    ImGui::SetItemTooltip("%s", tooltip);
    DrawUiReset(id, false, resetId);

}

void UIRenderer::DrawUiTokenOption(SettingId id, std::size_t index, bool selected)
{
    const std::string label = FormatUiSettingsTokenLabel(id, index);
    DrawDropdownOption(label.c_str(), selected, [this, id, index]()
    {
        ApplyUiSetting(id, UiSettingsValue::Token(GetUiSettingToken(id, index)));
    });
}

void UIRenderer::DrawUiRoundedTokenCombo(
    const char* label, SettingId id, bool custom, bool focusSelected)
{
    const auto& domain = GetUiSettingDefinition(id).typedDomain;
    const std::size_t current = ReadUiTokenIndex(id);
    std::string preview = FormatUiSettingsTokenLabel(id, current);
    if (custom)
        preview += " (Custom)";
    if (!ImGui::BeginCombo(label, preview.c_str()))
        return;
    for (std::size_t index = 0u; index < domain.tokenCount; ++index)
    {
        DrawUiTokenOption(id, index, !custom && index == current);
        if (focusSelected && index == current)
            ImGui::SetItemDefaultFocus();
    }
    ImGui::EndCombo();
}

void UIRenderer::DrawUiTokenCombo(
    const char* label, SettingId id, const char* tooltip, bool nestedReset)
{
    const auto& domain = GetUiSettingDefinition(id).typedDomain;
    std::array<std::string, UiSettingsTypedDomain::MaximumTokenCount> labels;
    std::array<const char*, UiSettingsTypedDomain::MaximumTokenCount> pointers{};
    for (std::size_t index = 0u; index < domain.tokenCount; ++index)
    {
        labels[index] = FormatUiSettingsTokenLabel(id, index);
        pointers[index] = labels[index].c_str();
    }
    int candidate = static_cast<int>(ReadUiTokenIndex(id));
    if (ImGui::Combo(label, &candidate, pointers.data(), domain.tokenCount))
        ApplyUiSetting(id, UiSettingsValue::Token(GetUiSettingToken(id, std::size_t(candidate))));
    ImGui::SetItemTooltip("%s", tooltip);
    DrawUiReset(id, nestedReset);
}

auto UIRenderer::DrawGeneralDrawer(float settingsControlWidth) -> void {
        const bool generalOpen = DrawCollapsingHeader(
            "General",
            "Show general renderer settings.",
            ImGuiTreeNodeFlags_DefaultOpen);
        if (!generalOpen)
        {
            ImGui::Spacing();
            return;
        }

        BeginDrawerBody("##GeneralBody", settingsControlWidth);

        ImGui::TextUnformatted("Lighting Solution");
        ImGui::SetNextItemWidth(-FLT_MIN);
        DrawUiRoundedTokenCombo("##LightingSolution", SettingId::LightingSolution);
        ImGui::SetItemTooltip(
            "Choose the scene-lighting pipeline. Ray Marching retains the "
            "existing screen-space and selective ray-traced techniques; Path "
            "Tracing uses the shared complete transport core.");

        if (!m_ui.GpuAdapterChoices.empty())
        {
            const GpuAdapterChoice* activeAdapter =
                GetActiveGpuAdapterChoice();
            const char* activeAdapterName = activeAdapter
                ? activeAdapter->name.c_str()
                : "Unknown adapter";

            ImGui::TextUnformatted("Graphics Adapter");
            ImGui::SetNextItemWidth(-FLT_MIN);
            if (ImGui::BeginCombo(
                    "##GraphicsAdapter",
                    activeAdapterName))
            {
                for (const GpuAdapterChoice& adapter :
                    m_ui.GpuAdapterChoices)
                {
                    const bool selected =
                        adapter.adapterIndex ==
                        m_ui.ActiveGpuAdapterIndex;
                    DrawDropdownOption(
                        adapter.name.c_str(),
                        selected,
                        [this, adapterIndex = adapter.adapterIndex]()
                        {
                            std::string error;
                            if (!ApplySettingValue(
                                    SettingId::GpuAdapter,
                                    UiSettingsValue::Selector(
                                        FormatSettingsSnapshotAdapterToken(
                                            adapterIndex)),
                                    error))
                            {
                                uvsr::log::warning(
                                    "Graphics adapter update failed: %s",
                                    error.c_str());
                            }
                        });
                    if (selected)
                        ImGui::SetItemDefaultFocus();
                }
                ImGui::EndCombo();
            }
            ImGui::SetItemTooltip(
                "Choose the graphics processor. UVSR restarts after a "
                "change.");
        }


        ImGui::TextUnformatted("Camera Mode");
        DrawUiReset(SettingId::CameraMode, false, "Camera Mode");
        ImGui::SetNextItemWidth(-FLT_MIN);
        DrawUiRoundedTokenCombo("##Camera", SettingId::CameraMode);
        ImGui::SetItemTooltip(
            "Choose Freelook or Locked. Q moves up, E moves down, X/C roll, "
            "and V levels the roll.");

        const ImGuiStyle& style = ImGui::GetStyle();
        const std::string currentScene =
            m_app->GetCurrentSceneName();
        const std::string currentSceneDisplayName =
            m_app->GetCurrentSceneDisplayName();
        const float folderButtonWidth = ImGui::GetFrameHeight();
        ImGui::TextUnformatted("World Scenes");
        ImGui::SetNextItemWidth(
            -(folderButtonWidth + style.ItemSpacing.x));
        if (ImGui::BeginCombo(
                "##Scene",
                currentSceneDisplayName.c_str()))
        {
            const std::vector<SceneCatalogEntry>& scenes =
                m_app->GetAvailableScenes();
            for (const SceneCatalogEntry& scene : scenes)
            {
                ImGui::PushID(scene.FileName.c_str());
                const bool selected =
                    scene.FileName == currentScene;
                DrawDropdownOption(
                    scene.DisplayName.c_str(),
                    selected,
                    [this,
                        sceneToken = FormatSettingsSnapshotSceneToken(
                            MakeSceneDisplayName(m_app->GetSceneDir(), scene.FileName))]()
                    {
                        ApplyUiSetting(
                            SettingId::SceneCurrent,
                            UiSettingsValue::Selector(sceneToken));
                    });
                if (selected)
                    ImGui::SetItemDefaultFocus();
                ImGui::PopID();
            }
            ImGui::EndCombo();
        }
        ImGui::SetItemTooltip("Load a different scene.");

        ImGui::SameLine();
        const bool openSceneFolderPressed = ImGui::Button(
            "##OpenSceneFolder",
            ImVec2(folderButtonWidth, ImGui::GetFrameHeight()));
        const ImVec2 iconMinimum = ImGui::GetItemRectMin();
        const ImVec2 iconMaximum = ImGui::GetItemRectMax();
        if (openSceneFolderPressed)
        {
            std::string error;
            if (!RunAction(ActionId::OpenSceneFolder, error))
            {
                uvsr::log::warning(
                    "Open scene folder failed: %s",
                    error.c_str());
            }
        }
        ImDrawList* drawList = ImGui::GetWindowDrawList();
        const float iconWidth = iconMaximum.x - iconMinimum.x;
        const float iconHeight = iconMaximum.y - iconMinimum.y;
        const ImU32 iconColor = ImGui::GetColorU32(ImGuiCol_Text);
        const ImVec2 folderBodyMinimum(
            iconMinimum.x + iconWidth * 0.20f,
            iconMinimum.y + iconHeight * 0.38f);
        const ImVec2 folderBodyMaximum(
            iconMaximum.x - iconWidth * 0.20f,
            iconMaximum.y - iconHeight * 0.22f);
        drawList->AddRect(
            folderBodyMinimum,
            folderBodyMaximum,
            iconColor,
            1.5f,
            0,
            1.5f);
        drawList->AddLine(
            folderBodyMinimum,
            ImVec2(
                folderBodyMinimum.x + iconWidth * 0.22f,
                iconMinimum.y + iconHeight * 0.27f),
            iconColor,
            1.5f);
        drawList->AddLine(
            ImVec2(
                folderBodyMinimum.x + iconWidth * 0.22f,
                iconMinimum.y + iconHeight * 0.27f),
            ImVec2(
                folderBodyMinimum.x + iconWidth * 0.40f,
                folderBodyMinimum.y),
            iconColor,
            1.5f);
        ImGui::SetItemTooltip("Open the scene folder.");

        if (m_SceneLoadFailed || m_app->HasSceneLoadFailure())
        {
            ImGui::PushStyleColor(
                ImGuiCol_Text,
                g_UiVisualTokens.errorText);
            const std::string& workerFailure =
                m_app->GetSceneLoadFailure();
            if (workerFailure.empty())
            {
                ImGui::TextWrapped(
                    "The selected scene could not be loaded.");
            }
            else
            {
                ImGui::TextWrapped(
                    "The selected scene could not be loaded: %s",
                    workerFailure.c_str());
            }
            ImGui::PopStyleColor();
            if (ImGui::Button(
                    "Retry Scene Load",
                    ImVec2(-FLT_MIN, 0.f)))
            {
                m_SceneLoadFailed = false;
                m_app->RetryCurrentSceneLoad();
            }
            ImGui::SetItemTooltip(
                "Retry loading the currently selected scene.");
        }

        EndDrawerBody();
        ImGui::Spacing();
    }

auto UIRenderer::DrawPathingDrawer(float settingsControlWidth) -> void {
        if (std::exchange(m_PathingDrawerOpenRequested, false))
            ImGui::SetNextItemOpen(true, ImGuiCond_Always);
        if (!DrawCollapsingHeader(
                "Path Tracing",
                "One conventional fixed MIS path tracer."))
        {
            return;
        }

        BeginDrawerBody("##PathingBody", settingsControlWidth);
        const WorldSpaceRepresentationStatus& representation =
            m_app->GetWorldSpaceRepresentationStatus();
        const PathTracingCapabilities& capabilities =
            m_app->GetPathTracingCapabilities();
        const PathTracingSceneDomainStatus sceneDomain =
            m_app->GetPathTracingSceneDomainStatus();
        if (!m_ui.Representation.allowRayTraversal)
        {
            ImGui::TextDisabled(
                "Enable Allow Ray Traversal in Developer > Advanced.");
        }
        else if (sceneDomain == PathTracingSceneDomainStatus::Unsupported)
        {
            ImGui::TextDisabled(
                "Path Tracing is unavailable for this scene's geometry or "
                "materials. It remains selected; no raster transport is "
                "substituted.");
        }
        else if (!capabilities.rayQuerySupported ||
            representation.state == WorldSpaceRepresentationState::Unsupported ||
            representation.state == WorldSpaceRepresentationState::Failed)
        {
            ImGui::TextDisabled(
                "DXR 1.1 inline ray queries and a valid world hierarchy are required.");
        }
        else if (representation.state == WorldSpaceRepresentationState::BuildingBlas ||
            representation.state == WorldSpaceRepresentationState::BuildingTlas)
        {
            ImGui::TextDisabled(
                "Preparing path transport: BLAS %u/%u.",
                representation.builtBlasCount,
                representation.totalBlasCount);
        }
        else if (m_app->GetSelectedLightingTransportState() ==
            SelectedLightingTransportState::PathTracingUnavailable)
        {
            ImGui::TextDisabled(
                "Path transport failed or is unavailable. Path Tracing "
                "remains selected and no raster transport is rendered.");
        }
        else if (m_app->GetSelectedLightingTransportState() ==
            SelectedLightingTransportState::PathTracingPreparing)
        {
            ImGui::TextDisabled("Preparing path transport.");
        }
        else
        {
            if (sceneDomain ==
                PathTracingSceneDomainStatus::BlendedGeometryOmitted)
            {
                ImGui::TextDisabled(
                    "Alpha-blended geometry is omitted; opaque and alpha-tested geometry is traced.");
            }
            ImGui::TextWrapped(
                "Fixed balance-heuristic MIS, %u path per pixel each dispatch, %u bounces, roulette after bounce %u.",
                PathTracingSamplesPerFrame,
                PathTracingBounceCount,
                PathTracingRussianRouletteStart);
            const uint64_t acceptedSampleCount =
                m_app->GetPathTracingCenterPixelAcceptedSampleCount();
            ImGui::Text(
                "Center-pixel accepted history: %llu sample%s",
                static_cast<unsigned long long>(acceptedSampleCount),
                acceptedSampleCount == 1u ? "" : "s");
            ImGui::SetItemTooltip(
                "Resets on camera, scene, resize, renderer-setting, and "
                "explicit history invalidation. This asynchronous GPU "
                "readback reports successful accumulated samples at the "
                "viewport center, not CPU dispatch attempts.");
        }
        EndDrawerBody();
    }

auto UIRenderer::DrawMaterialDrawer(float settingsControlWidth) -> void {
        ImGui::SetNextItemOpen(
            m_ui.ShowMaterialDrawer,
            ImGuiCond_Always);
        const bool materialBodyVisible = DrawCollapsingHeader(
            "Material",
            "Inspect and edit the surface under the center crosshair. Press M "
            "to refresh the center selection.",
            ImGuiTreeNodeFlags_None);
        const bool targetOpen = materialBodyVisible;
        if (targetOpen != m_ui.ShowMaterialDrawer)
        {
            ApplyUiSetting(
                SettingId::MaterialEditorVisible,
                UiSettingsValue::Boolean(targetOpen));
        }
        if (m_MaterialRevealRequested && targetOpen)
        {
            ImGui::SetScrollHereY(0.f);
            m_MaterialRevealRequested = false;
        }

        if (!materialBodyVisible)
        {
            ImGui::Spacing();
            return;
        }

        BeginDrawerBody("##MaterialBody", settingsControlWidth);
        auto material = m_ui.SelectedMaterial;
        if (material)
        {
            const std::string materialPrefix = "Material " + std::to_string(material->materialID) + ":";
            ImGui::BeginGroup();
            ImGui::TextUnformatted(materialPrefix.c_str());
            ImGui::SameLine(0.f, ImGui::GetStyle().ItemInnerSpacing.x);
            const float nameWidth = ImGui::GetContentRegionAvail().x;
            const bool truncated = ImGui::CalcTextSize(material->name.c_str()).x > nameWidth;
            std::string name = material->name;
            if (truncated)
            {
                const char* end = name.data();
                ImGui::GetFont()->CalcTextSizeA(ImGui::GetFontSize(),
                    std::max(0.f, nameWidth - ImGui::CalcTextSize("...").x), 0.f,
                    name.data(), name.data() + name.size(), &end);
                name.resize(size_t(end - name.data()));
                name += "...";
            }
            ImGui::TextColored(g_UiVisualTokens.successText, "%s", name.c_str());
            ImGui::EndGroup();
            if (truncated)
                ImGui::SetItemTooltip("%s", material->name.c_str());

            ImGui::PushID(material->materialID);

            SetNextLabeledControlWidth("Material Domain", settingsControlWidth);
            DrawUiRoundedTokenCombo(
                "Material Domain##MaterialDomain", SettingId::MaterialSelectedDomain, false, false);
            ImGui::SetItemTooltip(
                "Choose how the selected surface is rendered.");
            DrawUiReset(SettingId::MaterialSelectedDomain, false, "Material Domain");

            DrawUiBoolean(
                "Double-Sided",
                SettingId::MaterialSelectedDoubleSided,
                "Render both sides of the selected surface.");

            if (IsSettingAvailable(
                    SettingId::MaterialSelectedBaseTextureEnabled))
            {
                DrawUiBoolean(
                    material->useSpecularGlossModel
                        ? "Use Diffuse Texture"
                        : "Use Base Color Texture",
                    SettingId::MaterialSelectedBaseTextureEnabled,
                    "Enable the selected material's base or diffuse texture.",
                    false,
                    &material->baseOrDiffuseTexture->path);
            }
            DrawUiColor(
                material->useSpecularGlossModel
                    ? material->enableBaseOrDiffuseTexture
                        ? "Diffuse Factor"
                        : "Diffuse Color"
                    : material->enableBaseOrDiffuseTexture
                        ? "Base Color Factor"
                        : "Base Color",
                SettingId::MaterialSelectedBaseColor,
                "Set the selected material's base or diffuse color.",
                nullptr,
                settingsControlWidth);

            if (IsSettingAvailable(
                    SettingId::MaterialSelectedMetalSpecularTextureEnabled))
            {
                DrawUiBoolean(
                    material->useSpecularGlossModel
                        ? "Use Specular Texture"
                        : "Use Metal-Rough Texture",
                    SettingId::MaterialSelectedMetalSpecularTextureEnabled,
                    "Enable the selected material's metal rough or specular texture.",
                    false,
                    &material->metalRoughOrSpecularTexture->path);
            }

            if (material->useSpecularGlossModel)
            {
                DrawUiColor(
                    material->enableMetalRoughOrSpecularTexture
                        ? "Specular Factor"
                        : "Specular Color",
                    SettingId::MaterialSelectedSpecularColor,
                    "Set the selected material's specular color.",
                    nullptr,
                    settingsControlWidth);
                const UiSettingRange roughnessRange =
                    GetUiSettingRange(
                        SettingId::MaterialSelectedRoughness);
                float glossiness = 1.f - material->roughness;
                SetNextLabeledControlWidth(
                    "Glossiness",
                    settingsControlWidth);
                if (DrawBoundedSlider(
                        material->enableMetalRoughOrSpecularTexture
                            ? "Glossiness Factor"
                            : "Glossiness",
                        &glossiness,
                        roughnessRange.safeMinimum,
                        roughnessRange.safeMaximum,
                        roughnessRange.trackMinimum,
                        roughnessRange.trackMaximum,
                        "%.3f"))
                {
                    ApplyUiSetting(
                        SettingId::MaterialSelectedRoughness,
                        UiSettingsValue::Float(1.f - glossiness));
                }
                ImGui::SetItemTooltip(
                    "Set glossiness as one minus the canonical roughness value.");
                DrawUiReset(
                    SettingId::MaterialSelectedRoughness);
            }
            else
            {
                DrawUiFloat(
                    material->enableMetalRoughOrSpecularTexture
                        ? "Metalness Factor"
                        : "Metalness",
                    SettingId::MaterialSelectedMetalness,
                    "%.3f",
                    "Set the selected material's metalness.",
                    ImGuiSliderFlags_None,
                    false,
                    settingsControlWidth,
                    false);
                DrawUiFloat(
                    material->enableMetalRoughOrSpecularTexture
                        ? "Roughness Factor"
                        : "Roughness",
                    SettingId::MaterialSelectedRoughness,
                    "%.3f",
                    "Set the selected material's roughness.",
                    ImGuiSliderFlags_None,
                    false,
                    settingsControlWidth,
                    false);
            }

            if (IsSettingAvailable(
                    SettingId::MaterialSelectedOpacity))
            {
                DrawUiFloat(
                    material->baseOrDiffuseTexture
                        ? "Opacity Factor"
                        : "Opacity",
                    SettingId::MaterialSelectedOpacity,
                    "%.3f",
                    "Set opacity for the alpha blended material.",
                    ImGuiSliderFlags_None,
                    false,
                    settingsControlWidth,
                    static_cast<bool>(material->baseOrDiffuseTexture));
            }
            if (IsSettingAvailable(
                    SettingId::MaterialSelectedAlphaCutoff))
            {
                DrawUiFloat(
                    "Alpha Cutoff",
                    SettingId::MaterialSelectedAlphaCutoff,
                    "%.3f",
                    "Set the alpha test cutoff.",
                    ImGuiSliderFlags_None,
                    false,
                    settingsControlWidth,
                    false);
            }

            if (IsSettingAvailable(
                    SettingId::MaterialSelectedNormalTextureEnabled))
            {
                DrawUiBoolean(
                    "Use Normal Texture",
                    SettingId::MaterialSelectedNormalTextureEnabled,
                    "Enable the selected material's normal texture.",
                    false,
                    &material->normalTexture->path);
                if (material->enableNormalTexture)
                {
                    DrawUiFloat(
                        "Normal Scale",
                        SettingId::MaterialSelectedNormalScale,
                        "%.3f",
                        "Set the normal texture scale.",
                        ImGuiSliderFlags_None,
                        false,
                        settingsControlWidth,
                        false);
                }
            }

            if (IsSettingAvailable(
                    SettingId::MaterialSelectedOcclusionTextureEnabled))
            {
                DrawUiBoolean(
                    "Use Occlusion Texture",
                    SettingId::MaterialSelectedOcclusionTextureEnabled,
                    "Enable the selected material's occlusion texture.",
                    false,
                    &material->occlusionTexture->path);
                if (material->enableOcclusionTexture)
                {
                    DrawUiFloat(
                        "Occlusion Strength",
                        SettingId::MaterialSelectedOcclusionStrength,
                        "%.3f",
                        "Set the occlusion texture strength.",
                        ImGuiSliderFlags_None,
                        false,
                        settingsControlWidth,
                        false);
                }
            }

            if (IsSettingAvailable(
                    SettingId::MaterialSelectedEmissiveTextureEnabled))
            {
                DrawUiBoolean(
                    "Use Emissive Texture",
                    SettingId::MaterialSelectedEmissiveTextureEnabled,
                    "Enable the selected material's emissive texture.",
                    false,
                    &material->emissiveTexture->path);
            }
            DrawUiColor(
                "Emissive Color",
                SettingId::MaterialSelectedEmissiveColor,
                "Set the selected material's emissive color.",
                nullptr,
                settingsControlWidth);
            DrawUiFloat(
                "Emissive Intensity",
                SettingId::MaterialSelectedEmissiveIntensity,
                "%.3f",
                "Set the selected material's emissive intensity.",
                ImGuiSliderFlags_Logarithmic,
                false,
                settingsControlWidth,
                false);

            if (IsSettingAvailable(
                    SettingId::MaterialSelectedTransmissionFactor))
            {
                if (IsSettingAvailable(
                        SettingId::MaterialSelectedTransmissionTextureEnabled))
                {
                    DrawUiBoolean(
                        "Use Transmission Texture",
                        SettingId::MaterialSelectedTransmissionTextureEnabled,
                        "Enable the selected material's transmission texture.",
                        false,
                        &material->transmissionTexture->path);
                }
                DrawUiFloat(
                    "Transmission Factor",
                    SettingId::MaterialSelectedTransmissionFactor,
                    "%.3f",
                    "Set the selected material's transmission factor.",
                    ImGuiSliderFlags_None,
                    false,
                    settingsControlWidth,
                    false);
            }

            if (IsSettingAvailable(
                    SettingId::MaterialSelectedAlphaMaskTextureEnabled))
            {
                DrawUiBoolean(
                    "Use Alpha Mask Texture",
                    SettingId::MaterialSelectedAlphaMaskTextureEnabled,
                    "Enable the selected material's alpha mask texture.",
                    false,
                    &material->opacityTexture->path);
            }
            ImGui::PopID();
        }
        else
        {
            ImGui::TextWrapped(
                "Aim the center crosshair at an editable surface, then press "
                "M.");
        }
        EndDrawerBody();
        ImGui::Spacing();
    }

auto UIRenderer::DrawInterfaceDrawer(float settingsControlWidth) -> void {
        const bool interfaceOpen = DrawCollapsingHeader(
            "Interface",
            "Choose the interface skin and its live colors.");
        if (!interfaceOpen)
        {
            ImGui::Spacing();
            return;
        }

        BeginDrawerBody("##InterfaceBody", settingsControlWidth);

        bool overrideVisualMaxes = m_ui.OverrideVisualMaxes;
        if (ImGui::Checkbox(
                "Override Visual Maxes",
                &overrideVisualMaxes))
        {
            ApplyUiSetting(
                SettingId::UiOverrideVisualMaxes,
                UiSettingsValue::Boolean(overrideVisualMaxes));
        }
        ImGui::SetItemTooltip(
            "Allow numeric entry beyond a slider's visible track, up to "
            "the setting's safe supported limits.");

        SetNextLabeledControlWidth(
            "Interface Skin",
            settingsControlWidth);
        DrawUiRoundedTokenCombo("Interface Skin##UiSkin", SettingId::UiSkin);
        ImGui::SetItemTooltip(
            "Choose the interface appearance. Ogg uses standard controls.");
        DrawUiReset(SettingId::UiSkin, false, "Interface Skin");

        SetNextLabeledControlWidth(
            "Font Family",
            settingsControlWidth);
        const std::size_t fontIndex =
            ReadUiTokenIndex(SettingId::UiFontFamily);
        const std::string fontLabel = FormatUiSettingsTokenLabel(
            SettingId::UiFontFamily,
            fontIndex);
        if (ImGui::BeginCombo(
                "Font Family##UiFontFamily",
                fontLabel.c_str()))
        {
            const UiSettingsTypedDomain& fontDomain =
                GetUiSettingDefinition(
                    SettingId::UiFontFamily).typedDomain;
            assert(fontDomain.tokenCount == UiFontFamilyValues.size());
            for (std::size_t index = 0u;
                index < fontDomain.tokenCount; ++index)
            {
                const auto candidateIterator = std::find_if(
                    UiFontFamilyValues.begin(),
                    UiFontFamilyValues.end(),
                    [&fontDomain, index](UiFontFamily candidate)
                    {
                        return UiFontFamilyCommandValue(candidate) ==
                            fontDomain.tokens[index];
                    });
                assert(candidateIterator != UiFontFamilyValues.end());
                const UiFontFamily candidate =
                    candidateIterator != UiFontFamilyValues.end()
                    ? *candidateIterator
                    : DefaultUiFontFamily;
                const bool available = IsUiFontFamilyAvailable(candidate);
                const bool selected = index == fontIndex;
                if (!available)
                    continue;
                DrawUiTokenOption(SettingId::UiFontFamily, index, selected);
                if (selected)
                    ImGui::SetItemDefaultFocus();
            }
            ImGui::EndCombo();
        }
        ImGui::SetItemTooltip(
            "Choose the global interface font independently of the interface "
            "skin. Ogg (ProggyClean) uses ProggyClean for body text; Amp "
            "headings remain Noto Sans Bold for clear emphasis.");
        DrawUiReset(SettingId::UiFontFamily, false, "Font Family");

        UiSkinPalette* palette =
            FindUiSkinPalette(m_ui.Accents, m_ui.Skin);
        const bool authoredPaletteAvailable =
            palette != nullptr &&
            IsSettingAvailable(SettingId::UiAccentPrimary);
        constexpr const char* StockColorTooltip =
            "Ogg preserves stock ImGui colors and has no single authored "
            "value for this role.";

        DrawUiColor(
            "Primary Accent##UiPrimaryAccent",
            SettingId::UiAccentPrimary,
            authoredPaletteAvailable
                ? "Set drawer headers, panel titles, footer buttons, "
                    "selection details, and slider knobs for the active "
                    "authored skin."
                : StockColorTooltip,
            "Primary Accent",
            settingsControlWidth,
            authoredPaletteAvailable);
        DrawUiColor(
            "Secondary Accent##UiSecondaryAccent",
            SettingId::UiAccentSecondary,
            "Set the secondary accent used by errors and disabled/off "
            "toggle knobs. The Amp default is translucent blue.",
            "Secondary Accent",
            settingsControlWidth,
            true);
        DrawUiColor(
            "Tertiary Accent##UiTertiaryAccent",
            SettingId::UiAccentTertiary,
            "Set success output, Material status, and enabled/on knobs. Amp "
            "defaults to the compensated blue used for a light track.",
            "Tertiary Accent",
            settingsControlWidth,
            true);

        DrawUiColor(
            "Font Color##UiFontColor",
            SettingId::UiAccentFont,
            authoredPaletteAvailable
                ? "Set all authored interface text, including drawer "
                    "and panel titles."
                : StockColorTooltip,
            "Font Color",
            settingsControlWidth,
            authoredPaletteAvailable);
        DrawUiColor(
            "Background Color##UiPrimaryBackgroundColor",
            SettingId::UiAccentPrimaryBackground,
            authoredPaletteAvailable
                ? "Set menu body, resting controls, and picker background; "
                    "hover, active, body, and picker opacity derive from it."
                : StockColorTooltip,
            "Background Color",
            settingsControlWidth,
            authoredPaletteAvailable);

        EndDrawerBody();
        ImGui::Spacing();
    }



void UIRenderer::UpdateStatSnapshot(int width, int height)
{
    constexpr double interval = 1.0 / 24.0;
    const double frameTime = std::max(0.0, double(ImGui::GetIO().DeltaTime));
    m_StatSnapshotElapsed += frameTime;
    if (frameTime > 0.0)
    {
        m_StatFrameTimeSum += frameTime;
        ++m_StatFrameTimeCount;
    }
    if (m_HasAppliedStatSnapshot && m_StatSnapshotElapsed < interval)
        return;

    m_StatSnapshotElapsed = m_HasAppliedStatSnapshot
        ? std::fmod(m_StatSnapshotElapsed, interval) : 0.0;
    if (m_StatFrameTimeCount > 0u)
        m_DisplayedFrameTime = m_StatFrameTimeSum / double(m_StatFrameTimeCount);
    m_StatFrameTimeSum = 0.0;
    m_StatFrameTimeCount = 0u;
    m_HasAppliedStatSnapshot = true;
    FormatStatLine(m_PerformanceStatValues[0], "%d x %d", width, height);
    m_PerformanceStatValues[3] = FormatTriangleCount(m_app->GetSubmittedMainViewTriangles());
    if (m_DisplayedFrameTime > 0.0)
    {
        FormatStatLine(m_PerformanceStatValues[1], "%.1f ms", m_DisplayedFrameTime * 1e3);
        FormatStatLine(m_PerformanceStatValues[2], "%.1f fps", 1.0 / m_DisplayedFrameTime);
    }
    else
    {
        m_PerformanceStatValues[1].clear();
        m_PerformanceStatValues[2].clear();
    }

    const auto* visibility = m_app->GetScreenSpaceVisibilityTimings();
    m_DisplayedVisibilityTimings = visibility ? *visibility : ScreenSpaceVisibilityTimings{};
    m_HasVisibilityStatSnapshot = visibility && visibility->active && visibility->available;
}









auto UIRenderer::DrawCenteredActionButton(const char* label, float width) -> bool {
        const ImVec2 size(width, ImGui::GetFrameHeight());
        ImGui::PushID(label);
        const bool pressed = ImGui::Button("##ActionButton", size);
        ImGui::PopID();
        const ImVec2 buttonMin = ImGui::GetItemRectMin();
        const ImVec2 buttonMax = ImGui::GetItemRectMax();
        ImDrawList* drawList = ImGui::GetWindowDrawList();

        const ImVec2 textSize = ImGui::CalcTextSize(label);
        const ImVec2 textPosition(
            std::floor(buttonMin.x + (buttonMax.x - buttonMin.x - textSize.x) * 0.5f),
            std::floor(buttonMin.y + (buttonMax.y - buttonMin.y - textSize.y) * 0.5f +
                       1.f));
        drawList->AddText(textPosition, ImGui::GetColorU32(ImGuiCol_Text), label);
        return pressed;
    }

auto UIRenderer::buildUI(void) -> void {
        const auto runUiAction = [this](ActionId id)
        {
            std::string error;
            if (!RunAction(id, error))
            {
                uvsr::log::warning(
                    "UI action failed: %s",
                    error.c_str());
                return false;
            }
            return true;
        };
        m_ComposedUiSkin = ResolveUiSkin(m_ui.Skin);
        ApplyUiSkin(
            m_ComposedUiSkin,
            m_ui.Accents,
            m_UiDisplayScale);
        int width, height;
        GetDeviceManager()->GetWindowDimensions(width, height);
        ImFont* activeUiFont = GetActiveUiFont();
        m_SettingsPanelMarginPixels = static_cast<uint32_t>(
            std::max(
                1.f,
                std::round(g_UiSpacingTokens.section)));
        const ImGuiViewport* mainViewport =
            ImGui::GetMainViewport();
        const UiLayoutRect workRectangle = {
            mainViewport->WorkPos.x,
            mainViewport->WorkPos.y,
            mainViewport->WorkPos.x + mainViewport->WorkSize.x,
            mainViewport->WorkPos.y + mainViewport->WorkSize.y
        };
        ImGui::PushFont(activeUiFont);
        const float performanceCollapsedHeight = GetSettingsCollapsedWindowHeight(
            ImGui::GetStyle(), ImGui::GetFontSize());
        const float minimumSettingsHeight =
            std::max(
                performanceCollapsedHeight + ImGui::GetFontSize() + g_UiSpacingTokens.tight,
                ImGui::GetStyle().WindowMinSize.y);
        const float panelSeparation =
            g_UiSpacingTokens.tight;
        ImGui::PopFont();
        const float panelStackMaximumBottom =
            workRectangle.maxY - float(m_SettingsPanelMarginPixels);
        const bool sceneLoading = m_app->IsSceneBusy();
        if (sceneLoading)
        {
            if (!m_WasSceneLoading)
            {
                m_WasSceneLoading = true;
                m_DisplayedFrameTime = 0.0;
                m_StatSnapshotElapsed = 0.0;
                m_StatFrameTimeSum = 0.0;
                m_StatFrameTimeCount = 0;
                for (std::string& value : m_PerformanceStatValues)
                    value.clear();
                m_DisplayedVisibilityTimings = {};
                m_HasAppliedStatSnapshot = false;
                m_HasVisibilityStatSnapshot = false;
                m_SceneLoadCounterStart =
                    std::chrono::steady_clock::now();
                m_SceneLoadHistoryKey = m_app->GetCurrentSceneName();
                m_SceneLoadFailed = false;
            }

            BeginFullScreenWindow();
            ImGui::PushFont(activeUiFont);
            ApplyActiveUiWordSpacing();

            const auto& stats = Scene::GetLoadingStats();
            const uint32_t objectsLoaded = stats.ObjectsLoaded.load();
            const uint32_t objectsTotal = std::max(
                stats.ObjectsTotal.load(),
                objectsLoaded);
            const uint64_t importStepsCompleted =
                stats.ImportStepsCompleted.load();
            const uint64_t importStepsTotal = std::max(
                stats.ImportStepsTotal.load(),
                importStepsCompleted);
            const uint32_t texturesDecoded =
                m_app->GetTextureCache()->GetNumberOfLoadedTextures();
            const uint32_t texturesReady =
                m_app->GetTextureCache()->GetNumberOfFinalizedTextures();
            const uint32_t texturesTotal = std::max(
                m_app->GetTextureCache()->GetNumberOfRequestedTextures(),
                std::max(texturesDecoded, texturesReady));
            char messageBuffer[512];
            const std::string sceneDisplayName =
                m_app->GetCurrentSceneDisplayName();
            const char* loadingPhase =
                m_app->IsSceneGpuUploadPending()
                    ? "Uploading mesh buffers in bounded chunks"
                    : "Importing and preparing scene data";
            const uint64_t elapsedLoadMilliseconds = static_cast<uint64_t>(
                std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::steady_clock::now() -
                    m_SceneLoadCounterStart).count());
            const uint64_t elapsedLoadTicks =
                ResolveSceneLoadElapsedTicks(elapsedLoadMilliseconds);
            uint64_t averageLoadTicks = 0u;
            const auto sceneTiming = m_SceneLoadTiming.byScene.find(
                m_SceneLoadHistoryKey);
            if (sceneTiming != m_SceneLoadTiming.byScene.end())
            {
                averageLoadTicks = ResolveAverageSceneLoadTicks(
                    sceneTiming->second);
            }
            if (averageLoadTicks == 0u)
            {
                averageLoadTicks = ResolveAverageSceneLoadTicks(
                    m_SceneLoadTiming.allScenes);
            }
            const std::string averageLoadLabel = averageLoadTicks > 0u
                ? std::to_string(averageLoadTicks)
                : "--";
            snprintf(
                messageBuffer,
                std::size(messageBuffer),
                "Loading scene: %s, please wait%.*s\n"
                "%s: %llu/%s\n"
                "Objects: %u/%u / Import steps: %llu/%llu / "
                "Textures decoded: %u/%u / GPU ready: %u/%u",
                sceneDisplayName.c_str(),
                1 + int(elapsedLoadMilliseconds / 500u % 3u), "...",
                loadingPhase,
                static_cast<unsigned long long>(elapsedLoadTicks),
                averageLoadLabel.c_str(),
                objectsLoaded,
                objectsTotal,
                static_cast<unsigned long long>(importStepsCompleted),
                static_cast<unsigned long long>(importStepsTotal),
                texturesDecoded,
                texturesTotal,
                texturesReady,
                texturesTotal);
            DrawScreenCenteredText(messageBuffer);

            RestoreActiveUiWordSpacing();
            ImGui::PopFont();
            EndFullScreenWindow();

            return;
        }
        if (m_WasSceneLoading)
        {
            m_SceneLoadFailed = m_app->HasSceneLoadFailure() ||
                !m_app->IsSceneLoaded();
            if (!m_SceneLoadFailed)
            {
                const uint64_t completedLoadMilliseconds =
                    static_cast<uint64_t>(
                        std::chrono::duration_cast<
                            std::chrono::milliseconds>(
                            std::chrono::steady_clock::now() -
                            m_SceneLoadCounterStart).count());
                RecordSceneLoadDuration(
                    m_SceneLoadTiming.allScenes,
                    completedLoadMilliseconds);
                if (!RecordBoundedSceneLoadDuration(
                        m_SceneLoadTiming.byScene,
                        m_SceneLoadHistoryKey,
                        completedLoadMilliseconds))
                {
                    uvsr::log::warning(
                        "Scene loading history rejected the key '%s'",
                        m_SceneLoadHistoryKey.c_str());
                }
                SaveSceneLoadTimingDatabase();
            }
        }
        m_WasSceneLoading = false;

        ImGui::PushFont(activeUiFont);
        ApplyActiveUiWordSpacing();

        float const fontSize = ImGui::GetFontSize();
        const ImGuiStyle& style = ImGui::GetStyle();
        const float settingsControlWidth =
            ImGui::CalcTextSize(
                "Bitmask Directional Visibility").x +
            style.FramePadding.x * 2.f;
        RefreshSettingsSnapshot();

        UpdateStatSnapshot(width, height);
        if (!m_ui.ShowUI)
        {
            RestoreActiveUiWordSpacing();
            ImGui::PopFont();
            return;
        }
        const std::string performanceLine = m_PerformanceStatValues[0] + " / " +
            m_PerformanceStatValues[3] + " / " + m_PerformanceStatValues[1] + " / " + m_PerformanceStatValues[2];

        // Keep Settings independent of live status digits. At the current
        // 23.44 font heights is exactly 20 percent narrower than the previous
        // panel while retaining the longest intentional control width. Root
        // and drawer padding plus the authored scrollbar form a hard content
        // floor; narrow viewports still cap the panel early enough to leave a
        // functional ColorEdit picker lane on the right.
        constexpr float SettingsWindowWidthInFontHeights = 23.44f;
        const float settingsPanelMarginPixels =
            float(m_SettingsPanelMarginPixels);
        const float availableWindowWidth =
            std::max(
                1.f,
                workRectangle.maxX -
                    workRectangle.minX -
                    settingsPanelMarginPixels * 2.f);
        const float colorPickerMinimumContentWidth =
            ImGui::GetUvsrAuthoredColorPickerMinimumWidth(
                ImGui::GetFrameHeight());
        const float colorPickerPopupHorizontalPadding =
            style.WindowPadding.x + style.ItemInnerSpacing.x;
        const float colorPickerMinimumLaneWidth =
            colorPickerMinimumContentWidth +
            colorPickerPopupHorizontalPadding * 2.f;
        const float settingsWindowMaximumWidth =
            std::max(
                1.f,
                availableWindowWidth -
                    colorPickerMinimumLaneWidth);
        const float settingsWindowMinimumWidth =
            settingsControlWidth +
            style.WindowPadding.x * 4.f +
            style.ScrollbarSize;
        const float settingsWindowWidth = std::min(
            std::max(
                fontSize * SettingsWindowWidthInFontHeights,
                settingsWindowMinimumWidth),
            settingsWindowMaximumWidth);
        const float performanceWindowTop =
            workRectangle.minY + settingsPanelMarginPixels;
        const float performanceMaximumWindowHeight = std::max(
            performanceCollapsedHeight,
            ResolvePerformanceMaximumWindowHeight(
                panelStackMaximumBottom,
                performanceWindowTop,
                minimumSettingsHeight,
                panelSeparation));
        const RootPanel performance = BeginRootPanel(true,
            ImVec2(workRectangle.minX + settingsPanelMarginPixels, performanceWindowTop),
            settingsWindowWidth, performanceMaximumWindowHeight);
        const RootPanelGeometry performanceGeometry = GetRootPanelGeometry(performance.window);
        const ImRect performanceExpandedContentRect(
            ImVec2(performanceGeometry.content.Min.x, performanceGeometry.summary.Max.y),
            performanceGeometry.content.Max);
        if (performance.expanded)
        {
            DrawRootPanelBodySurface(
                performance.window->DrawList,
                performanceGeometry.body,
                performanceExpandedContentRect,
                performanceGeometry.summary,
                style.WindowRounding);
            DrawPerformancePanelContents(
                settingsControlWidth,
                performanceLine);
            DrawRootPanelBodyOutlines(
                performance.window->DrawList,
                performanceGeometry.body,
                performanceExpandedContentRect,
                style.WindowRounding);
        }
        else if (performance.collapsed)
        {
            DrawCompactRootPanelBody(
                performance.window->DrawList,
                performanceGeometry.body,
                performanceGeometry.summary,
                style.WindowRounding,
                performanceLine.c_str());
        }
        const float performanceWindowBottom = performance.window->Pos.y + performance.window->Size.y;
        EndRootPanel();

        const float settingsWindowTop = performanceWindowBottom + panelSeparation;
        const float settingsMaximumWindowHeight =
            std::max(
                1.f,
                panelStackMaximumBottom - settingsWindowTop);
        const RootPanel settings = BeginRootPanel(false,
            ImVec2(workRectangle.minX + settingsPanelMarginPixels, settingsWindowTop),
            settingsWindowWidth, settingsMaximumWindowHeight);
        const RootPanelGeometry settingsGeometry = GetRootPanelGeometry(settings.window);

        ImVec2 expandedSettingsSnapshotMinimum{};
        bool expandedSettingsSnapshotSubmitted = false;
        if (settings.expanded)
        {
            const float snapshotCursorX = ImGui::GetCursorPosX();
            ImGui::SetCursorPosX(
                snapshotCursorX + g_UiSpacingTokens.tight);
            ImVec4 hiddenSnapshotText =
                ImGui::GetStyleColorVec4(ImGuiCol_Text);
            hiddenSnapshotText.w = 0.f;
            ImGui::PushStyleColor(
                ImGuiCol_Text,
                hiddenSnapshotText);
            ImGui::TextUnformatted(m_SettingsSnapshots.Code().c_str());
            ImGui::PopStyleColor();
            expandedSettingsSnapshotMinimum = ImGui::GetItemRectMin();
            expandedSettingsSnapshotSubmitted = true;
            if (ImGui::IsItemClicked(ImGuiMouseButton_Left))
                CopySettingsSnapshot();
            ImGui::SetItemTooltip(
                "Click to copy this versioned settings snapshot code. The "
                "decoder resolves every represented setting from the local "
                "UVSR snapshot catalog.");
            ImGui::SetCursorPosX(snapshotCursorX);

        // The root owns the fixed snapshot line and title-to-content inset.
        // Keeping them outside the scrolling child leaves the code visible
        // above every drawer.
        const float settingsBodyMaxHeight = std::max(
            1.f,
            panelStackMaximumBottom -
                ImGui::GetCursorScreenPos().y - style.WindowPadding.y);
        ImGui::SetNextWindowSizeConstraints(
            ImVec2(0.f, 0.f), ImVec2(FLT_MAX, settingsBodyMaxHeight));
        ImGui::BeginChild(
            "##SettingsBody",
            ImVec2(0.f, 0.f),
            ImGuiChildFlags_AutoResizeY,
            ImGuiWindowFlags_AlwaysVerticalScrollbar);
        ImGuiWindow* settingsBodyWindow =
            ImGui::GetCurrentWindow();
        const int settingsFrame = ImGui::GetFrameCount();
        if (m_SettingsScrollFrame == settingsFrame - 1 &&
            std::abs(settingsBodyWindow->Scroll.y - m_SettingsScrollY) > 0.01f)
        {
            ImGui::CloseUvsrColorPickerPopup();
        }
        m_SettingsScrollFrame = settingsFrame;
        m_SettingsScrollY = settingsBodyWindow->Scroll.y;
        const float colorPickerMaximumBottom = std::min(
            panelStackMaximumBottom,
            settingsBodyWindow->ParentWindow->Pos.y +
                settingsBodyWindow->ParentWindow->Size.y);
        ImVec4 colorPickerContentLayer =
            g_UiVisualTokens.drawerBackground;
        colorPickerContentLayer.w *= 0.72f;
        ImVec4 colorPickerControlLayer =
            g_UiVisualTokens.drawerBackground;
        ImGui::PushUvsrColorPickerPopupContentRight(
            settingsBodyWindow->InnerRect.Max.x,
            colorPickerMaximumBottom,
            g_UiVisualTokens.colorPickerSurface,
            g_UiVisualTokens.panelInsetFrame,
            colorPickerContentLayer,
            colorPickerControlLayer);
        DrawGeneralDrawer(settingsControlWidth);

        if (BeginToggleRegion(
                "##PathingDrawerVisibility",
                m_ui.Lighting == LightingSolution::PathTracing))
        {
            DrawPathingDrawer(settingsControlWidth);
            EndControlRegion();
        }

        const auto drawNoiseSettingsControls = [&] (
            const char* identifier,
            bool nestedResetIcons,
            const std::array<SettingId, 3>& settingIds)
        {
            const std::string patternLabel =
                std::string("Noise Pattern##") + identifier;
            SetNextLabeledControlWidth("Noise Pattern", settingsControlWidth);
            DrawUiTokenCombo(
                patternLabel.c_str(),
                settingIds[0],
                "Choose a precomputed R8 spatial or spatiotemporal noise "
                "texture.",
                nestedResetIcons);

            const std::string resolutionLabel =
                std::string("Noise Resolution##") + identifier;
            SetNextLabeledControlWidth(
                "Noise Resolution", settingsControlWidth);
            DrawUiTokenCombo(
                resolutionLabel.c_str(),
                settingIds[1],
                "Choose the centered tile resolution used by this noise "
                "texture.",
                nestedResetIcons);

            const std::string animateLabel =
                std::string("Animate Samples##") + identifier;
            const std::string animateReset = std::string(identifier) + "NoiseAnimate";
            DrawUiBoolean(animateLabel.c_str(), settingIds[2],
                "Advance the noise sequence after each successful effect dispatch.",
                false, nullptr, animateReset.c_str());
        };

        const auto drawDirectionalRayShadowControls = [&]()
        {
            if (!BeginSettingsTree(
                    "Ray Traced Shadows##Shadows",
                    ImGuiTreeNodeFlags_DefaultOpen,
                    "Trace directional-light visibility using the shared shadow sample count and emitter size."))
            {
                return;
            }

            const DirectionalShadowSettings& settings =
                m_ui.DirectionalShadows;
            const bool available =
                IsSettingAvailable(SettingId::ShadowsRayTracedEnabled);
            if (available || settings.enabled)
            {
            bool shadowsEnabled = settings.enabled;
            if (ImGui::Checkbox(
                    "Enabled##DirectionalRayShadows",
                    &shadowsEnabled))
            {
                ApplyUiSetting(
                    SettingId::ShadowsRayTracedEnabled,
                    UiSettingsValue::Boolean(shadowsEnabled));
            }
            ImGui::SetItemTooltip("Trace direct directional-light visibility at each visible surface.");
            DrawUiReset(SettingId::ShadowsRayTracedEnabled, false, "DirectionalRayShadowsEnabled");
            }

            if (BeginToggleRegion(
                    "##DirectionalRayShadowControls", settings.enabled))
            {
                DrawUiBoolean("Hard Shadows", SettingId::ShadowsRayTracedHard,
                    "Use one shadow ray and override all light emitter angles and radii to zero. Stored sample counts and emitter sizes return when disabled.");
                int shadowSamples = int(ResolveRayShadowSampleCount(settings));
                ImGui::BeginDisabled(settings.hardShadows);
                ImGui::SetNextItemWidth(settingsControlWidth);
                if (DrawBoundedSlider("Samples Per Pixel##DirectionalRayShadows", &shadowSamples,
                        1, 64, 1, 64, "%d", ImGuiSliderFlags_AlwaysClamp | ImGuiSliderFlags_Logarithmic))
                {
                    const int sampleCount = 1 << std::clamp(int(std::lround(std::log2(double(std::max(1, shadowSamples))))), 0, 6);
                    ApplyUiSetting(SettingId::ShadowsRayTracedSamplesPerPixel,
                        UiSettingsValue::Token(std::to_string(sampleCount)));
                }
                ImGui::SetItemTooltip("Shadow rays per pixel for the directional light and flashlight. Zero-size emitters need only one ray. Path tracing uses its own path sample count.");
                DrawUiReset(SettingId::ShadowsRayTracedSamplesPerPixel);
                ImGui::EndDisabled();
                SetNextLabeledControlWidth("Maximum Distance", settingsControlWidth);
                DrawUiRoundedTokenCombo(
                    "Maximum Distance", SettingId::ShadowsRayTracedMaxDistance, false, false);
                const UiSettingRange rayBiasRange =
                    GetUiSettingRange(
                        SettingId::ShadowsRayTracedRayBias);
                float rayBias = settings.rayBias;
                if (DrawBoundedSlider(
                        "Ray Bias",
                        &rayBias,
                        rayBiasRange.safeMinimum,
                        rayBiasRange.safeMaximum,
                        rayBiasRange.trackMinimum,
                        rayBiasRange.trackMaximum,
                        "%.4f"))
                {
                    ApplyUiSetting(
                        SettingId::ShadowsRayTracedRayBias,
                        UiSettingsValue::Float(rayBias));
                }
                ImGui::TextDisabled(
                    "Direct visibility: %ux receiver samples.",
                    1u);
                EndControlRegion();
            }
            if (!available)
                ImGui::TextDisabled("DXR 1.1 and a primary directional light are required.");
            EndSettingsTree();
        };

        if (BeginToggleRegion(
                "##DiffuseDrawerVisibility",
                m_ui.Lighting == LightingSolution::RayMarching))
        {
        const bool diffuseOpen = DrawCollapsingHeader(
            "Diffuse",
            "Configure occlusion, illumination, sampling, "
            "automatic upsampling, and buffer precision.");
        if (diffuseOpen)
        {
            BeginDrawerBody("##DiffuseBody", settingsControlWidth);
            const ScreenSpaceVisibilitySettings& visibility =
                m_ui.ScreenSpaceVisibility;
            const ScreenSpaceVisibilityQuality profileOrigin =
                visibility.quality == ScreenSpaceVisibilityQuality::Custom
                ? visibility.qualityPresetOrigin
                : visibility.quality;

            DrawUiBoolean(
                "Enabled",
                SettingId::VisibilityEnabled,
                "Enable screen space occlusion and illumination. "
                "Other lighting and material effects remain independent.");

            const UiSettingsTypedDomain& qualityDomain =
                GetUiSettingDefinition(
                    SettingId::VisibilityQuality).typedDomain;
            const std::size_t presetCount =
                qualityDomain.tokenCount - 1u;
            const std::size_t currentQualityIndex =
                ReadUiTokenIndex(SettingId::VisibilityQuality);
            const int rawProfileIndex = static_cast<int>(profileOrigin);
            const bool hasProfileOrigin =
                rawProfileIndex >= 0 &&
                rawProfileIndex < static_cast<int>(presetCount);
            const std::size_t profileIndex = hasProfileOrigin
                ? static_cast<std::size_t>(rawProfileIndex)
                : presetCount;
            std::string profilePreview = hasProfileOrigin
                ? FormatUiSettingsTokenLabel(
                    SettingId::VisibilityQuality,
                    profileIndex)
                : FormatUiSettingsTokenLabel(
                    SettingId::VisibilityQuality,
                    presetCount);
            if (hasProfileOrigin && visibility.quality ==
                ScreenSpaceVisibilityQuality::Custom)
            {
                profilePreview += " (Custom)";
            }
            SetNextLabeledControlWidth(
                "Profile##Visibility", settingsControlWidth);
            if (ImGui::BeginCombo(
                    "Profile##Visibility",
                    profilePreview.c_str()))
            {
                static constexpr const char* ProfileTooltips[] = {
                    "Quarter-resolution Bitmask Approximation: 8 samples, shared Noise, automatic guide-aware upsampling, 16-bit buffers.",
                    "Half-resolution Bitmask Directional Visibility: 8 samples, shared Noise, automatic guide-aware upsampling, 16-bit buffers.",
                    "Full resolution Bitmask Directional Visibility with sixteen samples, the shared Noise configuration, and 16 bit buffers.",
                    "Full-resolution Bitmask Directional Visibility, 48 samples, shared Noise, and 32-bit buffers."
                };
                for (std::size_t index = 0u;
                    index < presetCount;
                    ++index)
                {
                    DrawUiTokenOption(SettingId::VisibilityQuality, index, index == currentQualityIndex);
                    ImGui::SetItemTooltip("%s", ProfileTooltips[index]);
                }
                ImGui::EndCombo();
            }
            ImGui::SetItemTooltip(
                "Choose a diffuse profile. Changes retain it and append "
                "(Custom); the circular arrow restores the catalog default "
                "profile.");
            DrawUiReset(SettingId::VisibilityQuality, false, "VisibilityProfile", "Restore the complete catalog default profile.");

            if (BeginToggleRegion(
                    "##VisibilityControls", visibility.enabled))
            {

            if (BeginSettingsTree(
                    "Occlusion###Ambient Occlusion##Visibility",
                    ImGuiTreeNodeFlags_DefaultOpen,
                    "Configure contact darkening from nearby geometry."))
            {
            DrawUiBoolean(
                "Enabled##VisibilityAmbient",
                SettingId::VisibilityAoEnabled,
                "Darken surfaces whose nearby geometry blocks ambient light.");
            if (BeginToggleRegion(
                    "##VisibilityAmbientControls",
                    visibility.ambientOcclusion.enabled))
            {
            DrawUiFloat(
                "Strength",
                SettingId::VisibilityAoStrength,
                "%.2f",
                "Scale how strongly nearby occluders darken the final image.");
            EndControlRegion();
            }
            EndSettingsTree();
            }

            if (BeginSettingsTree(
                    "Illumination###Indirect Diffuse##Visibility",
                    ImGuiTreeNodeFlags_DefaultOpen,
                    "Configure diffuse light reflected from visible surfaces."))
            {
            DrawUiBoolean(
                "Enabled##VisibilityIndirect",
                SettingId::VisibilityGiEnabled,
                "Add diffuse light reflected from nearby visible surfaces.");
            if (BeginToggleRegion(
                    "##VisibilityIndirectControls",
                    visibility.indirectDiffuse.enabled))
            {
            DrawUiFloat(
                "Intensity",
                SettingId::VisibilityGiIntensity,
                "%.2f",
                "Scale the diffuse light gathered from nearby surfaces.");
            EndControlRegion();
            }
            EndSettingsTree();
            }

            if (BeginSettingsTree(
                    "Sampling##Visibility",
                    ImGuiTreeNodeFlags_DefaultOpen,
                    "Configure where and how visibility rays sample the scene."))
            {
            SetNextLabeledControlWidth(
                "Sampling Resolution", settingsControlWidth);
            DrawUiTokenCombo(
                "Sampling Resolution",
                SettingId::VisibilityResolution,
                "Choose the resolution used for visibility tracing. Reduced "
                "resolutions are reconstructed before composition.",
                true);

            SetNextLabeledControlWidth(
                "Estimator", settingsControlWidth);
            DrawUiTokenCombo(
                "Estimator",
                SettingId::VisibilityEstimator,
                "Choose how directions are distributed around each receiver.",
                true);

            DrawUiBoolean(
                "Specify Noise##Visibility",
                SettingId::VisibilitySpecifyNoise,
                "Use custom noise sampling for this effect only. This does "
                "not change the noise sampling used by any other effect.");
            if (BeginToggleRegion(
                    "##VisibilityCustomNoise",
                    visibility.noise.specifyNoise))
            {
                drawNoiseSettingsControls(
                    "Visibility",
                    true,
                    {
                        SettingId::VisibilityNoisePattern,
                        SettingId::VisibilityNoiseResolution,
                        SettingId::VisibilityAnimateSamples
                    });
                EndControlRegion();
            }

            DrawUiInteger(
                "Samples",
                SettingId::VisibilitySamples,
                "%d",
                "Set the number of visibility samples traced per pixel.");
            DrawUiFloat(
                "Radius",
                SettingId::VisibilityRadius,
                "%.2f",
                "Set the world-space reach of nearby visibility samples.");
            DrawUiFloat(
                "Thickness",
                SettingId::VisibilityThickness,
                "%.2f",
                "Set the accepted thickness of potential occluding surfaces.");
            DrawUiFloat(
                "Distribution",
                SettingId::VisibilityDistribution,
                "%.2f",
                "Bias samples toward the receiver or toward the trace edge.");
            EndSettingsTree();
            }


            EndControlRegion();
            }

            if (visibility.HasActiveConsumer() && BeginSettingsTree("Buffers##Diffuse", ImGuiTreeNodeFlags_DefaultOpen,
                    "Configure visibility buffer precision."))
            {
            const bool ambient16 =
                visibility.bufferPrecision.ambient ==
                    VisibilityScalarBufferPrecision::Float16;
            const bool indirect16 =
                visibility.bufferPrecision.indirect ==
                    VisibilityVectorBufferPrecision::Rgba16Float;
            const int bufferProfile = ambient16
                ? (indirect16 ? 0 : 2)
                : (indirect16 ? 3 : 1);
            static constexpr const char* BufferProfileLabels[] = {
                "Performance",
                "Maximum Precision",
                "Compact Occlusion",
                "Compact Indirect"
            };
            SetNextLabeledControlWidth(
                "Profile##Buffers", settingsControlWidth);
            if (ImGui::BeginCombo(
                    "Profile##Buffers",
                    BufferProfileLabels[bufferProfile]))
            {
                static constexpr bool Ambient16[] = {
                    true, false, true, false
                };
                static constexpr bool Indirect16[] = {
                    true, false, false, true
                };
                static constexpr const char* BufferProfileTooltips[] = {
                    "Use 16-bit floating point for both retained visibility buffers.",
                    "Use 32-bit floating point for both retained visibility buffers.",
                    "Use 16-bit Occlusion and 32-bit Illumination.",
                    "Use 32-bit Occlusion and 16-bit Illumination."
                };
                for (int index = 0;
                    index < static_cast<int>(
                        std::size(BufferProfileLabels));
                    ++index)
                {
                    DrawDropdownOption(
                        BufferProfileLabels[index],
                        index == bufferProfile,
                        [this, index]()
                        {
                            ApplyUiSetting(
                                SettingId::VisibilityAoPrecision,
                                UiSettingsValue::Token(
                                    GetUiSettingToken(
                                        SettingId::VisibilityAoPrecision,
                                        Ambient16[index] ? 0u : 1u)));
                            ApplyUiSetting(
                                SettingId::VisibilityGiPrecision,
                                UiSettingsValue::Token(
                                    GetUiSettingToken(
                                        SettingId::VisibilityGiPrecision,
                                        Indirect16[index] ? 0u : 1u)));
                        });
                    ImGui::SetItemTooltip(
                        "%s", BufferProfileTooltips[index]);
                }
                ImGui::EndCombo();
            }
            ImGui::SetItemTooltip(
                "Choose a compact precision combination for the two "
                "visibility buffers that remain in production.");
            const bool bufferProfileModified =
                IsUiSettingChanged(SettingId::VisibilityAoPrecision) ||
                IsUiSettingChanged(SettingId::VisibilityGiPrecision);
            if (DrawPresetResetIcon(
                    "VisibilityBufferProfile",
                    bufferProfileModified,
                    "Restore both buffer precisions to the originating visibility profile."))
            {
                ResetUiSetting(SettingId::VisibilityAoPrecision);
                ResetUiSetting(SettingId::VisibilityGiPrecision);
            }

            if (visibility.HasActiveAmbientOcclusion())
            {
                SetNextLabeledControlWidth("Occlusion###Ambient Occlusion", settingsControlWidth);
                DrawUiTokenCombo("Occlusion###Ambient Occlusion", SettingId::VisibilityAoPrecision,
                    "Set the storage precision of the Occlusion field.");
            }
            if (visibility.HasActiveIndirectDiffuse())
            {
                SetNextLabeledControlWidth("Illumination###Indirect Diffuse", settingsControlWidth);
                DrawUiTokenCombo("Illumination###Indirect Diffuse", SettingId::VisibilityGiPrecision,
                    "Set the storage precision of the Illumination field.");
            }

            EndSettingsTree();
            }

            EndDrawerBody();
        }
        EndControlRegion();
        }
        if (BeginToggleRegion(
                "##ShadowsDrawerVisibility",
                m_ui.Lighting == LightingSolution::RayMarching))
        {
        const bool shadowsOpen = DrawCollapsingHeader(
            "Shadows", "Configure ray traced direct light shadows.");
        if (shadowsOpen)
        {
            BeginDrawerBody(
                "##ShadowsBody",
                settingsControlWidth);

            const bool directionalVisibilityAvailable =
                m_app->HasPrimaryDirectionalLight();
            const bool rayTracedShadowHardwareAvailable =
                m_app->HasDirectionalRayVisibilityHardwareSupport();
            if (!directionalVisibilityAvailable)
            {
                ImGui::TextDisabled(
                    "Directional techniques require a directional light.");
            }
            else if (!rayTracedShadowHardwareAvailable)
            {
                ImGui::TextDisabled(
                    "Ray traced shadows require DXR 1.1 support.");
            }

            drawDirectionalRayShadowControls();
            EndDrawerBody();
        }
        EndControlRegion();
        }

        const auto& lights = m_app->GetEditableLights();
        const bool lightsOpen = DrawCollapsingHeader(
            "Lights", "Show scene light controls.");
        if (lightsOpen)
        {
            BeginDrawerBody(
                "##LightsBody",
                settingsControlWidth);
            if (m_ui.DirectionalShadows.hardShadows)
                ImGui::TextWrapped("Hard Shadows overrides emitter sizes to zero. Stored sizes below return when it is off.");
            if (!lights.empty())
            {
                UiSettingsValue selectedLightValue;
                std::string selectedLightError;
                const bool selectedLightRead = ReadSettingValue(
                    SettingId::LightSelected,
                    selectedLightValue,
                    selectedLightError);
                if (!selectedLightRead)
                {
                    uvsr::log::warning(
                        "Selected light read failed: %s",
                        selectedLightError.c_str());
                }
                ImGui::SetNextItemWidth(settingsControlWidth);
                const bool lightComboOpen = ImGui::BeginCombo(
                    "Select Light", m_SelectedLight ? m_SelectedLight->GetName().c_str() : "(None)");
                ImGui::SetItemTooltip("Choose a light to edit.");
                if (lightComboOpen)
                {
                    for (std::size_t index = 0u;
                        index < lights.size(); ++index)
                    {
                        const auto& light = lights[index];
                        const std::string selector =
                            FormatSettingsSnapshotLightToken(
                                index,
                                light->GetName());
                        const bool selected = selectedLightRead &&
                            selectedLightValue.kind ==
                                UiSettingsValueKind::Selector &&
                            selectedLightValue.text == selector;
                        DrawDropdownOption(
                            light->GetName().c_str(),
                            selected,
                            [this, selector]()
                            {
                                ApplyUiSetting(
                                    SettingId::LightSelected,
                                    UiSettingsValue::Selector(
                                        selector));
                            });
                        if (selected)
                        {
                            ImGui::SetItemDefaultFocus();
                        }
                    }
                    ImGui::EndCombo();
                }
                DrawUiReset(SettingId::LightSelected, false, "Selected Light", "Select the scene's primary directional light.");

                if (m_SelectedLight)
                {
                    if (m_app->IsFlashlight(m_SelectedLight))
                    {
                        const FlashlightSettings& flashlight =
                            m_ui.Flashlight;
                        DrawUiBoolean(
                            "Enabled",
                            SettingId::LightSelectedFlashlightEnabled,
                            "Turn the camera flashlight on or off. Plain F "
                            "uses the same setting.");
                        if (BeginToggleRegion(
                                "##RayMarchingFlashlightVisibility",
                                m_ui.Lighting ==
                                    LightingSolution::RayMarching))
                        {
                        DrawUiBoolean(
                            "Cast Shadows",
                            SettingId::LightSelectedFlashlightCastShadows,
                            "Trace flashlight visibility through the shared "
                            "scene representation.");
                        if (BeginToggleRegion(
                                "##FlashlightShadowControls",
                                flashlight.castShadows))
                        {
                            EndControlRegion();
                        }
                        EndControlRegion();
                        }

                        DrawUiBoolean(
                            "Realistic Flashlight",
                            SettingId::LightSelectedFlashlightRealistic,
                            "Add a lens hotspot, bounded sway, and aim "
                            "correction inside one physical spot light.");

                        if (BeginToggleRegion(
                                "##RealisticFlashlightControls",
                                flashlight.realisticLens))
                        {
                            DrawUiFloat(
                                "Hotspot Size",
                                SettingId::LightSelectedFlashlightHotspotSize,
                                "%.2f",
                                "Set the focused lens hotspot width relative "
                                "to the complete beam.");

                            DrawUiFloat(
                                "Hotspot Strength",
                                SettingId::LightSelectedFlashlightHotspotStrength,
                                "%.2f",
                                "Move peak candela from the broad spill into "
                                "the focused lens hotspot.");

                            static constexpr char
                                FlashlightStationaryWhenIdleTooltip[] =
                                    "Freeze the flashlight pose when the active "
                                    "camera rests. Camera motion or motion-setting "
                                    "changes resume it.";
                            static_assert(
                                sizeof(FlashlightStationaryWhenIdleTooltip) -
                                    1u <=
                                120u);
                            DrawUiBoolean(
                                "Stationary When Idle",
                                SettingId::LightSelectedFlashlightStationaryWhenIdle,
                                FlashlightStationaryWhenIdleTooltip);

                            DrawUiFloat(
                                "Sway",
                                SettingId::LightSelectedFlashlightSway,
                                "%.2f degrees",
                                "Set the maximum subtle handheld aim motion. "
                                "Zero keeps the corrected beam perfectly still.");

                            DrawUiFloat(
                                "Aim Correction",
                                SettingId::LightSelectedFlashlightAimCorrection,
                                "%.2f s",
                                "Set the half-life for the beam to catch up "
                                "after the camera turns.");

                            EndControlRegion();
                        }

                        DrawUiFloat(
                            "Brightness",
                            SettingId::LightSelectedFlashlightBrightness,
                            "%.0f candela",
                            "Set the peak on-axis luminous intensity.",
                            ImGuiSliderFlags_Logarithmic);

                        DrawUiFloat(
                            "Beam Size",
                            SettingId::LightSelectedFlashlightBeamSize,
                            "%.1f degrees",
                            "Set the full horizontal and vertical outer beam "
                            "width.");

                        DrawUiFloat(
                            m_ui.DirectionalShadows.hardShadows ? "Stored Angular Size" : "Angular Size",
                            SettingId::LightSelectedFlashlightAngularSize,
                            "%.2f degrees",
                            "Set the apparent diameter of the analytical "
                            "spherical emitter at one metre; apparent size "
                            "varies with surface distance.");

                        DrawUiFloat(
                            "Beam Roundness",
                            SettingId::LightSelectedFlashlightBeamRoundness,
                            "%.2f",
                            "Morph the beam footprint from a softly rounded "
                            "square to an exact circle.");

                        DrawUiFloat(
                            "Edge Softness",
                            SettingId::LightSelectedFlashlightEdgeSoftness,
                            "%.2f",
                            "Set the falloff width without changing the "
                            "projected beam shape.");

                        DrawUiFloat(
                            "Range",
                            SettingId::LightSelectedFlashlightRange,
                            "%.1f m",
                            "Set the finite distance where the beam fades out.",
                            ImGuiSliderFlags_Logarithmic);

                        DrawUiColor(
                            "Color", SettingId::LightSelectedColor,
                            "Set the flashlight's scene-linear red, green, and "
                            "blue color.", "Flashlight Color");

                        DrawUiFloat(
                            "Horizontal Offset",
                            SettingId::LightSelectedFlashlightHorizontalOffset,
                            "%.1f centimeters",
                            "Move the flashlight left or right from the camera "
                            "by up to 40 centimeters.");

                        DrawUiFloat(
                            "Vertical Offset",
                            SettingId::LightSelectedFlashlightVerticalOffset,
                            "%.1f centimeters",
                            "Move the flashlight down or up from the camera "
                            "by up to 40 centimeters.");
                    }
                    else
                    {
                    const auto drawLightDirection =
                        [&](const Light& light, bool directional)
                        {
                            auto [azimuth, elevation] =
                                GetCommandLightAngles(
                                    light.GetDirection(),
                                    directional);
                            const auto drawAngle = [&] (
                                const char* label,
                                SettingId id,
                                float value)
                            {
                                const UiSettingRange range =
                                    GetUiSettingRange(id);
                                if (DrawBoundedSlider(
                                        label,
                                        &value,
                                        range.safeMinimum,
                                        range.safeMaximum,
                                        range.trackMinimum,
                                        range.trackMaximum,
                                        "%.1f degrees"))
                                {
                                    ApplyUiSetting(
                                        id,
                                        UiSettingsValue::Float(value));
                                }
                                ImGui::SetItemTooltip(
                                    "Set the selected light's direction.");
                            };
                            drawAngle(
                                "Azimuth",
                                SettingId::LightSelectedAzimuth,
                                azimuth);
                            drawAngle(
                                "Elevation",
                                SettingId::LightSelectedElevation,
                                elevation);
                            if (DrawPresetResetIcon(
                                    "Light Direction",
                                    IsUiSettingChanged(
                                        SettingId::LightSelectedAzimuth) ||
                                    IsUiSettingChanged(
                                        SettingId::LightSelectedElevation)))
                            {
                                ResetUiSetting(
                                    SettingId::LightSelectedAzimuth);
                                ResetUiSetting(
                                    SettingId::LightSelectedElevation);
                            }
                        };

                    switch (m_SelectedLight->GetLightType())
                    {
                    case UVSR_LIGHT_TYPE_DIRECTIONAL:
                    {
                        const auto& light = static_cast<const DirectionalLight&>(
                            *m_SelectedLight);
                        drawLightDirection(light, true);
                        DrawUiColor(
                            "Color",
                            SettingId::LightSelectedColor,
                            "Set the selected light's color.",
                            "Light Color");
                        DrawUiFloat(
                            "Irradiance",
                            SettingId::LightSelectedIrradiance,
                            "%.2f",
                            "Set the directional light irradiance.",
                            ImGuiSliderFlags_Logarithmic);
                        DrawUiFloat(
                            m_ui.DirectionalShadows.hardShadows ? "Stored Angular Size" : "Angular Size",
                            SettingId::LightSelectedAngularSize,
                            "%.2f degrees",
                            "Set the directional light's angular diameter. Zero "
                            "degrees creates a zero extent emitter with hard shadows.");
                        break;
                    }
                    case UVSR_LIGHT_TYPE_POINT:
                    {
                        DrawUiFloat(
                            m_ui.DirectionalShadows.hardShadows ? "Stored Radius" : "Radius",
                            SettingId::LightSelectedRadius,
                            "%.3f",
                            "Set the point light radius.",
                            ImGuiSliderFlags_Logarithmic);
                        DrawUiColor(
                            "Color",
                            SettingId::LightSelectedColor,
                            "Set the selected light's color.",
                            "Light Color");
                        DrawUiFloat(
                            "Intensity",
                            SettingId::LightSelectedIntensity,
                            "%.2f",
                            "Set the point light intensity.",
                            ImGuiSliderFlags_Logarithmic);
                        break;
                    }
                    case UVSR_LIGHT_TYPE_SPOT:
                    {
                        const auto& light = static_cast<const SpotLight&>(
                            *m_SelectedLight);
                        drawLightDirection(light, false);
                        DrawUiFloat(
                            m_ui.DirectionalShadows.hardShadows ? "Stored Radius" : "Radius",
                            SettingId::LightSelectedRadius,
                            "%.3f",
                            "Set the spot light radius.",
                            ImGuiSliderFlags_Logarithmic);
                        DrawUiColor(
                            "Color",
                            SettingId::LightSelectedColor,
                            "Set the selected light's color.",
                            "Light Color");
                        DrawUiFloat(
                            "Intensity",
                            SettingId::LightSelectedIntensity,
                            "%.2f",
                            "Set the spot light intensity.",
                            ImGuiSliderFlags_Logarithmic);
                        DrawUiFloat(
                            "Inner Angle",
                            SettingId::LightSelectedInnerAngle,
                            "%.1f degrees",
                            "Set the full bright spot cone angle.");
                        DrawUiFloat(
                            "Outer Angle",
                            SettingId::LightSelectedOuterAngle,
                            "%.1f degrees",
                            "Set the outer spot cone angle.");
                        break;
                    }
                    default:
                        ImGui::TextDisabled(
                            "This light type has no editable settings.");
                        break;
                    }
                    }
                }
            }

            EndDrawerBody();
        }
        ImGui::Spacing();

        const bool skyOpen = DrawCollapsingHeader(
            "Sky", "Show sky controls.");
        if (skyOpen)
        {
            BeginDrawerBody(
                "##SkyBody",
                settingsControlWidth);

            SetNextLabeledControlWidth(
                "Environment##SkyEnvironment",
                settingsControlWidth);
            DrawUiRoundedTokenCombo(
                "Environment##SkyEnvironment",
                SettingId::SkyEnvironment);
            ImGui::SetItemTooltip(
                "Choose the imported radiance source used by image-based "
                "lighting and the "
                "optional matching background.");
            DrawUiReset(SettingId::SkyEnvironment, false, "Environment Source");

            DrawUiFloat(
                "Environment Exposure##ImageBasedLighting",
                SettingId::SkyExposure,
                "%+.2f stops",
                "Scale only environment lighting and its background. Direct lights and emissive materials keep their intensity. Image Exposure in Tonemapper adjusts the whole image.");
            DrawUiBoolean(
                "Show Environment Background",
                SettingId::SkyEnvironmentBackground,
                "Show the same environment used for lighting.");

            if (BeginSettingsTree(
                    "Auto Environment Exposure##Sky",
                    ImGuiTreeNodeFlags_DefaultOpen,
                    "Adapt display exposure without changing the established "
                    "tonemapper or physical lighting."))
            {
                DrawUiBoolean(
                    "Enable##AutoExposure",
                    SettingId::SkyAutoExposureEnabled,
                    "Adapt display exposure to the median scene luminance. "
                    "Lighting, ray effects, and their histories are unchanged.");
                if (BeginToggleRegion(
                        "##AutoExposureControls",
                        m_ui.AutoExposure.enabled))
                {
                    DrawUiFloat(
                        "Compensation",
                        SettingId::SkyAutoExposureExposureCompensation,
                        "%+.2f EV",
                        "Bias the bounded automatic exposure result in "
                        "exposure-value stops.");
                    DrawUiFloat(
                        "Maximum Brightening",
                        SettingId::SkyAutoExposureMaximumBrightening,
                        "%.2f EV",
                        "Limit how far automatic metering may raise exposure. "
                        "Compensation is applied afterward.");
                    DrawUiFloat(
                        "Maximum Darkening",
                        SettingId::SkyAutoExposureMaximumDarkening,
                        "%.2f EV",
                        "Limit how far automatic metering may lower exposure. "
                        "Compensation is applied afterward.");
                    DrawUiFloat(
                        "Adjustment Period",
                        SettingId::SkyAutoExposureAdjustmentPeriod,
                        "%.2f s",
                        "Set the half-life of exposure adaptation. This affects "
                        "only display adaptation, not lighting or effect histories.");
                    EndControlRegion();
                }
                EndSettingsTree();
            }

            if (BeginToggleRegion(
                    "##RayMarchingAmbientFill",
                    m_ui.Lighting == LightingSolution::RayMarching))
            {
            DrawUiBoolean(
                "Ambient Fill",
                SettingId::SkyAmbientFillEnabled,
                "Enable diffuse/specular environment fill. Disable it to "
                "isolate direct lights; settings persist, and Occlusion "
                "needs it.");
            if (BeginToggleRegion(
                    "##AmbientFillControls",
                    m_ui.EnableAmbientFill))
            {
                DrawUiBoolean(
                    "Diffuse Environment",
                    SettingId::SkyDiffuseIbl,
                    "Use the selected environment for diffuse lighting.");
                if (BeginToggleRegion(
                        "##DiffuseIblControls",
                        m_ui.EnableDiffuseIbl))
                {
                    DrawUiFloat(
                        "Diffuse Strength##ImageBasedLighting",
                        SettingId::SkyDiffuseIblStrength,
                        "%.2f",
                        "Scale diffuse environment lighting after exposure.");
                    EndControlRegion();
                }

                DrawUiBoolean(
                    "Specular Environment",
                    SettingId::SkySpecularIbl,
                    "Use the selected environment for specular reflections.");
                if (BeginToggleRegion(
                        "##SpecularIblControls",
                        m_ui.EnableSpecularIbl))
                {
                    DrawUiFloat(
                        "Specular Strength##ImageBasedLighting",
                        SettingId::SkySpecularIblStrength,
                        "%.2f",
                        "Scale specular environment lighting after exposure.");
                    EndControlRegion();
                }

                EndControlRegion();
            }
            EndControlRegion();
            }

            if (BeginToggleRegion(
                    "##RayMarchingSkyVisibility",
                    m_ui.Lighting == LightingSolution::RayMarching))
            {
            ImGui::Spacing();
            if (BeginSettingsTree(
                    "Ray Traced Sky Visibility##Sky",
                    ImGuiTreeNodeFlags_DefaultOpen,
                    "Configure ray traced environment visibility. This effect "
                    "section remains independently collapsible while enabled."))
            {
            const RayTracedSkyVisibilitySettings& skyVisibility =
                m_ui.RayTracedSkyVisibility;
            const bool skyVisibilityAvailable =
                IsSettingAvailable(SettingId::SkyVisibilityEnabled);
            const bool disableSkyVisibilityEnable =
                !skyVisibilityAvailable && !skyVisibility.enabled;
            if (!disableSkyVisibilityEnable)
            {
            DrawUiBoolean(
                "Enable##RayTracedSkyVisibility",
                SettingId::SkyVisibilityEnabled,
                "Trace current frame world space visibility for the selected "
                "diffuse and specular environment lighting consumers.");
            }

            if (BeginToggleRegion(
                    "##RayTracedSkyVisibilityControls",
                    skyVisibility.enabled && skyVisibilityAvailable))
            {
                DrawUiBoolean(
                    "Effect Diffuse##RayTracedSkyVisibility",
                    SettingId::SkyVisibilityDiffuseIbl,
                    "Apply the scalar visibility to diffuse environment "
                    "lighting before final composition and GI source "
                    "radiance.");
                DrawUiBoolean(
                    "Effect Specular##RayTracedSkyVisibility",
                    SettingId::SkyVisibilitySpecularIbl,
                    "Apply cosine-weighted normal-hemisphere visibility to "
                    "specular lighting; it ignores reflection direction and "
                    "roughness.");

                const UiSettingsTypedDomain& sampleDomain =
                    GetUiSettingDefinition(
                        SettingId::SkyVisibilitySamplesPerPixel).typedDomain;
                std::int64_t minimumSamples = 1;
                std::int64_t maximumSamples = 1;
                const bool parsedSampleBounds =
                    TryParseCommandInteger(
                        sampleDomain.tokens.front(), minimumSamples) &&
                    TryParseCommandInteger(
                        sampleDomain.tokens[
                            sampleDomain.tokenCount - 1u],
                        maximumSamples);
                assert(parsedSampleBounds);
                int sampleRate = 1 << skyVisibility.sampleRateLog2;
                ImGui::SetNextItemWidth(settingsControlWidth);
                if (DrawBoundedSlider("Samples Per Pixel##RayTracedSkyVisibility", &sampleRate, static_cast<int>(minimumSamples), static_cast<int>(maximumSamples),
                        static_cast<int>(minimumSamples), static_cast<int>(maximumSamples),
                        "%d",
                        ImGuiSliderFlags_AlwaysClamp |
                            ImGuiSliderFlags_Logarithmic))
                {
                    std::size_t closestIndex = 0u;
                    double closestDistance =
                        std::numeric_limits<double>::infinity();
                    for (std::size_t index = 0u;
                        index < sampleDomain.tokenCount; ++index)
                    {
                        std::int64_t candidateSamples = 1;
                        if (!TryParseCommandInteger(
                                sampleDomain.tokens[index],
                                candidateSamples))
                        {
                            continue;
                        }
                        const double distance = std::abs(
                            std::log2(double(std::max(1, sampleRate))) -
                            std::log2(double(candidateSamples)));
                        if (distance < closestDistance)
                        {
                            closestDistance = distance;
                            closestIndex = index;
                        }
                    }
                    ApplyUiSetting(
                        SettingId::SkyVisibilitySamplesPerPixel,
                        UiSettingsValue::Token(
                            std::string(sampleDomain.tokens[closestIndex])));
                }
                ImGui::SetItemTooltip(
                    "Trace and average 1 to 64 cosine-weighted normal-hemisphere "
                    "rays per pixel.");
                DrawUiReset(SettingId::SkyVisibilitySamplesPerPixel, false, "RayTracedSkyVisibilitySamples");

                DrawUiBoolean(
                    "Specify Noise##RayTracedSkyVisibility",
                    SettingId::SkyVisibilitySpecifyNoise,
                    "Use custom noise sampling for this effect only. This "
                    "does not change the noise sampling used by any other "
                    "effect.");
                if (BeginToggleRegion(
                        "##RayTracedSkyVisibilityCustomNoise",
                        skyVisibility.noise.specifyNoise))
                {
                    drawNoiseSettingsControls(
                        "RayTracedSkyVisibility",
                        true,
                        {
                            SettingId::SkyVisibilityNoisePattern,
                            SettingId::SkyVisibilityNoiseResolution,
                            SettingId::SkyVisibilityAnimateSamples
                        });
                    EndControlRegion();
                }

                SetNextLabeledControlWidth(
                    "Max Distance##RayTracedSkyVisibility",
                    settingsControlWidth);
                DrawUiTokenCombo(
                    "Max Distance##RayTracedSkyVisibility",
                    SettingId::SkyVisibilityMaxDistance,
                    "Max uses the scene diagonal. Finite distances ignore "
                    "farther blockers and provide bounded, not exact, sky "
                    "visibility.");

                DrawUiFloat(
                    "Ray Bias##RayTracedSkyVisibility",
                    SettingId::SkyVisibilityRayBias,
                    "%.4f",
                    "Offset the ray origin along the view-facing raster-"
                    "triangle normal; large values can detach contact occlusion.");

                const WorldSpaceRepresentationStatus& status =
                    m_app->GetWorldSpaceRepresentationStatus();
                if (status.state ==
                        WorldSpaceRepresentationState::BuildingBlas ||
                    status.state ==
                        WorldSpaceRepresentationState::BuildingTlas)
                {
                    ImGui::TextDisabled(
                        "Preparing world hierarchy: BLAS %u/%u.",
                        status.builtBlasCount,
                        status.totalBlasCount);
                }
                EndControlRegion();
            }
            EndSettingsTree();
            }
            EndControlRegion();
            }

            EndDrawerBody();
        }
        ImGui::Spacing();

        DrawTonemapperDrawer(settingsControlWidth);
        DrawMaterialDrawer(settingsControlWidth);
        const bool noiseOpen = DrawCollapsingHeader(
            "Noise",
            "Configure the shared precomputed noise used by rendering effects.");
        if (noiseOpen)
        {
            BeginDrawerBody("##NoiseBody", settingsControlWidth);
            const auto drawSampleAccumulationControls = [&]()
            {
                if (m_ui.Lighting == LightingSolution::PathTracing)
                {
                    ImGui::TextDisabled(
                        "Path Tracing always advances one cumulative mean while inputs remain stable.");
                    return;
                }
                DrawUiBoolean(
                    "Enable##SampleAccumulation",
                    SettingId::NoiseAccumulateSamples,
                    "Average each successful Ray Marching sample until camera, scene, resolution, or lighting changes.");
            };

            drawNoiseSettingsControls(
                "GlobalNoise",
                false,
                {
                    SettingId::NoisePattern,
                    SettingId::NoiseResolution,
                    SettingId::NoiseAnimateSamples
                });
            ImGui::TextDisabled(
                "Resident texture memory: %.2f MiB",
                double(m_app->GetNoiseTextureResidentBytes()) /
                    (1024.0 * 1024.0));
            if (BeginSettingsTree(
                    "Accumulate Samples##Noise",
                    ImGuiTreeNodeFlags_DefaultOpen,
                    "Average finite scene-linear samples while the camera, "
                    "scene, and lighting remain still."))
            {
                drawSampleAccumulationControls();
                EndSettingsTree();
            }
            EndDrawerBody();
        }
        ImGui::Spacing();

        const bool debugOpen = DrawCollapsingHeader(
            "Debug",
            "Combine world appearance and effect-specific information views.");
        if (debugOpen)
        {
            BeginDrawerBody("##DebugBody", settingsControlWidth);

            if (BeginSettingsTree(
                    "World##Debug",
                    ImGuiTreeNodeFlags_DefaultOpen,
                    "Change material presentation without changing lighting effects."))
            {
            SetNextLabeledControlWidth(
                "Materials", settingsControlWidth);
            DrawUiRoundedTokenCombo(
                "Materials",
                SettingId::DebugWorldMaterials);
            ImGui::SetItemTooltip(
                "Choose default materials or white world. This combines with "
                "every effect-specific debug view.");
            DrawUiReset(SettingId::DebugWorldMaterials, true, "DebugWorld");
            EndSettingsTree();
            }

            if (BeginToggleRegion(
                    "##RayMarchingDebugBody",
                    m_ui.Lighting == LightingSolution::RayMarching))
            {
            if (BeginSettingsTree(
                    "Visibility##Debug",
                    ImGuiTreeNodeFlags_DefaultOpen,
                    "Inspect composition-stage visibility information."))
            {
            SetNextLabeledControlWidth(
                "View##VisibilityDebug", settingsControlWidth);
            DrawUiRoundedTokenCombo(
                "View##VisibilityDebug",
                SettingId::DebugVisibilityView);
            ImGui::SetItemTooltip(
                "Show the composite, ambient visibility, traced indirect light, "
                "or indirect response after material application.");
            DrawUiReset(SettingId::DebugVisibilityView, true, "DebugVisibility");
            EndSettingsTree();
            }

            if (BeginSettingsTree(
                    "Physically Based Lighting##Debug",
                    ImGuiTreeNodeFlags_DefaultOpen,
                    "Inspect material and environment-lighting information."))
            {
            const bool skyVisibilityDebugAvailable =
                m_ui.RayTracedSkyVisibility.enabled &&
                m_ui.Representation.allowRayTraversal &&
                m_app->SupportsRayTracedSkyVisibility();
            SetNextLabeledControlWidth(
                "Information Filter", settingsControlWidth);
            const SettingId debugPbrId = SettingId::DebugPbrFilter;
            const std::size_t lightingView =
                ReadUiTokenIndex(debugPbrId);
            const std::string lightingViewLabel =
                FormatUiSettingsTokenLabel(debugPbrId, lightingView);
            if (ImGui::BeginCombo(
                    "Information Filter",
                    lightingViewLabel.c_str()))
            {
                const UiSettingsTypedDomain& domain =
                    GetUiSettingDefinition(debugPbrId).typedDomain;
                for (std::size_t index = 0u;
                    index < domain.tokenCount;
                    ++index)
                {
                    const bool selected = index == lightingView;
                    const bool available =
                        domain.tokens[index] != "sky-visibility" ||
                        skyVisibilityDebugAvailable;
                    if (!available)
                        continue;
                    DrawUiTokenOption(debugPbrId, index, selected);
                    if (selected)
                        ImGui::SetItemDefaultFocus();
                }
                ImGui::EndCombo();
            }
            ImGui::SetItemTooltip(
                "Choose which material or environment-lighting quantity is "
                "shown. Visibility remains enabled and can still be inspected.");
            DrawUiReset(SettingId::DebugPbrFilter, true, "DebugLighting");
            EndSettingsTree();
            }

            EndControlRegion();
            }

            EndDrawerBody();
        }
        ImGui::Spacing();

        DrawDeveloperDrawer(settingsControlWidth);
        DrawInterfaceDrawer(settingsControlWidth);

        constexpr float ActionButtonCount = 4.f;
        const float actionButtonGap = g_UiSpacingTokens.tight;
        const float actionButtonWidth = std::max(
            1.f,
            (ImGui::GetContentRegionAvail().x -
                actionButtonGap * (ActionButtonCount - 1.f)) /
                ActionButtonCount);

        const ImVec4 drawerBackgroundColor =
            g_UiVisualTokens.actionButton;
        const ImVec4 drawerBackgroundHoveredColor =
            g_UiVisualTokens.actionButtonHovered;
        const ImVec4 drawerBackgroundActiveColor =
            g_UiVisualTokens.actionButtonActive;
        ImGui::PushStyleColor(
            ImGuiCol_Button,
            drawerBackgroundColor);
        ImGui::PushStyleColor(
            ImGuiCol_ButtonHovered,
            drawerBackgroundHoveredColor);
        ImGui::PushStyleColor(
            ImGuiCol_ButtonActive,
            drawerBackgroundActiveColor);
        ImGui::PushStyleColor(
            ImGuiCol_Text,
            g_UiVisualTokens.actionButtonText);

        if (DrawCenteredActionButton("Reset", actionButtonWidth))
            runUiAction(ActionId::ResetSettings);
        ImGui::SetItemTooltip(
            "Restore renderer and interface factory settings without changing "
            "the camera, scene, or graphics adapter.");

        ImGui::SameLine(0.f, actionButtonGap);
        if (DrawCenteredActionButton("Capture", actionButtonWidth))
            runUiAction(ActionId::Capture);
        ImGui::SetItemTooltip("Copy the current frame to the clipboard.");

        ImGui::SameLine(0.f, actionButtonGap);
        if (DrawCenteredActionButton(
                "Zoom",
                actionButtonWidth))
        {
            const SettingId zoomId = SettingId::UiZoom;
            const UiSettingsTypedDomain& zoomDomain =
                GetUiSettingDefinition(zoomId).typedDomain;
            const std::size_t tokenIndex =
                (ReadUiTokenIndex(zoomId) + 1u) %
                zoomDomain.tokenCount;
            ApplyUiSetting(
                zoomId,
                UiSettingsValue::Token(
                    GetUiSettingToken(zoomId, tokenIndex)));
        }
        ImGui::SetItemTooltip(
            "Cycle exact Off, 2x, 3x, 4x, and 5x pixel zoom. Z uses the "
            "same cycle.");

        ImGui::SameLine(0.f, actionButtonGap);
        if (DrawCenteredActionButton("Restart", actionButtonWidth))
            runUiAction(ActionId::Restart);
        ImGui::SetItemTooltip("Restart UVSR.");
        ImGui::PopStyleColor(4);

        const RootPanelGeometry finalSettingsGeometry = GetRootPanelGeometry(settings.window);
        ImRect settingsContentRect = settingsBodyWindow->Rect();
        settingsContentRect.ClipWith(finalSettingsGeometry.content);
        ImDrawList* settingsDecorationDrawList =
            ResolveFinalSettingsDecorationDrawList(settings.window);
        if (settingsDecorationDrawList &&
            settingsDecorationDrawList->_Splitter._Count > 1)
        {
            settingsDecorationDrawList->ChannelsMerge();
        }
        // Root chrome is appended after visible descendants so its border
        // covers clipped child edges without changing their hit rectangles.
        DrawRootPanelBodyChrome(
            settingsDecorationDrawList,
            finalSettingsGeometry.body,
            settingsContentRect,
            settingsGeometry.summary,
            style.WindowRounding);
        if (expandedSettingsSnapshotSubmitted)
        {
            settingsDecorationDrawList->PushClipRect(
                finalSettingsGeometry.body.Min,
                finalSettingsGeometry.body.Max,
                false);
            settingsDecorationDrawList->AddText(
                expandedSettingsSnapshotMinimum,
                ImGui::GetColorU32(ImGuiCol_Text),
                m_SettingsSnapshots.Code().c_str());
            settingsDecorationDrawList->PopClipRect();
        }
        ImGui::PopUvsrColorPickerPopupContentRight();
        ImGui::EndChild();
        }
        const float rootBodyRounding =
            style.WindowRounding;
        const ImRect settingsBodyRect = settingsGeometry.body;
        if (settings.collapsed &&
            settingsBodyRect.GetHeight() >
                style.WindowPadding.y * 2.f + 2.f)
        {
            const ImRect snapshotHitRect = DrawCompactRootPanelBody(
                settings.window->DrawList,
                settingsBodyRect,
                settingsGeometry.summary,
                rootBodyRounding,
                m_SettingsSnapshots.Code().c_str());
            const bool snapshotHovered = snapshotHitRect.Contains(ImGui::GetIO().MousePos);
            if (snapshotHovered)
            {
                ImGui::SetMouseCursor(ImGuiMouseCursor_Hand);
                ImGui::SetTooltip(
                    "Click to copy this versioned settings snapshot code. "
                    "The decoder resolves every represented setting from "
                    "the local UVSR snapshot catalog.");
                if (ImGui::IsMouseClicked(ImGuiMouseButton_Left))
                    CopySettingsSnapshot();
            }
        }
        if (settings.collapsed != m_SettingsCollapsed)
        {
            ApplyUiSetting(
                SettingId::UiSettingsCollapsed,
                UiSettingsValue::Boolean(settings.collapsed));
        }
        if (settings.collapsed && m_ui.ShowMaterialDrawer)
            ApplyUiSetting(SettingId::MaterialEditorVisible, UiSettingsValue::Boolean(false));
        EndRootPanel();
        RestoreActiveUiWordSpacing();
        ImGui::PopFont();
    }

void UIRenderer::DrawTonemapperDrawer(float controlWidth)
{
    if (!DrawCollapsingHeader("Tonemapper", "AgX tone and color controls for the rendered image."))
    {
        ImGui::Spacing();
        return;
    }
    BeginDrawerBody("##TonemapperBody", controlWidth);
    DrawUiBoolean("Enabled##Tonemapper", SettingId::TonemapperEnabled,
        "Enable the tone controls and film LUT. Off restores the original neutral AgX image. Automatic exposure remains independent.");
    if (BeginToggleRegion("##TonemapperControls", m_ui.ToneMapping.enabled))
    {
        const int preset = FindToneMappingPreset(m_ui.ToneMapping);
        SetNextLabeledControlWidth("Preset##Tonemapper", controlWidth);
        if (ImGui::BeginCombo("Preset##Tonemapper", preset < 0 ? "Custom" : ToneMappingPresets[preset].label))
        {
            for (int index = 0; index < int(ToneMappingPresets.size()); ++index)
            {
                DrawDropdownOption(ToneMappingPresets[index].label, index == preset, [&]()
                {
                    constexpr std::array ids = {
                        SettingId::TonemapperExposure, SettingId::TonemapperContrast,
                        SettingId::TonemapperSaturation, SettingId::TonemapperWarmth,
                        SettingId::TonemapperTint, SettingId::TonemapperSlope, SettingId::TonemapperPower };
                    const auto values = ToneMappingGradeValues(ToneMappingPresets[index].settings);
                    for (size_t field = 0; field < ids.size(); ++field)
                        ApplyUiSetting(ids[field], UiSettingsValue::Float(values[field]));
                });
            }
            ImGui::EndCombo();
        }
        ImGui::SetItemTooltip("Choose a grade. Edits display Custom. Film LUT selection is independent.");
        SetNextLabeledControlWidth("Film LUT", controlWidth);
        DrawUiRoundedTokenCombo("Film LUT", SettingId::TonemapperLut);
        ImGui::SetItemTooltip("Apply a bundled film-style color look. These are artistic simulations, not official film profiles.");
        DrawUiReset(SettingId::TonemapperLut);
        DrawUiFloat("Image Exposure##Tonemapper", SettingId::TonemapperExposure, "%.2f EV",
            "Adjust the whole rendered image, including direct lights and emissive materials, before AgX. This does not change lighting. Environment Exposure in Sky changes only the environment.", ImGuiSliderFlags_None, false, controlWidth);
        DrawUiFloat("Contrast##Tonemapper", SettingId::TonemapperContrast, "%.3f",
            "Increase or reduce contrast.", ImGuiSliderFlags_None, false, controlWidth);
        DrawUiFloat("Saturation##Tonemapper", SettingId::TonemapperSaturation, "%.3f",
            "Increase or reduce color intensity.", ImGuiSliderFlags_None, false, controlWidth);
        DrawUiFloat("Warmth##Tonemapper", SettingId::TonemapperWarmth, "%.3f",
            "Shift colors warmer or cooler.", ImGuiSliderFlags_None, false, controlWidth);
        DrawUiFloat("Tint##Tonemapper", SettingId::TonemapperTint, "%.3f",
            "Shift colors toward green or magenta.", ImGuiSliderFlags_None, false, controlWidth);
        DrawUiFloat("Slope##Tonemapper", SettingId::TonemapperSlope, "%.4f",
            "Scale the color grade. 1.0 is neutral.", ImGuiSliderFlags_None, false, controlWidth);
        DrawUiFloat("Power##Tonemapper", SettingId::TonemapperPower, "%.4f",
            "Below 1 brightens; above 1 darkens.", ImGuiSliderFlags_None, false, controlWidth);
        EndControlRegion();
    }
    EndDrawerBody();
    ImGui::Spacing();
}
