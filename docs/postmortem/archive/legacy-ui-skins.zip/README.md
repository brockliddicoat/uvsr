# legacy UI recovery

this archive preserves the complete first-party source before the single-skin cutdown, including Amp, Ogg, and Cap. it is historical recovery material, outside routine source inspection.

source lineage: codex/pre-nrd-features-20260905, commit c4dbcb31c2a241f5864cb08ae2f80551ef2615fb with the dirty snapshot in source-before.zip. source-manifest.json records every source file hash and the unchanged index hash. the vendor revisions and license records are inside that source snapshot. Noto Sans font assets and their license are included here.

recovery: extract this archive into a separate work directory. verify the checksums, then extract source-before.zip into an isolated checkout at the recorded commit with its pinned dependencies. do not overwrite newer work. the snapshot contains the full pre-cut settings catalog, ImGui patch, staging digest, tests, asset map, and legal records, so the skins can be rebuilt or deliberately ported to newer source together. current settings catalogs must not load old UI implementation files piecemeal.

this archive contains source recovery evidence, not a current release package.
